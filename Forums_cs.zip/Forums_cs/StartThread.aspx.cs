using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Configuration;
using dotForumIncludes;
using Forums_cs.Classes;
namespace Forums_cs
{
	/// <summary>
	/// Summary description for StartThread1.
	/// </summary>
	public partial class StartThread1 : System.Web.UI.Page
	{
		public includeFunctions myIncludes = new includeFunctions();
		ThreadMgr objThreadMgr = null;
		clsError objError = null;
		DataSet dsCts = null;
		User objUser = null;
		clsItemUploadFileMgr objUploadMgr = null;

		protected System.Web.UI.WebControls.Panel pnlGuest;
		
		string strQry = null;
		public string thisTopicId = null;
		string strPsid = null;
	
		string TopicId = null;
		protected void Page_Load(object sender, System.EventArgs e)
		{
			if(Session["Uname"]!=null)
			{
				objUploadMgr = new clsItemUploadFileMgr();
				if(objUploadMgr.ShowAttach(Session["Uname"].ToString()))
				{
					pnlAttach.Visible = true;
				}
				pnlLoginImage.Visible = true;	
				
				pnluser.Visible = true;
				pnlTopLogin.Visible = false;
				pnlBottomLogin.Visible = false;
				pnlBottomLogout.Visible = true;
				pnlMiddleLogin.Visible = false;
				pnlMiddleLogout.Visible = true;
				if(Session["Name"]!=null)
				{
					lblUserName.Text = Session["Name"].ToString();
				}
			}
			else
			{
				lblUserName.Text = null;
			}
			if(Session["Uname"]!=null)
			{
				psEmail.Text = Session["Uname"].ToString();
				if(Session["Name"]!=null)
				{
					psName.Text = Session["Name"].ToString();
				}
				try
				{
					if(Request.QueryString["id"]!=null)
					{
						thisTopicId = Request.QueryString["id"];
					}										
				}
					//INSTANT C# TODO TASK: No C# equivalent to 'When'
				catch (Exception ex) // When 1=1
				{						
					Response.Redirect("ErrorPage.aspx");
				}

				

				if (! Page.IsPostBack)
				{
					objUser = new User();
					objError = new clsError();
					

					HidPostid.Value = objUser.GetID("PS","select * from forumthreads where Postid = ",ref objError);
					submitter.CommandArgument = thisTopicId;
					objError = new clsError();
					objThreadMgr = new ThreadMgr();
					string strImgurl = objThreadMgr.GetImagPath(thisTopicId,ref objError);
					if(strImgurl != null && strImgurl != "")
					{						
						imgCountry.ImageUrl = strImgurl;
					}
					else
					{
						imgCountry.ImageUrl = "fa_images/default_image.JPG";
					}
				}
			}
			else
			{
				Response.Redirect("LoginPage.aspx?qstr=Newthread");
			}
			submitter.Attributes["onclick"] = "javascript:return valid()";
			lnkbtnAttach.Attributes["onclick"] = "javascript:return FileUpload('"+HidPostid.Value.Trim()+"')";
		}
		public void Page_Error(object sender, EventArgs e)
		{
			string strErrorMessage = "";

			Response.Write("<font style=\"color:#cc0000; font-family: system; font-size:11px;\">An error has occurred on this page:<p>");
			strErrorMessage = Request.Url.ToString() + "<p>" + Server.GetLastError().ToString() + "</font>";
			Response.Write(strErrorMessage);

			Server.ClearError();

			Response.Write("<p><a class=\"menuitem\" href=\"ErrorPage.aspx\">Return to the Discussion Forum</a></p>");

		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.imgbtnSearch.ServerClick += new System.Web.UI.ImageClickEventHandler(this.imgbtnSearch_ServerClick);

		}
		#endregion

		protected void lnkbtnBotLogout_click(object sender, System.EventArgs e)
		{
			Session.Abandon();
			
			Response.Redirect("Home.aspx");
		}

		protected void submitter_Click(object sender, System.EventArgs e)
		{
			
			objError = new clsError();
			string PostId = null;
			try
			{
				if (Page.IsValid)
				{
					
					PostId = HidPostid.Value.Trim();
					objUser = new User();
					objError = new clsError();
					strPsid = objUser.GetThreadId("select * from forumthreads where psId = ",ref objError);
					objThreadMgr = new ThreadMgr();
					if(Session["CatName"]!=null)
					{
						objThreadMgr.CreateCategory(thisTopicId,Session["CatName"].ToString(),ref objError);
					}				
					
					if(objError.boolErrorOccurred == false)
					{		
			
						System.DateTime lastUpdate = System.DateTime.Now;
						SqlConnection myConnection = new SqlConnection(ConfigurationSettings.AppSettings["forumDSN"]);
						if(chkBox.Checked)
						{
							strQry = "INSERT INTO forumThreads (psId,psRelTopId, psName, psEmail, psSubject, psPost, psDate, psRelBcId, psLastUpdate, psIP, Postid, Notify) VALUES('"+strPsid+"','0', '" + myIncludes.RemoveHTMLQuote(psName.Text) + "',  '" + myIncludes.RemoveHTMLQuote(psEmail.Text) + "',  '["+myIncludes.getTopicName(thisTopicId.Trim())+"]"+myIncludes.RemoveHTMLQuote(psSubject.Text) + "',  '" + myIncludes.RemoveHTMLQuote(psPost.Text) + "', '" + lastUpdate + "', '"+thisTopicId.Trim()+"', '" + lastUpdate + "', '" + Request.ServerVariables["REMOTE_HOST"] + "', '"+PostId+"', 'Y')";
						}
						else
						{
							strQry = "INSERT INTO forumThreads (psId,psRelTopId, psName, psEmail, psSubject, psPost, psDate, psRelBcId, psLastUpdate, psIP, Postid) VALUES('"+strPsid+"','0', '" + myIncludes.RemoveHTMLQuote(psName.Text) + "',  '" + myIncludes.RemoveHTMLQuote(psEmail.Text) + "',  '["+myIncludes.getTopicName(thisTopicId)+"]"+myIncludes.RemoveHTMLQuote(psSubject.Text) + "',  '" + myIncludes.RemoveHTMLQuote(psPost.Text) + "', '" + lastUpdate + "','"+thisTopicId+"', '" + lastUpdate + "', '" + Request.ServerVariables["REMOTE_HOST"] + "', '"+PostId+"')";
						}
						SqlCommand myCommand = new SqlCommand(strQry, myConnection);

						myConnection.Open();
						myCommand.ExecuteNonQuery();
						myConnection.Close();

						//### UPDATE LAST DATE IN TOPIC
						SqlCommand myCommand2 = new SqlCommand("UPDATE forumTopics SET bcLastUpdate = '" + lastUpdate + "' WHERE bcId = '"+thisTopicId+"'", myConnection);

						myConnection.Open();
						myCommand2.ExecuteNonQuery();
						myConnection.Close();
						Session["CatName"] = null;
						Response.Redirect("topicView.aspx?id=" + thisTopicId);
					}
				}
			}
				//INSTANT C# TODO TASK: No C# equivalent to 'When'
			catch (Exception ex) // When 1=1
			{
				Response.Write("<font style=\"color:#cc0000; font-family: system; font-size:11px;\">An Exception error has occurred on this page:<p>");
				Response.Write("<p>" + ex.ToString());
				Response.Write("<p><b>Record NOT Inserted</b></font>");
				Server.ClearError();
			}
		}

		protected void canceller_Click(object sender, System.EventArgs e)
		{
			Response.Redirect("topicView.aspx?id=" + thisTopicId);
		}

		

		protected void lnkbtnLogout_Click(object sender, System.EventArgs e)
		{
			Session.Abandon();
			
			Response.Redirect("Home.aspx");
		}

		protected void lnkbtnSetting_Click(object sender, System.EventArgs e)
		{
			Response.Redirect("MySettings.aspx?uid=Edit");
		}
		public DataSet FillCountries()
		{
			dsCts = new DataSet();
			objError = new clsError();
			objThreadMgr = new ThreadMgr();
			dsCts =	objThreadMgr.GetCountries(ref objError);
			return dsCts;
		}
		public DataSet FillStates()
		{
			dsCts = new DataSet();
			objError = new clsError();
			objThreadMgr = new ThreadMgr();
			dsCts =	objThreadMgr.GetSates(ref objError);
			return dsCts;
		}

		private void imgbtnSearch_ServerClick(object sender, System.Web.UI.ImageClickEventArgs e)
		{
			Response.Redirect("Search.aspx?srch="+textfield.Value.Trim());
		}

		
	}
}
