using System;
using System.Collections;
using System.Configuration;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using Forums_cs.Classes;
using System.IO;
using System.Security.Permissions;
using dotForumIncludes;
namespace FA.Web
{
	/// <summary>
	/// Summary description for LoginPage.
	/// </summary>
	public partial class LoginPage : System.Web.UI.Page
	{
		Login objLogin = null;		
		User objUser = null;
		clsError objError = null;
		string strQstr = null;
		Authenticate objAuth = null;
		includeFunctions myincludes = null;

		Register objReg = null;
		protected System.Web.UI.WebControls.ImageButton imgbtnLogout;
		
		bool redirect = false;
		
		FileStream objFile = null;
		StreamReader objreader = null;
		DataSet dsCts = null;
		ThreadMgr objThreadMgr = null;
		protected System.Web.UI.WebControls.Panel pnlRegCts;
		protected System.Web.UI.WebControls.LinkButton lnkbtnNew;
		ArrayList alistCts = null;
		bool flag = false;
		protected void Page_Load(object sender, System.EventArgs e)
		{
			lblError.Text = null;
			if(Request.QueryString["qstr"]!=null)
			{
				redirect = true;
				strQstr = Request.QueryString["qstr"].ToString();
				if(strQstr == "login")
				{
					pnlLogin.Visible = true;
				}
				else if(strQstr == "LoginUser")
				{
					Session["CntName"] = null;
					pnlLogin.Visible = true;
					pnlshowLogin.Visible = true;
					pnlshowReg.Visible = false;
					pnlflashLogin.Visible = true;
				}
				else if(strQstr == "Register")
				{
					pnlshowLogin.Visible = false;
					pnlshowReg.Visible = true;
					pnlCreateAcnt.Visible = true;
					pnlflashReg.Visible = true;
					if(!IsPostBack)
					{
						if(Session["IMGpath"]!=null)
						{
							Session["IMGpath"] = null;
						}
						Session["CntName"] = null;
						ddlNationality.DataSource = FillRegCountries();
						ddlNationality.DataBind();
						ddlNationality.Items.Insert(0,"--Select Country--");
						ddlCntry.DataSource = FillRegCountries();
						ddlCntry.DataBind();
						ddlCntry.Items.Insert(0,"--Select Country--");
						

						//lstCnts.DataSource = FillCountries();
						//lstCnts.DataBind();						
					}
					if(pnlLogin.Visible == true)
					{

						pnlLogin.Visible = false;
					}
				}
				else if(strQstr == "Newthread")
				{
					Session["CntName"] = null;
					pnlshowLogin.Visible = true;
					pnlshowReg.Visible = false;
					pnlLogin.Visible = true;
				}
				else if(strQstr == "RegSuc")
				{
					pnlshowLogin.Visible = false;
					pnlshowReg.Visible = true;
					lblError.Text = null;
					pnlSuccess.Visible = true;
					pnlLogin.Visible = false;
					pnlCreateAcnt.Visible = false;
				}
				else if(strQstr == "forgot")
				{
					if(!IsPostBack)
					{
						pnlshowLogin.Visible = true;
						pnlshowReg.Visible = false;
						pnlCreateAcnt.Visible = false;
						pnlforgot.Visible = true;
						pnlLogin.Visible = false;
					}				
					else if(Request["__EVENTTARGET"] != null)
					{
						if(Request["__EVENTTARGET"].ToString() == "btnforgot")
						{
							ForgotSubmit();
						}
					}
					
				}				
				else
				{
					Response.Redirect("ErrorPage.aspx");
				}

			}
			if(Session["Uname"]!=null)
			{
				redirect = true;
				pnlLoginImage.Visible = true;	
				pnlBottomLogout.Visible = true;
				pnlBottomLogin.Visible = false;
				pnluser.Visible = true;
				pnlTopLogin.Visible = false;
				if(Session["Name"]!=null)
				{
					lblUserName.Text = Session["Name"].ToString();
				}
			}
			else
			{
				lblUserName.Text = null;
			}
			btnCreate.Attributes["onclick"] = "javascript:return Valid()";
			btnLogin.Attributes["onclick"] = "javascript:return LoginValid()";
			lnkbtnUpload.Attributes["onclick"] = "javascript:return ImgPopup()";
			lnkbtnCtsVisit.Attributes["onclick"] = "javascript:return OpenCtsVisit()";
			btnsubmit.Attributes["onclick"] = "javascript:return ForgotValid()";
			if(!redirect)
			{
				Response.Redirect("ErrorPage.aspx");
			}
			
			
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    

		}
		#endregion

		

		protected void btnCreate_Click(object sender, System.EventArgs e)
		{
			DataSet dsCts = new DataSet();
			try
			{
				if(chkBoxTerms.Checked && chkBoxPolicy.Checked)
				{
					if(txtBoxPwd.Text.Trim()==txtBoxConfirmPwd.Text.Trim())
					{
						alistCts = new ArrayList();
						objReg = new Register();
						objLogin = new Login();
						objReg = new Register();
						objError = new clsError();						
						objLogin.State = txtBoxstate.Text;
						if(ddlNationality.SelectedIndex != 0)
						{
							objLogin.Nation = ddlNationality.SelectedItem.Text;
						}
						
						if(ddlCntry.SelectedIndex != 0)
						{
							objLogin.Country = ddlCntry.SelectedItem.Text;
						}						
						objLogin.Uname = txtBoxEmail.Text;
						objLogin.Pwd = txtBoxPwd.Text;
						objLogin.Fname = txtBoxFname.Text;
						
						objLogin.City = txtBoxCity.Text;
						objLogin.AbtMyself = txtBoxabtMyself.Text;
						if(ddlCntry.SelectedIndex != 0)
						{
							objLogin.FlagPath = ddlCntry.SelectedItem.Value;
						}
						if(rdbtnYes.Checked)
						{
							objLogin.PvtCnt = "Y";
						}
						else if(rdbtnNo.Checked)
						{
							objLogin.PvtCnt = "N";
						}
						if(Session["IMGpath"]!=null)
						{
							objLogin.ImgPath = Session["IMGpath"].ToString();	
						}
						dsCts = (DataSet)Session["CntName"];
						if(dsCts != null)
						{
							for(int i = 0; i<dsCts.Tables[0].Rows.Count ; i++)	
							{								
								alistCts.Add(dsCts.Tables[0].Rows[i]["Cntryid"].ToString());								
							}
						}
							
						if(objReg.CreateUser(ref objLogin,alistCts,ref objError))
						{
							if(objError.boolErrorOccurred == false)
							{
								if(Session["IMGpath"]!=null)
								{
									Session["IMGpath"] = null;
								}
								Response.Redirect("LoginPage.aspx?qstr=RegSuc");					
							}
						
						}
						else
						{
							
							lblError.ForeColor = Color.Red;
							lblError.Text = objError.strMessage;
						}
					}
				}
			}
			catch(Exception ex)
			{
				lblError.ForeColor = Color.Red;
				lblError.Text = "Error:"+ex.Message.ToString();
			}
		}

		protected void btnSave_Click(object sender, System.EventArgs e)
		{	
			
		}
		protected void btnLogin_Click(object sender, System.EventArgs e)
		{
			bool flag = false;
			try
			{				
				objAuth = new Authenticate();
				objError = new clsError();
				objLogin = new Login();
				objLogin.Uname = txtBoxUname.Text;
				objLogin.Pwd = txtBoxLoginPwd.Text;
				if(objAuth.Authenticator(ref objLogin,ref objError))
				{
					Session["Uname"] = objLogin.Uname;
					Session["Name"] = objAuth.GetName(objLogin.Uname,ref objError);
					if(strQstr == "login")
					{
						flag = true;
					}
					else if(strQstr == "LoginUser")
					{
						Response.Redirect("Home.aspx");
					}
					else if(strQstr == "Newthread")
					{
						Response.Redirect("Home.aspx");
					}
				}
				else
				{
					lblError.ForeColor = Color.Red;
					lblError.Text = "Invalid Login.Please check your Username and Password";
				}
			}
			catch(Exception ex)
			{
				objError.boolErrorOccurred = true;
				lblError.ForeColor = Color.Red;
				lblError.Text = "Error:"+ex.Message.ToString();
			}
			finally
			{
				if(flag)
				{
					Response.Redirect("postReply.aspx");
				}
			}
		}

		protected void lnkbtnNew_Click(object sender, System.EventArgs e)
		{

			Response.Redirect("LoginPage.aspx?qstr=Register");
		}


		protected void btnSuccess_Click(object sender, System.EventArgs e)
		{
			Response.Redirect("Home.aspx");
		}

		private void imgbtnLogout_Click(object sender, System.Web.UI.ImageClickEventArgs e)
		{
			Session.Abandon();
//			pnlLoginImage.Visible = true;
//			imgbtnLogout.Visible = false;
//			lblUserName.Text = null;			
//			pnluser.Visible = false;
			Response.Redirect("Home.aspx");
		}

		protected void lnkbtnForgot_Click(object sender, System.EventArgs e)
		{
//			pnlshowLogin.Visible = true;
//			pnlshowReg.Visible = false;
//			pnlCreateAcnt.Visible = false;
//			pnlforgot.Visible = true;
//			pnlLogin.Visible = false;

			Response.Redirect("LoginPage.aspx?qstr=forgot");
		}

		protected void btnsubmit_Click(object sender, System.EventArgs e)
		{
			if(!flag)
			{
				objAuth = new Authenticate();
				objError = new clsError();
				string strText = null;
				lblUserName.Text = null;
				strText = objAuth.ForgotPassword(txtForgot.Text.Trim(),ref objError);
				if(strText!=null)
				{
					lblError.Text = null;
					pnlLogin.Visible = false;
					pnlCreateAcnt.Visible = false;
					pnlforgot.Visible = false;
					pnlSuccess.Visible = false;
					pnlTopLogin.Visible = true;
					pnlForgotSuc.Visible = true;
					lblForgotSuc.Text = strText;
				}
				else
				{
					pnlLogin.Visible = false;
					pnlCreateAcnt.Visible = false;
					pnlforgot.Visible = true;
					pnlSuccess.Visible = false;
					lblError.ForeColor = Color.Red;
					lblError.Text = objError.strMessage;
				}
			}
		}

		public void ForgotSubmit()
		{
			flag = true;
			objAuth = new Authenticate();
			objError = new clsError();
			string strText = null;
			lblUserName.Text = null;
			strText = objAuth.ForgotPassword(txtForgot.Text.Trim(),ref objError);
			if(strText!=null)
			{
				lblError.Text = null;
				pnlLogin.Visible = false;
				pnlCreateAcnt.Visible = false;
				pnlforgot.Visible = false;
				pnlSuccess.Visible = false;
				pnlTopLogin.Visible = true;
				pnlForgotSuc.Visible = true;
				lblForgotSuc.Text = strText;
				txtForgot.Text = null;
			}
			else
			{
				pnlLogin.Visible = false;
				pnlCreateAcnt.Visible = false;
				pnlforgot.Visible = true;
				pnlSuccess.Visible = false;
				lblError.ForeColor = Color.Red;
				lblError.Text = objError.strMessage;
			}
		}

		protected void btnForHome_Click(object sender, System.EventArgs e)
		{
			Response.Redirect("Home.aspx");
		}

		
		

		protected void lnkbtnLogout_Click(object sender, System.EventArgs e)
		{
			Session.Abandon();
			pnlTopLogin.Visible = true;			
			pnlLoginImage.Visible = false;
			lblUserName.Text = null;
			
			pnluser.Visible = false;
		}

		protected void lnkbtnSetting_Click(object sender, System.EventArgs e)
		{
			Response.Redirect("MySettings.aspx?uid=Edit");
		}

		public DataSet FillCountries()
		{
			dsCts = new DataSet();
			objError = new clsError();
			objThreadMgr = new ThreadMgr();
			dsCts =	objThreadMgr.GetCountries(ref objError);
			return dsCts;
		}

		public DataSet FillRegCountries()
		{
			dsCts = new DataSet();
			objError = new clsError();
			objThreadMgr = new ThreadMgr();
			dsCts =	objThreadMgr.GetRegCountries(ref objError);
			return dsCts;
		}

		public DataSet FillStates()
		{
			dsCts = new DataSet();
			objError = new clsError();
			objThreadMgr = new ThreadMgr();
			dsCts =	objThreadMgr.GetSates(ref objError);
			return dsCts;
		}
		
		
		public DataSet ddlBind()
		{
			DataSet dsddl = new DataSet();
			objThreadMgr = new ThreadMgr();
			objError = new clsError();
			if(Session["Uname"] != null)
			{
				dsddl =	objThreadMgr.GetCountries(ref objError);
			}
			return dsddl;
		}

		

		private void Button1_Click(object sender, System.EventArgs e)
		{
			lblError.Text = null;
			pnlSuccess.Visible = true;
			pnlLogin.Visible = false;
			pnlCreateAcnt.Visible = false;
			pnlRegCts.Visible = false;
		}
		
		public void Check()
		{
			if(pnlForgotSuc.Visible)
			{
				Response.Redirect("Home.aspx");
			}
			if(pnlSuccess.Visible)
			{
				Response.Redirect("Home.aspx");
			}
		}

		protected void lnkbtnBotLogout_click(object sender, System.EventArgs e)
		{
			Session.Abandon();
			
			Response.Redirect("Home.aspx");
		}
		
	}
}
