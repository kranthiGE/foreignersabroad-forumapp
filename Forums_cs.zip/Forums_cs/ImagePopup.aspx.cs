using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Configuration;
using Forums_cs.Classes;
using dotForumIncludes;
namespace Forums_cs
{
	/// <summary>
	/// Summary description for ImagePopup.
	/// </summary>
	public partial class ImagePopup : System.Web.UI.Page
	{
		string strFileName = null;
		string strPath = null;
		string RelPath = null;
		string ItemId = null;
		int Filelength = 0;
		int fileindex = 0;
		string strFileExtent = null;

		includeFunctions myincludes = null;
		clsError objError = new clsError();
        clsSendmail objSend = null;

		string strMailTo = null;
		string strMailFrom = null;
		protected void Page_Load(object sender, System.EventArgs e)
		{
			lblError.Text = null;
			
			if(Request.QueryString["send"]!=null)
			{
				if(!IsPostBack)
				{
					pnlImg.Visible = false;
					pnlSendMail.Visible = true;
					txtBoxTo.Text = Request.QueryString["send"].ToString();
					
				}
			}
			else
			{
				if(!Page.IsPostBack)
				{
					UploadImg.ImageUrl = ConfigurationSettings.AppSettings["nophoto"].ToString();
					if(Session["IMGpath"]!=null)
					{
						UploadImg.ImageUrl = Session["IMGpath"].ToString();
					}
				}
			}
			btnSend.Attributes["onclick"] = "javascript:return SendValid()";
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    

		}
		#endregion

		protected void lnkbtnAdd_Click(object sender, System.EventArgs e)
		{
			if(FileImage.Value != null)
			{
				if(FileImage.PostedFile != null)
				{	
					if(FileImage.PostedFile.ContentLength != 500000)
					{
						FileExtentionCheck(ref objError);

						if(objError.boolErrorOccurred == false)
						{
							if(strFileExtent == ".jpg" || strFileExtent == ".gif" || strFileExtent == ".bmp")
							{
								try
								{
									if(FileImage.PostedFile.ContentLength < 300000)
									{									
										lblImagePath.Text = FileImage.PostedFile.FileName;
										UploadImg.Width = 75;
										UploadImg.Height = 75;
									
										strFileName = GetFileName(FileImage.PostedFile.FileName);
								
										RelPath = ConfigurationSettings.AppSettings["ImgPath"]+strFileName;
										strPath = HttpContext.Current.Server.MapPath(ConfigurationSettings.AppSettings["ImgPath"]+strFileName);
										FileImage.PostedFile.SaveAs(strPath);
										UploadImg.ImageUrl = RelPath;
										Session["IMGpath"] = RelPath;	
									}
									else
									{
										lblError.ForeColor = Color.Red;
										lblError.Text = "Error: Cannot upload Images greater than 300KB";
									}
								}
								catch(Exception ex)
								{
									Response.Write(ex.Message.ToString());
									lblError.ForeColor = Color.Red;
									lblError.Text = "Error: Please browse for the Image";
								}
							}
							else
							{
								Session["FileExtent"] = null;
								lblError.ForeColor = Color.Red;
								lblError.Text = "Error:Please upload only Jpj or Gif Files";
							}
						}
						else
						{
							if(objError.boolErrorOccurred == true)
							{
								lblError.ForeColor = Color.Red;
								lblError.Text =	objError.strMessage;
							}
						}
					}
					else
					{
						lblError.ForeColor = Color.Red;
						lblError.Text = "The Size of the Image cannot be more than 500kb.";
					}
				}

			}
		}

		protected void btnAdd_Click(object sender, System.EventArgs e)
		{
			try
			{
				RegisterClientScriptBlock("Close","<script language='Javascript'>closeWin();</script>");
			}
			catch(Exception ex)
			{
				Session["IMGpath"] = null;
				lblError.ForeColor = Color.Red;
				lblError.Text = "The Image Couldnot be Saved.";
			}
		}

		public void FileExtentionCheck(ref clsError objError)
		{   
			try
			{
				Filelength = FileImage.PostedFile.FileName.Length;
				fileindex = FileImage.PostedFile.FileName.LastIndexOf(".");
				strFileExtent = FileImage.PostedFile.FileName.Substring(fileindex,Filelength - fileindex).ToLower();
				Filelength = 0;
			}
			catch(Exception ex)
			{
				objError.boolErrorOccurred = true;
				objError.strMessage = "Error: Please Browse for the Image File";
			}
		}

		public string GetFileName(string strPath)
		{
			Filelength = FileImage.PostedFile.FileName.Length;
			fileindex = FileImage.PostedFile.FileName.LastIndexOf("\\");
			strFileExtent = FileImage.PostedFile.FileName.Substring(fileindex+1,Filelength - (fileindex+1)).ToLower();
			return strFileExtent;
		}

		protected void btnSend_Click(object sender, System.EventArgs e)
		{
			string strBody = null;
			string strEmail = null;
			objError = new clsError();
			objSend = new clsSendmail();
			myincludes = new includeFunctions();
			objSend.SetMailSubject(txtBoxSub.Text.Trim());
			strBody = myincludes.InsertSmiley_Domain(txtBoxBody.Text.Trim());
			objSend.SetMailBody(strBody);
			if(Session["emailid"]!=null)
			{
				strEmail = Session["emailid"].ToString();
				strMailFrom = Session["Uname"].ToString();
				objSend.SendMailTo(strMailFrom,strEmail,ref objError);
				if(objError.boolErrorOccurred == false)
				{
					pnlMailSent.Visible = true;
					pnlImg.Visible = false;
					pnlSendMail.Visible = false;
				}
			}
		}

		public string MailBody(string Body)
		{
			string strBody = null;

			return strBody;
		}

		protected void btnClose_Click(object sender, System.EventArgs e)
		{
			if(Session["IMGpath"] != null)
			{
				Session["IMGpath"] = null;
			}
			RegisterClientScriptBlock("Close","<script language='Javascript'>closeWin();</script>");
		}


		


	}
}
