using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using Forums_cs.Classes;
using dotForumIncludes;
using System.Text.RegularExpressions;
namespace Forums_cs
{
	/// <summary>
	/// Summary description for Search.
	/// </summary>
	public partial class Search : System.Web.UI.Page
	{
		includeFunctions myincludes = new includeFunctions();
		protected System.Web.UI.WebControls.ImageButton imgbtnLogout;
		Forums_cs.Classes.Search objSearch = null;
		SearchFields objSfields = null;
		clsError objError = null;
		string strQstr = null;
		Regex objRegex=null;
		DataSet dsSearch = null;
		string strId = null;
		protected void Page_Load(object sender, System.EventArgs e)
		{

			if(Request.QueryString["id"]!=null)
			{
				strId = Request.QueryString["id"].ToString();
			}
				if(Request.QueryString["srch"]!=null)
				{
					strQstr = Request.QueryString["srch"].ToString();
					if(strQstr!=null)
					{
						if(filterInput(strQstr))
						{
							if(!IsPostBack)
							{
								BindData();
																	
							}
						}
						else
						{
							pnlNotFound.Visible = true;
							pnlFound.Visible = false;
						}
					}
				}		
			if(Session["Uname"]!=null)
			{
				pnlMiddleLogin.Visible = false;
				pnlMiddleLogout.Visible = true;
				pnlBottomLogout.Visible = true;
				pnlBottomLogin.Visible = false;
				pnlLoginImage.Visible = true;	
				pnluser.Visible = true;
				pnlTopLogin.Visible = false;
				if(Session["Name"]!=null)
				{
					lblUserName.Text = Session["Name"].ToString();
				}
			}

		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    

		}
		#endregion

		protected void lnkbtnBotLogout_click(object sender, System.EventArgs e)
		{
			Session.Abandon();
			
			Response.Redirect("Home.aspx");
		}

		public void BindData()
		{
			try
			{
				dsSearch = new DataSet();
				objError = new clsError();
				objSearch = new Forums_cs.Classes.Search();
				objSfields = new SearchFields();
				if(strId != null)
				{				
					dsSearch = objSearch.SearchMessage(strId,strQstr.Trim(),ref objError);				
				}
				else
				{
					dsSearch = objSearch.SearchMessage(null,strQstr.Trim(),ref objError);				
				}
				if(dsSearch.Tables.Count>0)
				{
					if(dsSearch.Tables[0].Rows.Count>0)
					{
						dgSearch.DataSource = dsSearch;
						dgSearch.DataBind();
						if(dsSearch.Tables[0].Rows.Count > 20)
						{
							dgSearch.AllowPaging = true;
						}
					}
					else
					{
						pnlNotFound.Visible = true;
						pnlFound.Visible = false;
					}
				}
				else
				{
					pnlNotFound.Visible = true;
					pnlFound.Visible = false;
				}
				
			}
			catch(Exception ex)
			{
				lblError.ForeColor = Color.Red;
				lblError.Text = "Error:"+ex.Message.ToString();
			}
		}

		#region Input filtering
		public bool filterInput(string input)
		{
			bool flag=true;
			objRegex=new Regex("[!]|[@]|[#]|[%]|[<]|[>][&]|[\n]|[\t]|[\r]|[:]|[.]|[?]|[&]|[{]|[}]|[/]|[+]|[=]|[\\]|[-]");
			string text="";
			text=objRegex.Replace(input," ").Trim();
			input = text;
			if(input.Trim()=="a" || input.Trim()=="an" || input.Trim()=="," || input.Trim()=="and" || input.Trim()=="" || input.Trim()=="is" || input.Trim()=="to" || input.Trim()=="as" || input.Trim()=="if" || input.Trim()=="for" || input.Trim()=="how")
			{
				flag=false;
				return flag;
			}
				
			return flag;
		}
		#endregion

		protected void dgSearch_ItemDataBound(object sender, System.Web.UI.WebControls.DataGridItemEventArgs e)
		{
			if(e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
			{
				int sublen = 0;
				Label lblPost = (Label)e.Item.FindControl("lblPost");
				lblPost.Text = myincludes.InsertSmiley(lblPost.Text.Trim());
				Label lblSub = (Label)e.Item.FindControl("lblDgSub");
				sublen = lblSub.Text.LastIndexOf("]");
				lblSub.Text = lblSub.Text.Substring(sublen+1,(lblSub.Text.Length)-(sublen+1));
			}
		}

		protected void dgSearch_PageIndexChanged(object source, System.Web.UI.WebControls.DataGridPageChangedEventArgs e)
		{
			dgSearch.CurrentPageIndex = e.NewPageIndex;
			BindData();
		}

		protected void imgbtnSearch_ServerClick(object sender, System.Web.UI.ImageClickEventArgs e)
		{
			Response.Redirect("Search.aspx?srch="+textfield.Value.Trim());
		}

		protected void btnSuccess_Click(object sender, System.EventArgs e)
		{
			Response.Redirect("Home.aspx");
		}

		protected void lnkbtnLogout_Click(object sender, System.EventArgs e)
		{
			Session.Abandon();
			Response.Redirect("Home.aspx");
		}

		protected void lnkbtnSetting_Click(object sender, System.EventArgs e)
		{
			Response.Redirect("MySettings.aspx?uid=Edit");
		}

	}
}
