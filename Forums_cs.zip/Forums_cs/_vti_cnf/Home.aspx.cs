vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|26 May 2006 08:47:48 -0000
vti_extenderversion:SR|5.0.2.5012
vti_lineageid:SR|{DD418848-756D-42DF-BBE8-39D8BB52D03D}
vti_cacheddtm:TX|23 May 2006 14:49:42 -0000
vti_filesize:IR|1040
vti_backlinkinfo:VX|
