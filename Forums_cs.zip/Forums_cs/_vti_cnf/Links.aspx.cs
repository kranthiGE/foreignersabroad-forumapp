vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|26 May 2006 08:14:55 -0000
vti_extenderversion:SR|5.0.2.5012
vti_lineageid:SR|{73014FF4-B16C-49A5-A04F-B53E9BD3306C}
vti_cacheddtm:TX|23 May 2006 14:50:12 -0000
vti_filesize:IR|1042
vti_backlinkinfo:VX|
