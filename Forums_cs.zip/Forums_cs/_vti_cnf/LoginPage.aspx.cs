vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|26 May 2006 08:47:25 -0000
vti_extenderversion:SR|5.0.2.5012
vti_lineageid:SR|{DF65A347-8762-4A1F-9D7C-697BEA7E6120}
vti_cacheddtm:TX|24 May 2006 14:56:26 -0000
vti_filesize:IR|6035
vti_backlinkinfo:VX|
