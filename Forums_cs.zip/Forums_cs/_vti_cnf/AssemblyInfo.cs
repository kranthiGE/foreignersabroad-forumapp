vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|20 May 2006 13:15:44 -0000
vti_extenderversion:SR|5.0.2.5012
vti_lineageid:SR|{A81B5EED-A993-42A1-9F0C-4F39F5777A52}
vti_cacheddtm:TX|20 May 2006 13:15:44 -0000
vti_filesize:IR|2781
vti_backlinkinfo:VX|
