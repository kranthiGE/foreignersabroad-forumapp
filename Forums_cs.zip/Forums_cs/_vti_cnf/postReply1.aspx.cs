vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|26 May 2006 09:56:17 -0000
vti_extenderversion:SR|5.0.2.5012
vti_lineageid:SR|{135CC2B9-68A1-4529-B8F4-B6B93BC8F43F}
vti_cacheddtm:TX|24 May 2006 14:38:34 -0000
vti_filesize:IR|9648
vti_backlinkinfo:VX|
