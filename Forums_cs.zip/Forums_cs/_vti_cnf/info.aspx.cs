vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|23 May 2006 14:49:58 -0000
vti_extenderversion:SR|5.0.2.5012
vti_lineageid:SR|{2BA5B6E4-F101-466B-A46E-EB7B83E099BC}
vti_cacheddtm:TX|23 May 2006 14:49:58 -0000
vti_filesize:IR|1040
vti_backlinkinfo:VX|
