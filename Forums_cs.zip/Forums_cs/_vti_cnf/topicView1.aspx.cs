vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|26 May 2006 08:48:27 -0000
vti_extenderversion:SR|5.0.2.5012
vti_lineageid:SR|{0A8F80E0-1C3A-4350-989F-E191F1C7F7DD}
vti_cacheddtm:TX|23 May 2006 11:15:31 -0000
vti_filesize:IR|5525
vti_backlinkinfo:VX|
