vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|26 May 2006 08:46:39 -0000
vti_extenderversion:SR|5.0.2.5012
vti_lineageid:SR|{318CB8C4-F2E2-4276-A14B-34031B01D158}
vti_cacheddtm:TX|23 May 2006 11:18:24 -0000
vti_filesize:IR|5372
vti_backlinkinfo:VX|
