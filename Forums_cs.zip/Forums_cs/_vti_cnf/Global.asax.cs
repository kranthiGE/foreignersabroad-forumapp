vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|20 May 2006 13:15:44 -0000
vti_extenderversion:SR|5.0.2.5012
vti_lineageid:SR|{C399DDE5-620B-487C-AAE0-48462BC57777}
vti_cacheddtm:TX|20 May 2006 13:15:44 -0000
vti_filesize:IR|1446
vti_backlinkinfo:VX|
