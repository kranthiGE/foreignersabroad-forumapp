vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|26 May 2006 08:48:28 -0000
vti_extenderversion:SR|5.0.2.5012
vti_lineageid:SR|{99FFBE88-B2A5-4587-9062-E1C99F5FFAA8}
vti_cacheddtm:TX|24 May 2006 14:38:13 -0000
vti_filesize:IR|4187
vti_backlinkinfo:VX|
