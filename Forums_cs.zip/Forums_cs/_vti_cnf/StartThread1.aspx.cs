vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|26 May 2006 08:47:02 -0000
vti_extenderversion:SR|5.0.2.5012
vti_lineageid:SR|{0F562143-F364-48EB-92F4-2E4B30EA13A0}
vti_cacheddtm:TX|24 May 2006 15:00:15 -0000
vti_filesize:IR|5566
vti_backlinkinfo:VX|
