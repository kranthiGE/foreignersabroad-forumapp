using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using Forums_cs.Classes;

namespace Forums_cs
{
	/// <summary>
	/// Summary description for ContactUs.
	/// </summary>
	public partial class ContactUs : System.Web.UI.Page
	{
		protected System.Web.UI.HtmlControls.HtmlGenericControl form1;
		User objUser = null;
		clsError objError = null;
		protected void Page_Load(object sender, System.EventArgs e)
		{
			if(Session["Uname"]!=null)
			{
				pnlTopLogin.Visible = false;
				pnlLoginImage.Visible = true;
				pnlBottomLogout.Visible = true;
				pnlBottomLogin.Visible = false;
			}
			btnSubmit.Attributes["onclick"] = "javascript:return valid()";
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    

		}
		#endregion

		protected void lnkbtnSetting_Click(object sender, System.EventArgs e)
		{
			Response.Redirect("MySettings.aspx?uid=Edit");
		}

		protected void lnkbtnLogout_Click(object sender, System.EventArgs e)
		{
			Session.Abandon();
			pnlTopLogin.Visible = true;			
			pnlLoginImage.Visible = false;
			pnluser.Visible = false;
			Response.Redirect("Home.aspx");
		}

		protected void lnkbtnBotLogout_click(object sender, System.EventArgs e)
		{
			Session.Abandon();
			
			Response.Redirect("Home.aspx");
		}
		protected void btnSubmit_Click(object sender, System.EventArgs e)
		{
			objUser = new User();
			objError = new clsError();
			if(objUser.ContactUsSubmit(txtBoxName.Text.Trim(),txtBoxEmail.Text,txtBoxPh.Text,txtBoxSub.Text,txtBoxMsg.Text,ref objError))
			{
				Response.Redirect("Home.aspx");
			}			
			
		}
		
	}
}
