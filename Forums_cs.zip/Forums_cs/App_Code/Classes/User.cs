using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;

namespace Forums_cs.Classes
{
	/// <summary>
	/// Summary description for User.
	/// </summary>
	public class User
	{
		DataSet dsCats = null;
		string strQry = null;
		ArrayList alist = null;
		DataSet ds = null;
		Register objReg = null;
		SqlCommand cmd = null;
		SqlDataReader dr = null;
		SqlConnection connect = null;
		SqlDataAdapter da1 = null;
		SqlDataAdapter da2 = null;
		SqlDataAdapter da3 = null;
		Random objRnd = null;
		int result = 0;
		public User()
		{
			connect = new SqlConnection(ConfigurationSettings.AppSettings["forumDSN"]);
		}
		public bool CheckPwd(string Uname,string Pwd,ref clsError objError)
		{
			bool flag = false;
			try
			{		
				objReg = new Register();
				string strPwd = objReg.Encrypt(Pwd,ref objError);
				strQry = "select * from users where Pwd = '"+strPwd+"' and Email = '"+Uname+"'";
				cmd = new SqlCommand(strQry,connect);
				connect.Open();
				dr = cmd.ExecuteReader();
				if(dr.Read())
				{
					flag = true;
				}
				connect.Close();
			}
			catch(Exception ex)
			{
				objError.boolErrorOccurred = true;
				objError.strMessage = "Error:"+ex.Message.ToString();				
			}
			return flag;
		}
		public void UpdateUserInfo(ref Login objLogin,bool flag,ref clsError objError)
		{
			try
			{
				if(flag)
				{
					objReg = new Register();
					objLogin.NewPwd = objReg.Encrypt(objLogin.NewPwd,ref objError);
					if(objLogin.ImgPath != null)
					{
						strQry = "update users set fname = '"+objLogin.Fname+"' ,pwd = '"+objLogin.NewPwd+"', city = '"+objLogin.City+"', imgpath = '"+objLogin.ImgPath+"', Pvtcnt = '"+objLogin.PvtCnt+"', state = '"+objLogin.State+"', country = '"+objLogin.Country+"', flagpath = '"+objLogin.FlagPath+"', Nationality = '"+objLogin.Nation+"', abtmyself = '"+objLogin.AbtMyself+"'  where Email = '"+objLogin.Uname+"' and roleid = 2";
					}
					else
					{
						strQry = "update users set fname = '"+objLogin.Fname+"' ,pwd = '"+objLogin.NewPwd+"', city = '"+objLogin.City+"', Pvtcnt = '"+objLogin.PvtCnt+"', state = '"+objLogin.State+"', country = '"+objLogin.Country+"', flagpath = '"+objLogin.FlagPath+"', Nationality = '"+objLogin.Nation+"', abtmyself = '"+objLogin.AbtMyself+"' where Email = '"+objLogin.Uname+"' and roleid = 2";
					}
				}
				else
				{
					if(objLogin.ImgPath != null)
					{
						strQry = "update users set fname = '"+objLogin.Fname+"' , city = '"+objLogin.City+"', imgpath = '"+objLogin.ImgPath+"', Pvtcnt = '"+objLogin.PvtCnt+"', state = '"+objLogin.State+"', country = '"+objLogin.Country+"', flagpath = '"+objLogin.FlagPath+"', Nationality = '"+objLogin.Nation+"', abtmyself = '"+objLogin.AbtMyself+"' where Email = '"+objLogin.Uname+"' and roleid = 2";
					}
					else
					{
						strQry = "update users set fname = '"+objLogin.Fname+"' , city = '"+objLogin.City+"', Pvtcnt = '"+objLogin.PvtCnt+"', state = '"+objLogin.State+"', country = '"+objLogin.Country+"', flagpath = '"+objLogin.FlagPath+"', Nationality = '"+objLogin.Nation+"', abtmyself = '"+objLogin.AbtMyself+"' where Email = '"+objLogin.Uname+"' and roleid = 2";
					}
				}
				cmd = new SqlCommand(strQry,connect);
				connect.Open();
				result = cmd.ExecuteNonQuery();
				connect.Close();
				if(result>0)
				{
					objError.strMessage = "Successfully Updated";
				}
				else
				{
					objError.boolErrorOccurred = true;
					objError.strMessage = "could not Update";
				}
			}
			catch(Exception ex)
			{
				objError.boolErrorOccurred = true;
				objError.strMessage = "Error:"+ex.Message.ToString();				
			}
		}
		public ArrayList getuserInfo(string uid,ref clsError objError)
		{
			try
			{
				alist = new ArrayList();
				strQry = "select * from users where Email = '"+uid+"' and roleid = 2";
				cmd = new SqlCommand(strQry,connect);
				connect.Open();
				dr = cmd.ExecuteReader();
				while(dr.Read())
				{
					alist.Add(dr["Email"]);
					alist.Add(dr["Pwd"]);
					alist.Add(dr["Fname"]);
					alist.Add(dr["Location"]);	
					alist.Add(dr["Pvtcnt"]);
					alist.Add(dr["imgpath"]);	
					alist.Add(dr["country"]);	
					alist.Add(dr["state"]);	
					alist.Add(dr["Nationality"]);
					alist.Add(dr["abtmyself"]);
					alist.Add(dr["City"]);
				}
				connect.Close();
			}
			catch(Exception ex)
			{
				objError.boolErrorOccurred = true;
				objError.strMessage = "Error:"+ex.Message.ToString();				
			}
			return alist;
		}
		public string GetID(string Pid,string strQry,ref clsError objError)
		{
			clsItemUploadFileMgr objItempload= new clsItemUploadFileMgr();
			objRnd = new Random();			
			CreateID:
				string Id = null;
			int rndNo = 0;
			try
			{
				rndNo = objRnd.Next(100,1000);
				Pid = Pid+rndNo.ToString();
				strQry = strQry + "'"+Pid+"'";
				if(objItempload.CheckExistence(strQry,ref objError)==false)
				{
					Id = Pid;
					rndNo = 0;
					Pid = null;
					strQry = null;
				}
				else
				{
					goto CreateID;
				}
				
			}
			catch(Exception ex)
			{
				objError.boolErrorOccurred = true;
				objError.strMessage = "Error:"+ex.Message.ToString();
			}

			return Id;
		}

		public string GetThreadId(string strQry,ref clsError objError)
		{
			string Pid = null;
			clsItemUploadFileMgr objItempload= new clsItemUploadFileMgr();
			objRnd = new Random();			
			CreateID:
				string Id = null;
			int rndNo = 0;
			try
			{
				rndNo = objRnd.Next(Convert.ToInt16(ConfigurationSettings.AppSettings["TMin"]),Convert.ToInt16(ConfigurationSettings.AppSettings["TMax"]));
				Pid = rndNo.ToString();
				strQry = strQry + "'"+Pid+"'";
				if(objItempload.CheckExistence(strQry,ref objError)==false)
				{
					Id = Pid;
					rndNo = 0;
					Pid = null;
					strQry = null;
				}
				else
				{
					goto CreateID;
				}
				
			}
			catch(Exception ex)
			{
				objError.boolErrorOccurred = true;
				objError.strMessage = "Error:"+ex.Message.ToString();
			}

			return Id;
		}

		public DataSet GetUserProfile(string strUname,ref clsError objError)
		{
			ds = new DataSet();
			try
			{
				strQry = "select typename from countriesvisited C join threadtype T on C.cntryid = T.Typeid where C.userid = '"+strUname+"'";
				da1 = new SqlDataAdapter(strQry,connect);
				da1.Fill(ds,"additional");				
				strQry = "select email,country,fname,joindate,flagpath,count(psid) as Postcount, Pvtcnt, imgpath from users U join forumthreads F on U.email = F.psEmail where U.Email = '"+strUname+"' group by email,country,fname,joindate, Pvtcnt, imgpath,flagpath";
				da2 = new SqlDataAdapter(strQry,connect);
				da2.Fill(ds,"users");
				strQry = "select Nationality,city,state,abtmyself from users where email = '"+strUname+"'";
				da3 = new SqlDataAdapter(strQry,connect);
				da3.Fill(ds,"nation");
			}
			catch(Exception ex)
			{
				objError.boolErrorOccurred = true;
				objError.strMessage = "Error:"+ex.Message.ToString();
			}
			return ds;
		}

		public DataSet GetCats(ref clsError objError)
		{
			try
			{
				dsCats = new DataSet();
				//strQry = "select bcId,upper(substring(bctitle, 1,1)) + lower(substring(bctitle,2,len(bctitle)-1)) as bcTitle  from forumtopics where parentid is null";
				strQry = "select bcId, bcTitle  from forumtopics where parentid is null and TopicType = 'A' order by bctitle";
				da1 = new SqlDataAdapter(strQry,connect);
				da1.Fill(dsCats);
			}
			catch(Exception ex)
			{
				objError.boolErrorOccurred = true;
				objError.strMessage = "Error:"+ex.Message.ToString();
			}			
			return dsCats;
		}

		public DataSet GetStates(string strParentid,ref clsError objError)
		{
			try
			{
				dsCats = new DataSet();
				strQry = "select bcId, bcTitle  from forumtopics where parentid = "+strParentid+" and TopicType = 'A' order by bctitle";
				da1 = new SqlDataAdapter(strQry,connect);
				da1.Fill(dsCats);
			}
			catch(Exception ex)
			{
				objError.boolErrorOccurred = true;
				objError.strMessage = "Error:"+ex.Message.ToString();
			}			
			return dsCats;
		}
		
		public DataSet GetSelectedCts(string Uname,ref clsError objError)
		{
			try
			{
				dsCats = new DataSet();
				strQry = "select upper(substring(typename, 1,1)) + lower(substring(typename,2,len(typename)-1)) as Typename, cntryid from countriesvisited C join threadtype T on C.cntryid = T.Typeid where C.userid = '"+Uname+"'";
				da1 = new SqlDataAdapter(strQry,connect);
				da1.Fill(dsCats);
			}
			catch(Exception ex)
			{
				objError.boolErrorOccurred = true;
				objError.strMessage = "Error:"+ex.Message.ToString();
			}
			return dsCats;
		}

		public void RemoveCts(string strUname,string ctsId,ref clsError objError)
		{
			try
			{
				strQry = "delete from countriesvisited where userid = '"+strUname+"' and cntryid = '"+ctsId+"'";
				cmd = new SqlCommand(strQry,connect);
				connect.Open();
				result = cmd.ExecuteNonQuery();
				if(result>0)
				{
					objError.strMessage = "Removed Successfully";
				}
				else
				{
					objError.boolErrorOccurred = true;
					objError.strMessage = "Error:Deletion failed";
				}
                connect.Close();
			}
			catch(Exception ex)
			{
				objError.boolErrorOccurred = true;
				objError.strMessage = "Error:"+ex.Message.ToString();
			}						
		}

		public void InsertCts(string strUname,string ctsId,ref clsError objError)
		{
			try
			{
				if(!CheckExist(strUname,ctsId,ref objError))
				{
					strQry = "insert into countriesvisited values('"+strUname+"','"+ctsId+"')";
					cmd = new SqlCommand(strQry,connect);
					connect.Open();
					result = cmd.ExecuteNonQuery();
					if(result>0)
					{
						
						objError.strMessage = "inserted Successfully";
					}
					else
					{
						objError.boolErrorOccurred = true;
						objError.strMessage = "Error:Insertion failed";
					}
					connect.Close();
				}
				else
				{
					objError.boolErrorOccurred = true;
					objError.strMessage = "Error:Country already existing";
				}
			}
			catch(Exception ex)
			{
				objError.boolErrorOccurred = true;
				objError.strMessage = "Error:"+ex.Message.ToString();
			}						
		}

		public bool CheckExist(string Uname,string cntryid,ref clsError objError)
		{
			bool flag = false;
			try
			{			
				objError = new clsError();				
				
				strQry = "select cntryid from countriesvisited where userid = '"+Uname+"' and cntryid = '"+cntryid+"'";
				connect.Open();
				cmd = new SqlCommand(strQry,connect);
				dr = cmd.ExecuteReader();
				if(dr.Read())
				{
					flag = true;
				}
				connect.Close();
				dr.Close();			
			}
			catch(Exception ex)
			{	
				objError.boolErrorOccurred = true;
				objError.strMessage = "Error:"+ex.Message.ToString();
			}
			return flag;
		}
		
		#region   INFORMATION  CENTER
			
		public DataSet getTop5Cats()
		{
			ds = new DataSet();
			strQry = "select top 3(FC.bcID) as bcId,count(psrelbcid) as cnt from forumtopics FC join forumthreads FT on FT.psrelbcid = FC.bcid where datediff(day,bcLastUpdate,getdate()) < 30 group by FC.bcID order by count(psrelbcid) desc";
			da1 = new SqlDataAdapter(strQry,connect);
			da1.Fill(ds);
			return ds;
		}

		public DataSet getTop5Threads()
		{
			ds = new DataSet();
			strQry = "SELECT  top 3(bcId),Left(bcTitle, 100) As bcTitle, psId, bcLastUpdate as bcLastUpdate,pssubject, FT.pspost FROM forumTopics FC join forumthreads FT on FT.psrelbcid = FC.bcID where psreltopid='0' ORDER BY bcLastUpdate DESC";
			da1 = new SqlDataAdapter(strQry,connect);
			da1.Fill(ds);
			return ds;
		}

		public string UsersOnline()
		{
			string strOnline = null;
			strQry = "";

			return strOnline;
		}

		public string GetUserRegistered()
		{
			string strUserCnt = null;
			strQry = "select count(*) from users where isactive = 1 and roleId = 2";
			cmd = new SqlCommand(strQry,connect);
			connect.Open();
			strUserCnt = cmd.ExecuteScalar().ToString();
			connect.Close();
			return strUserCnt;
		}

		public string GetTotalThreadCnt()
		{
			string strThreadCnt = null;
			strQry = "select count(*) from forumthreads";
			cmd = new SqlCommand(strQry,connect);
			connect.Open();
			strThreadCnt = cmd.ExecuteScalar().ToString();
			connect.Close();
			return strThreadCnt;
		}

		#endregion


		public string GetFavIds(string strUname, ref clsError objError)
		{
			string strFavid = null;
			try
			{
				strQry = "select Favid from Myfav where Uname = '"+strUname+"'";
				cmd = new SqlCommand(strQry,connect);
				connect.Open();
				dr = cmd.ExecuteReader();
				while(dr.Read())
				{
					strFavid += "'"+dr["Favid"].ToString()+"'"+",";
				}			
				if(strFavid != null)
				{
					strFavid = strFavid.Substring(0,(strFavid.Length)-1);
				}
			}
			catch(Exception ex)
			{
				objError.boolErrorOccurred = true;
				objError.strMessage = "Error:"+ex.Message.ToString();
			}
			finally
			{
				dr.Close();
				connect.Close();
			}
			return strFavid;
		}

		public void AddFav(string strUname, string strId, ref clsError objError)
		{
			
			try
			{
				strQry = "insert into Myfav(Uname,Favid) values('"+strUname+"','"+strId+"')";
				cmd = new SqlCommand(strQry,connect);
				connect.Open();
				result = cmd.ExecuteNonQuery();
				if(result > 0)
				{
					objError.strMessage = "Successfully added to Favourites";
				}
				else
				{
					objError.boolErrorOccurred = true;
				}
			}
			catch(Exception ex)
			{
				objError.boolErrorOccurred = true;
				objError.strMessage = "Error:"+ex.Message.ToString();
			}
			finally
			{
			
				connect.Close();
			}
		}

		public void RemoveFav(string strUname, string strId, ref clsError objError)
		{
			try
			{
				strQry = "delete from Myfav where Uname = '"+strUname+"' and Favid='"+strId+"'";
				cmd = new SqlCommand(strQry,connect);
				connect.Open();
				result = cmd.ExecuteNonQuery();
				if(result > 0)
				{
					objError.strMessage = "Successfully deleted from Favourites";
				}
			}
			catch(Exception ex)
			{
				objError.boolErrorOccurred = true;
				objError.strMessage = "Error:"+ex.Message.ToString();
			}
			finally
			{
				
				connect.Close();
			}
		}

		public bool IsMyFav(string strUname, string strId,ref clsError objError)
		{		
			bool flag = false;
			try
			{
				strQry = "select * from Myfav where Uname = '"+strUname+"' and Favid='"+strId+"'";
				cmd = new SqlCommand(strQry,connect);
				connect.Open();
				dr = cmd.ExecuteReader();
				if(dr.Read())
				{
					flag = true;
				}
			}
			catch(Exception ex)
			{
				objError.boolErrorOccurred = true;
				objError.strMessage = "Error:"+ex.Message.ToString();
			}
			finally
			{
				connect.Close();
			}
			return flag;
		}
		public bool IsMyFav(string strUname,ref clsError objError)
		{		
			bool flag = false;
			try
			{
				strQry = "select * from Myfav where Uname = '"+strUname+"'";
				cmd = new SqlCommand(strQry,connect);
				connect.Open();
				dr = cmd.ExecuteReader();
				if(dr.Read())
				{
					flag = true;
				}
			}
			catch(Exception ex)
			{
				objError.boolErrorOccurred = true;
				objError.strMessage = "Error:"+ex.Message.ToString();
			}
			finally
			{
				connect.Close();
			}
			return flag;
		}

		public bool ContactUsSubmit(string name,string email,string phone,string sub,string Msg,ref clsError objError)
		{
			bool flag = false;
			try
			{
				strQry = "insert into contactUs(name,email,phone,sub,msg) values('"+name+"','"+email+"','"+phone+"','"+sub+"','"+Msg+"')";
				cmd = new SqlCommand(strQry,connect);
				connect.Open();
				result = cmd.ExecuteNonQuery();
				if(result > 0)
				{
					flag = true;
				}
			}
			catch(Exception ex)
			{
				objError.boolErrorOccurred = true;
				objError.strMessage = "Error:"+ex.Message.ToString();
			}
			finally
			{
				connect.Close();
			}
			return flag;
		}
	}
}
