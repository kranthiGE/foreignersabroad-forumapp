using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Text.RegularExpressions;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using Forums_cs;
using Forums_cs.Classes;
namespace dotForumIncludes
{

	public class includeFunctions
	{
		public string strSmileyText = null;		
		SqlDataReader dr = null;
		public object RemoveQuote(string SQLString)
		{
			SQLString = Regex.Replace(SQLString, "'", "''");
			return SQLString;
		}

		public object RemoveHTMLQuote(string SQLString)
		{
			SQLString = Regex.Replace(SQLString, "'", "''");
			SQLString = Regex.Replace(SQLString, "<[^>]*>", "");
			SQLString = Regex.Replace(SQLString, System.Environment.NewLine, "<br>");
			SQLString = SQLString.Replace("<br>","");
			return SQLString;
		}

		public object countReplies(int thisId)
		{
			SqlConnection myConnection = new SqlConnection(ConfigurationSettings.AppSettings["forumDSN"]);
			SqlCommand myCommand = new SqlCommand("SELECT COUNT(*) FROM forumThreads WHERE psRelTopId = " + thisId, myConnection);

			myConnection.Open();
			int totalRecords = Convert.ToInt16(myCommand.ExecuteScalar());
			myConnection.Close();

			return totalRecords;

		}


		public object countRepliesLink(int thisId)
		{
			SqlConnection myConnection = new SqlConnection(ConfigurationSettings.AppSettings["forumDSN"]);
			SqlCommand myCommand = new SqlCommand("SELECT COUNT(*) FROM forumThreads WHERE psRelTopId = " + thisId, myConnection);

			myConnection.Open();
			int totalRecords = Convert.ToInt16(myCommand.ExecuteScalar());
			myConnection.Close();

			object returnStr = null;
			if (totalRecords > 0)
			{
				returnStr = "<a class=\"listItemLink\" href=\"reply.aspx?id=" + thisId + "\">" + totalRecords + "</a>";
			}
			else
			{
				returnStr = totalRecords;
			}

			return returnStr;

		}


		public string getTopicName(string thisId)
		{
			string thisTopic = null;
			
			SqlConnection myConnection = new SqlConnection(ConfigurationSettings.AppSettings["forumDSN"]);
			SqlCommand myCommand = new SqlCommand("SELECT LEFT(bcTitle, 60) As bcTitle FROM forumTopics WHERE bcId = '" + thisId+"'", myConnection);
				
			myConnection.Open();
			dr = myCommand.ExecuteReader();
			if(dr.Read())
			{	
				thisTopic = dr["bcTitle"].ToString();
			}
			else
			{
				thisTopic = "";
			}
				
			myConnection.Close();

			
			return thisTopic;
		}


		public object getThreadSubject(string thisId)
		{
			SqlConnection myConnection = new SqlConnection(ConfigurationSettings.AppSettings["forumDSN"]);
			SqlCommand myCommand = new SqlCommand("SELECT LEFT(psSubject, 60) As psSubject FROM forumThreads WHERE psId = '"+thisId+"'", myConnection);

			myConnection.Open();
			string thisThread = myCommand.ExecuteScalar().ToString();
			myConnection.Close();

			return thisThread;
		}

		



		public object countThreads(int thisId)
		{
			SqlConnection myConnection = new SqlConnection(ConfigurationSettings.AppSettings["forumDSN"]);
			SqlCommand myCommand = new SqlCommand("SELECT COUNT(*) FROM forumThreads WHERE psRelBcId = " + thisId, myConnection);

			myConnection.Open();
			int totalRecords = Convert.ToInt16(myCommand.ExecuteScalar());
			myConnection.Close();

			return totalRecords;

		}

		public object countAdminThreadsLink(int thisId)
		{
			SqlConnection myConnection = new SqlConnection(ConfigurationSettings.AppSettings["forumDSN"]);
			SqlCommand myCommand = new SqlCommand("SELECT COUNT(*) FROM forumThreads WHERE psRelTopId = 0 AND psRelBcId = " + thisId, myConnection);

			myConnection.Open();
			int totalRecords = Convert.ToInt16(myCommand.ExecuteScalar());
			myConnection.Close();

			object returnStr = null;
			if (totalRecords > 0)
			{
				returnStr = "<a class=\"listItemLink\" href=\"thread.aspx?id=" + thisId + "\">" + totalRecords + "</a>";
			}
			else
			{
				returnStr = totalRecords;
			}

			return returnStr;

		}


		public object countTopThreads(string thisId)
		{
			SqlConnection myConnection = new SqlConnection(ConfigurationSettings.AppSettings["forumDSN"]);
			SqlCommand myCommand = new SqlCommand("SELECT COUNT(*) FROM forumThreads WHERE psRelTopId = 0 AND psRelBcId = '"+thisId+"'", myConnection);

			myConnection.Open();
			int totalRecords = Convert.ToInt16(myCommand.ExecuteScalar());
			myConnection.Close();

			return totalRecords;

		}


		public object countTopReplies(string thisId)
		{
			SqlConnection myConnection = new SqlConnection(ConfigurationSettings.AppSettings["forumDSN"]);
			SqlCommand myCommand = new SqlCommand("SELECT COUNT(*) FROM forumThreads WHERE psRelTopId <> 0 AND psRelBcId = '"+thisId+"'", myConnection);

			myConnection.Open();
			int totalRecords = Convert.ToInt16(myCommand.ExecuteScalar());
			myConnection.Close();

			return totalRecords;

		}


		public object getLastPosterByTopic(int topicId)
		{
			SqlConnection myConnection = new SqlConnection(ConfigurationSettings.AppSettings["forumDSN"]);
			SqlCommand myCommand = new SqlCommand("SELECT TOP 1 psId, psRelTopId, psPost, psName FROM forumThreads WHERE psRelBcId = " + topicId + " ORDER BY psDate DESC", myConnection);

			myConnection.Open();

			SqlDataReader myReader = null;
			myReader = myCommand.ExecuteReader();

			int thisId = 0;
			int thisTopId = 0;
			string thisName = "";
			int thisnameLen = 0;
			while (myReader.Read())
			{
				thisId = Convert.ToInt16(myReader["psId"]);
				thisTopId = Convert.ToInt16(myReader["psRelTopId"]);
				thisName = myReader["psPost"].ToString();
			}
			myReader.Close();
			myConnection.Close();

			if (thisName == "")
			{
				thisName = "<font class=\"labelNew\">New!</font>";
			}
			else
			{
				thisnameLen = thisName.Length;
				if(thisnameLen > 6)
				{
					thisName = thisName.Substring(0,7) + ".....";
				
					if (thisTopId != 0)
					{
						//### GENERATE LINK TO LAST REPLY
						thisName = "<a class=\"lastPostLink\" href=\"threadView.aspx?id=" + thisTopId + "\">" + thisName + "</a>";
					}
					else
					{
						//### GENERATE LINK TO LAST THREAD
						thisName = "<a class=\"lastPostLink\" href=\"topicView.aspx?id=" + topicId + "\">" + thisName + "</a>";
					}
				}
			}


			return thisName;
		}
		



		public object getLastPosterByThread(int threadId)
		{
			SqlDataReader dr = null;
			string thisName = null;
			SqlConnection myConnection = new SqlConnection(ConfigurationSettings.AppSettings["forumDSN"]);
			SqlCommand myCommand = new SqlCommand("SELECT TOP 1 psName FROM forumThreads WHERE psRelTopId = " + threadId + " ORDER BY psDate DESC", myConnection);

			myConnection.Open();
			dr = myCommand.ExecuteReader();
			if(dr.Read())
			{
				thisName = dr[0].ToString();
			}				
			myConnection.Close();

			if (thisName == null)
			{
				thisName = "<font class=\"labelNew\">No Replies</font>";
			}
			return thisName;
		}

		public object getFLagPath(string strEmail)
		{
			string flagpath = null;
			try
			{
				SqlDataReader dr = null;				
				SqlConnection myConnection = new SqlConnection(ConfigurationSettings.AppSettings["forumDSN"]);
				SqlCommand myCommand = new SqlCommand("select flagpath from users where email = '"+strEmail+"'", myConnection);
				myConnection.Open();
				dr = myCommand.ExecuteReader();
				if(dr.Read())
				{
					flagpath = dr["flagpath"].ToString();
					if(flagpath == "--Select Country--")
					{
						flagpath = "";
					}
				}				
				else
				{
					flagpath = "";
				}
			}
			catch(Exception ex)
			{

			}
			return flagpath;
		}


		public string InsertSmiley(string strText)
		{
			strText = strText.Replace(":-D","<img src='fa_images/Smileys/smiley_biggrin.gif'></img>");			 
			strText = strText.Replace(":confused:","<img src='fa_images/Smileys/smiley_confused.gif'></img>");
			strText = strText.Replace(":cool:","<img src='fa_images/Smileys/smiley_cool.gif'></img>");
			strText = strText.Replace(":((","<img src='fa_images/Smileys/smiley_cry.gif'></img>");
			strText = strText.Replace("X|","<img src='fa_images/Smileys/smiley_dead.gif'></img>");
			strText = strText.Replace(":eek:","<img src='fa_images/Smileys/smiley_eek.gif'></img>");
			strText = strText.Replace(":(","<img src='fa_images/Smileys/smiley_frown.gif'></img>");
			strText = strText.Replace(":laugh:","<img src='fa_images/Smileys/smiley_laugh.gif'></img>");
			strText = strText.Replace(":)","<img src='fa_images/Smileys/smiley_smile.gif'></img>");
			strText = strText.Replace(";)","<img src='fa_images/Smileys/smiley_wink.gif'></img>");
			strText = strText.Replace(";P","<img src='fa_images/Smileys/smiley_tongue.gif'></img>");
			strText = strText.Replace(":-O","<img src='fa_images/Smileys/smiley_redface.gif'></img>");
			strText = strText.Replace(":rolleyes:","<img src='fa_images/Smileys/smiley_rolleyes.gif'></img>");
			strText = strText.Replace(":mad:","<img src='fa_images/Smileys/smiley_mad.gif'></img>");
			strText = strText.Replace(":|","<img src='fa_images/Smileys/smiley_line.gif'></img>");
			strText = strText.Replace(":suss:","<img src='fa_images/Smileys/smiley_suss.gif'></img>");
		

			return strText;
		}

		public string InsertHomeSmiley(string strText)
		{
			
			if(strText.IndexOf(":-D") != -1)
			{
				strText = strText.Replace(":-D","");
				strSmileyText += "<img src='fa_images/Smileys/smiley_biggrin.gif'></img>";
			}
			if(strText.IndexOf(":confused:") != -1)
			{
				strText = strText.Replace(":confused:","");
				strSmileyText += "<img src='fa_images/Smileys/smiley_confused.gif'></img>";
			}
			if(strText.IndexOf(":cool:") != -1)
			{
				strText = strText.Replace(":cool:","");
				strSmileyText += "<img src='fa_images/Smileys/smiley_cool.gif'></img>";
			}
			if(strText.IndexOf(":((") != -1)
			{
				strText = strText.Replace(":((","");
				strSmileyText += "<img src='fa_images/Smileys/smiley_cry.gif'></img>";
			}
			if(strText.IndexOf("X|") != -1)
			{
				strText = strText.Replace("X|","");
				strSmileyText += "<img src='fa_images/Smileys/smiley_dead.gif'></img>";
			}
			if(strText.IndexOf(":eek:") != -1)
			{
				strText = strText.Replace(":eek:","");
				strSmileyText += "<img src='fa_images/Smileys/smiley_eek.gif'></img>";
			}
			if(strText.IndexOf(":(") != -1)
			{
				strText = strText.Replace(":(","");
				strSmileyText += "<img src='fa_images/Smileys/smiley_frown.gif'></img>";
			}
			if(strText.IndexOf(":laugh:") != -1)
			{
				strText = strText.Replace(":laugh:","");
				strSmileyText += "<img src='fa_images/Smileys/smiley_laugh.gif'></img>";
			}
			if(strText.IndexOf(":)") != -1)
			{
				strText = strText.Replace(":)","");
				strSmileyText += "<img src='fa_images/Smileys/smiley_smile.gif'></img>";
			}
			if(strText.IndexOf(";)") != -1)
			{
				strText = strText.Replace(";)","");
				strSmileyText += "<img src='fa_images/Smileys/smiley_wink.gif'></img>";
			}
			if(strText.IndexOf(";P") != -1)
			{
				strText = strText.Replace(";P","");
				strSmileyText += "<img src='fa_images/Smileys/smiley_tongue.gif'></img>";
			}
			if(strText.IndexOf(":-O") != -1)
			{
				strText = strText.Replace(":-O","");
				strSmileyText += "<img src='fa_images/Smileys/smiley_redface.gif'></img>";
			}
			if(strText.IndexOf(":rolleyes:") != -1)
			{
				strText = strText.Replace(":rolleyes:","");
				strSmileyText += "<img src='fa_images/Smileys/smiley_rolleyes.gif'></img>";
			}
			if(strText.IndexOf(":mad:") != -1)
			{
				strText = strText.Replace(":mad:","");
				strSmileyText += "<img src='fa_images/Smileys/smiley_mad.gif'></img>";
			}
			if(strText.IndexOf(":|") != -1)
			{
				strText = strText.Replace(":|","");
				strSmileyText += "<img src='fa_images/Smileys/smiley_line.gif'></img>";
			}
			if(strText.IndexOf(":suss:") != -1)
			{
				strText = strText.Replace(":suss:","");
				strSmileyText += "<img src='fa_images/Smileys/smiley_suss.gif'></img>";
			}
			return strText;
		}

		public string InsertSmiley_Domain(string strText)
		{
			string strDomain = ConfigurationSettings.AppSettings["DomainName"];
			strText = strText.Replace(":-D","<img src='"+strDomain+"/fa_images/Smileys/smiley_biggrin.gif'></img>");			 
			strText = strText.Replace(":confused:","<img src='"+strDomain+"/fa_images/Smileys/smiley_confused.gif'></img>");
			strText = strText.Replace(":cool:","<img src='"+strDomain+"/fa_images/Smileys/smiley_cool.gif'></img>");
			strText = strText.Replace(":((","<img src='"+strDomain+"/fa_images/Smileys/smiley_cry.gif'></img>");
			strText = strText.Replace("X|","<img src='"+strDomain+"/fa_images/Smileys/smiley_dead.gif'></img>");
			strText = strText.Replace(":eek:","<img src='"+strDomain+"/fa_images/Smileys/smiley_eek.gif'></img>");
			strText = strText.Replace(":(","<img src='"+strDomain+"/fa_images/Smileys/smiley_frown.gif'></img>");
			strText = strText.Replace(":laugh:","<img src='"+strDomain+"/fa_images/Smileys/smiley_laugh.gif'></img>");
			strText = strText.Replace(":)","<img src='"+strDomain+"/fa_images/Smileys/smiley_smile.gif'></img>");
			strText = strText.Replace(";)","<img src='"+strDomain+"/fa_images/Smileys/smiley_wink.gif'></img>");
			strText = strText.Replace(";P","<img src='"+strDomain+"/fa_images/Smileys/smiley_tongue.gif'></img>");
			strText = strText.Replace(":-O","<img src='"+strDomain+"/fa_images/Smileys/smiley_redface.gif'></img>");
			strText = strText.Replace(":rolleyes:","<img src='"+strDomain+"/fa_images/Smileys/smiley_rolleyes.gif'></img>");
			strText = strText.Replace(":mad:","<img src='"+strDomain+"/fa_images/Smileys/smiley_mad.gif'></img>");
			strText = strText.Replace(":|","<img src='"+strDomain+"/fa_images/Smileys/smiley_line.gif'></img>");
			strText = strText.Replace(":suss:","<img src='"+strDomain+"/fa_images/Smileys/smiley_suss.gif'></img>");
		

			return strText;
		}
	}


}