using System;
using System.Web.Mail;
using System.ComponentModel;
using System.Configuration;
using System.Web;
using System.Diagnostics;

namespace Forums_cs.Classes
{
	/// <summary>
	/// Summary description for Sendmail.
	/// </summary>
	public class clsSendmail
	{
		
		public clsSendmail()
		{
			
			mail = null;
			subject = null;
			body = null;
		}	
		private MailMessage mail;
		private string subject;
		private string body;
		/// **************************************************************
		/// <summary>
		/// Sets the Subject of the Mail
		/// </summary>
		/// **************************************************************
		public void SetMailSubject(string subject)
		{
			this.subject = subject;
		}
		/// **************************************************************
		/// <summary>
		/// Sets the Body of the Mail.
		/// </summary>		
		/// **************************************************************
		public void SetMailBody(string body)
		{
			this.body = body;
		}
		/// **************************************************************
		/// <summary>
		/// Sends the mail to the to address from given From Address.		
		/// </summary>		
		/// <param name="mailFrom">From address</param>
		/// <param name="mailTo">To address</param>
		/// <param name="objError">Error object</param>
		/// **************************************************************
		/// 
		public void SendMailTo(string mailFrom, string mailTo,ref clsError objError)
		{
			mail = new MailMessage();
			mail.From = mailFrom;
			mail.Fields["http://schemas.microsoft.com/cdo/configuration/smtpserver"]
				= ConfigurationSettings.AppSettings["smtpadd"].ToString();
			mail.Fields[
				"http://schemas.microsoft.com/cdo/configuration/smtpserverport"] = ConfigurationSettings.AppSettings["smtpport"].ToString();

				mail.Fields[
					"http://schemas.microsoft.com/cdo/configuration/smtpauthenticate"] = 1;
				mail.Fields[
					"http://schemas.microsoft.com/cdo/configuration/sendusername"] = 
					ConfigurationSettings.AppSettings["smtpUname"].ToString();
				mail.Fields[
					"http://schemas.microsoft.com/cdo/configuration/sendpassword"] = 
					ConfigurationSettings.AppSettings["smtpPwd"].ToString();
			


			
			mail.To = mailTo;
			mail.Subject = this.subject;
			mail.Body = this.body;
			mail.Priority = MailPriority.High;
			mail.BodyFormat = MailFormat.Html;
			//SmtpMail.SmtpServer = ConfigurationSettings.AppSettings["smtpadd"].ToString();
			try
			{
				SmtpMail.Send(mail);
			}
			catch(Exception ex)
			{
				objError.boolErrorOccurred = true;
				objError.strMessage = "Error:"+ex.Message.ToString();
			}
		}
		/// **************************************************************
		/// <summary>
		/// 
		/// </summary>
		/// <returns>true or false</returns>
		/// **************************************************************
		public void SendMailTo(string mailFrom, string mailTo, string copyTo)
		{
			mail = new MailMessage();
			mail.From = mailFrom;
			mail.To = mailTo;
			mail.Cc = copyTo;
			mail.Subject = this.subject;
			mail.Body = this.body;
			mail.Priority = MailPriority.High;
			mail.BodyFormat = MailFormat.Html;
			SmtpMail.SmtpServer = ConfigurationSettings.AppSettings["smtpadd"].ToString();
			SmtpMail.Send(mail);
		}
		/// **************************************************************
		/// <summary>
		/// This gives the Body of the Mail specifically for New Password created.
		/// </summary>
		/// <param name="strBody">string Body</param>
		/// <returns>string</returns>
		/// **************************************************************
		public string MailBody(string strBody)
		{
			strBody = "<table cellpadding='0' height='50%' cellspacing='0' border='0' width='80%'>"
				+"<tr height='80%'>"
				+"<td>&nbsp;</td>"
				+"</tr>"
				+"<tr>"
				+"<td>"
				+"<hr>"
				+"<br>"
				+"A New Password has been created and given below."
				+"<br>"
				+"<br>"
				+"&nbsp;&nbsp;&nbsp;&nbsp;Password:&nbsp;'"+strBody+"'"
				+"<br>"
				+"<hr>"
				+"</td>"
				+"</tr>"
				+"</table>";
			return strBody;
		}	
	}
}
