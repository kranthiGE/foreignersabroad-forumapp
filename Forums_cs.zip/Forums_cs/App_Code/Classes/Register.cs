using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Text;
using System.Security.Cryptography;
using System.Collections;
using dotForumIncludes;
namespace Forums_cs.Classes
{
	/// <summary>
	/// Summary description for Register.
	/// </summary>
	public class Register
	{
		byte[] byteArray = null;
		SqlCommand cmd = null;
		SqlTransaction trans;
		ASCIIEncoding asciiEncode = null;
		bool flag = false;
		int result = 0;
		Authenticate objauth = null;
		includeFunctions myincludes = null;
		public Register()
		{
			//
			// TODO: Add constructor logic here
			//
		}
		/// **************************************************************
		/// <summary>
		/// Encrypts the source content using Sha1Managed.
		/// </summary>
		/// <param name="Source">source string</param>
		/// <param name="objError">Error object</param>
		/// <returns>true or false</returns>
		/// **************************************************************
		public string Encrypt(string Source,ref clsError objError)
		{
			string strEncrypt = string.Empty;
			try
			{
				byteArray = new byte[Source.Length];
				asciiEncode = new ASCIIEncoding();
				asciiEncode.GetBytes(Source,0,Source.Length,byteArray,0);
				SHA1Managed objSha = new SHA1Managed();
				byteArray = objSha.ComputeHash(byteArray);
				for(int k=0;k<byteArray.Length;k++)
				{
					strEncrypt = strEncrypt + byteArray[k].ToString();
				}

			}
			catch(Exception ex)
			{
				objError.boolErrorOccurred = true;
				objError.strMessage = "Error:"+ex.Message.ToString();
			}
			return strEncrypt;
		}
		/// **************************************************************
		/// <summary>
		/// Inserts the New User content into the datatable of the database and return true or false.
		/// </summary>
		/// <param name="objLogin">Object of the Login class</param>
		/// <param name="objError">Error object.</param>
		/// <returns>true or false</returns>
		/// **************************************************************
		public bool CreateUser(ref Login objLogin,ArrayList alist,ref clsError objError)
		{
			try
			{
				myincludes = new includeFunctions();
				objauth = new Authenticate();
				string strHashPwd = null;
				if(!objauth.CheckExist(objLogin.Uname))
				{
				strHashPwd = Encrypt(objLogin.Pwd,ref objError);
				if(objError.boolErrorOccurred == false)
				{
					
						using (SqlConnection connect = new SqlConnection(ConfigurationSettings.AppSettings["forumDSN"]))
						{
							try
							{
								connect.Open();
								cmd = new SqlCommand();
								cmd.Connection = connect;
								trans = connect.BeginTransaction();
								cmd.Transaction = trans;
								cmd.CommandText = "insert into users(Email, Pwd, Fname, City, state, Nationality, country,IsActive, roleId, pvtcnt, imgpath, flagpath,abtmyself) values('"+myincludes.RemoveQuote(objLogin.Uname)+"','"+strHashPwd+"','"+myincludes.RemoveQuote(objLogin.Fname)+"','"+myincludes.RemoveQuote(objLogin.City)+"','"+myincludes.RemoveQuote(objLogin.State)+"','"+objLogin.Nation+"','"+objLogin.Country+"', 1, 2, '"+objLogin.PvtCnt+"', '"+objLogin.ImgPath+"', '"+objLogin.FlagPath+"', '"+myincludes.RemoveHTMLQuote(objLogin.AbtMyself)+"')";
								result = cmd.ExecuteNonQuery();
								if(result<0)
								{
									objError.strMessage = "Registration Unsuccessfull.Please enter the details correctly";
								}
								else
								{
									flag = true;
									if(alist != null && alist.Count != 0)
									{
										for(int i=0;i<alist.Count;i++)
										{
											cmd.CommandText = "insert into CountriesVisited values('"+objLogin.Uname+"','"+alist[i].ToString()+"')";					
										
											cmd.ExecuteNonQuery();
										}
										
									}
								}
								trans.Commit();					
							}
							catch(Exception ex)
							{
								trans.Rollback();
								objError.boolErrorOccurred = true;
								objError.strMessage = "Error:"+ex.Message.ToString();
							}
							finally
							{
								connect.Close();
							}
						}
					}
					
				}
				else
					{
						objError.boolErrorOccurred = true;
						objError.strMessage = "Error:"+"This Email Address already exists in the database.";
					}
			}
			catch(Exception ex)
			{
                objError.boolErrorOccurred = true;
				objError.strMessage = "Error:"+ex.Message.ToString();
			}
			return flag;
		}
	}
}
