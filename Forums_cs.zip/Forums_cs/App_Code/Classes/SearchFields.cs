using System;

namespace Forums_cs.Classes
{
	/// <summary>
	/// Summary description for SearchFields.
	/// </summary>
	public class SearchFields
	{
		private string strSubject = null;
		private string strDate = null;
		private string strName = null;
		private string strMsg = null;
		private string strpsId = null;

		public SearchFields()
		{
			//
			// TODO: Add constructor logic here
			//
		}
		#region Search Fields

		public string psId
		{
			get
			{
				return strpsId;
			}
			set
			{
				strpsId = value;
			}
		}

		public string Name
		{
			get
			{
				return strName;
			}
			set
			{
				strName = value;
			}
		}

		public string Msg
		{
			get
			{
				return strMsg;
			}
			set
			{
				strMsg = value;
			}
		}

		public string Date
		{
			get
			{
				return strDate;
			}
			set
			{
				strDate = value;
			}
		}

		public string Subject 
		{
			get
			{
				return strSubject;
			}
			set
			{
				strSubject = value;
			}
		}

		#endregion
	}
}
