using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections;
using System.Configuration;
namespace Forums_cs.Classes
{
	/// <summary>
	/// Summary description for Search.
	/// </summary>
	public class Search
	{
		ArrayList aInput = new ArrayList();
		SqlCommand cmd = null;
		DataSet ds = new DataSet();

		DataTable dtable=null;
		DataRow drow=null;
		ArrayList alistData = null;
		ArrayList alist = null;
		string strQry = null;
		string strconnect = null;
		SqlConnection con = null;
		SqlDataReader dr = null;
		string strtest="";
		string getstr="";
		bool flag=false;
		int k=0;
		
		SearchFields objSfields = null;
		

		public Search()
		{
			strconnect = ConfigurationSettings.AppSettings["forumDSN"];
		}

		public DataSet SearchSubject(string source,ref clsError objError)
		{
			DataSet dsSearch = new DataSet();
			try
			{
				
				DataRow drow_s = null;
				objSfields = new SearchFields();
				alistData = new ArrayList();
				strQry = "select * from forumthreads";
				con = new SqlConnection(strconnect);
				cmd = new SqlCommand(strQry,con);
				dr = cmd.ExecuteReader();
				dsSearch = fillingDataset();
				while(dr.Read())
				{
					if(search(dr["psSubject"].ToString(),source))
					{
						objSfields.Name = dr["psName"].ToString();
						objSfields.Subject = dr["psSubject"].ToString();
						objSfields.Date = dr["psDate"].ToString();
						objSfields.psId = dr["psId"].ToString();
						//drow_s = getDatarow(objSfields.Name,objSfields.Subject,objSfields.Date,objSfields.psId);
						
					}
				}

			}
			catch(Exception ex)
			{
				objError.boolErrorOccurred = true;
				objError.strMessage = "Error:"+ex.Message.ToString();
			}
			return dsSearch;
		}
		public DataRow getDatarow(string Name,string msg,string Date,string psId,string Subject)
		{
			
			drow=dtable.NewRow();
		
			drow[0]=Name;
			drow[1]=msg;
			drow[2]=Date;
			drow[3]=psId;
			drow[4] = Subject;
			dtable.Rows.Add(drow);
			return drow;
		}

		public DataSet fillingDataset()
		{
			dtable=ds.Tables.Add("searchresult");
			dtable.Columns.Add("Name",typeof(string));
			dtable.Columns.Add("Msg",typeof(string));
			dtable.Columns.Add("Date",typeof(string));
			dtable.Columns.Add("psId",typeof(string));
			dtable.Columns.Add("Subject",typeof(string));			

			return ds;
		}
		public DataSet SearchMessage(string strId,string source,ref clsError objError)
		{
			DataSet dsSearch = new DataSet();
			try
			{
				
				DataRow drow_s = null;
				if(strId == null)
				{
					strQry = "select * from forumthreads where psrelbcid in (select bcid from forumtopics)";
				}
				else
				{
					strQry = "select * from forumthreads where psId = '"+strId+"' OR psRelTopId = '"+strId+"'";
				}
				con = new SqlConnection(strconnect);
				con.Open();
				cmd = new SqlCommand(strQry,con);
				dr = cmd.ExecuteReader();
				aInput = inputList(source.Trim());
				objSfields = new SearchFields();
				dsSearch = fillingDataset();
				while(dr.Read())
				{
					if(search(dr["psPost"].ToString().Trim(),source))
					{
						objSfields.Name = dr["psName"].ToString();
						objSfields.Msg = dr["psPost"].ToString();
						objSfields.Date = dr["psDate"].ToString();
						objSfields.psId = dr["psId"].ToString();
						objSfields.Subject = dr["psSubject"].ToString();
						drow_s = getDatarow(objSfields.Name,objSfields.Msg,objSfields.Date,objSfields.psId,objSfields.Subject);
					}
				}
				con.Close();

			}
			catch(Exception ex)
			{
				objError.boolErrorOccurred = true;
				objError.strMessage = "Error:"+ex.Message.ToString();
			}
			finally
			{
				dr.Close();
			}
			return dsSearch;
		}

		public bool search(string data,string desiredtext)
		{
			alist = new ArrayList();
			flag=false;
			int len=data.Length;
			strtest="";
			getstr="";
			k=0;
			data = data.Trim();
			for(int i=0;i<=len;i++)
			{
				if(i!=data.Length)
				{
					strtest=data.Substring(i,1);
					if(strtest==" " || strtest=="," || strtest=="." || i==len)
					{
						getstr=(data).Substring(k,i-k);
						k=i;
						alist.Add(getstr.Trim());
					}
				}
				else
				{
					getstr=data.Substring(k,i-k);
					alist.Add(getstr.Trim());
				}
			}
			alist = removeSpaces(alist);
			for(int i=0;i<alist.Count;i++)
			{
				string str=alist[i].ToString().ToLower();
				for(int j=0;j<aInput.Count;j++)
				{
					if(((aInput[j].ToString().ToLower().Trim()).IndexOf(str,0)!=-1) && (str.Trim()).IndexOf(aInput[j].ToString().ToLower(),0)!=-1)
					{
						flag=true;		
						return flag;			
					}
					
				}
			}
			alist.Clear();
			
			return flag;
		}

		#region Remove WhiteSpaces in Arraylist
		public ArrayList removeSpaces(ArrayList alistRemove)
		{
			for(int i=0;i<alistRemove.Count;i++)
			{
				
				if( alistRemove[i].ToString().CompareTo(" ")==0)
				{
					alistRemove.Remove(alistRemove[i]);
				}
				
			}
			return alistRemove;
		}
		#endregion

		public ArrayList inputList(string input)
		{
			
			k=0;
			strtest="";
			getstr="";
			
			for(int i=0;i<=input.Length;i++)
			{
				if(i!=input.Length)
				{
					strtest=input.Substring(i,1);
					if(strtest==" " || strtest=="," || strtest=="." || i==input.Length)
					{
						getstr=(input).Substring(k,i-k);
						k=i+1;
						aInput.Add(getstr.Trim());
					}
				}
				else
				{
					getstr=input.Substring(k,i-k);
					aInput.Add(getstr.Trim());
				}
			}
			for(int i=0;i<aInput.Count;i++)
			{
				
				if( aInput[i].ToString().CompareTo(" ")==0)
				{
					aInput.Remove(aInput[i]);
				}
				
			}
			
			return aInput;
		}

	}
}
