using System;
using System.Data.SqlClient;
using System.Data;
using System.IO;
using System.Configuration;
using System.Collections;



namespace Forums_cs.Classes
{
	/// <summary>
	/// Summary description for clsUploadFileMgr.
	/// </summary>
	public class clsItemUploadFileMgr
	{
		DataSet ds = null;
		protected DataSet dsUploadFile;
		string strQry = null;
		SqlConnection connect = null;
		SqlCommand cmd = null;
		int result = 0;
		DataSet dsData = null;
		SqlDataAdapter da = null;
		SqlDataReader dr = null;
		public clsItemUploadFileMgr()
		{
			connect = new SqlConnection(ConfigurationSettings.AppSettings["forumDSN"]);
		}

		public void DeleteUploadFile(clsItemUploadFiles objUploadFile,clsError ObjError)
		{

		
			if(ObjError.boolErrorOccurred==false)
			{
				try
				{

					strQry = "delete from Post_Files where postID = '"+objUploadFile.PostId+"' and File_id = '"+objUploadFile.File_id+"'";
					cmd = new SqlCommand(strQry,connect);
					connect.Open();
					result = cmd.ExecuteNonQuery();
					connect.Close();				
					if(result>0)
					{
						ObjError.strMessage = "Successfully deleted";
					}
					else
					{
						ObjError.boolErrorOccurred = true;
					}
				}
				catch(Exception ex)
				{
					ObjError.boolErrorOccurred=true;
					ObjError.strMessage="Error:"+ex.Message.ToString();
				}		
			}		
		}


		public void InsertUpLoadfile(clsItemUploadFiles objItemFile,clsError objError)
		{
			if(objError.boolErrorOccurred == false)
			{
				try
				{

					strQry = "insert into Post_Files values('"+objItemFile.PostId+"','"+objItemFile.ItemFile_Name+"','"+objItemFile.File_path+"')";
					cmd = new SqlCommand(strQry,connect);
					connect.Open();
                    result = cmd.ExecuteNonQuery();
					connect.Close();
					if(result>0)
					{
						objError.strMessage = "Successfully Inserted";
					}
					else
					{
						objError.boolErrorOccurred = true;
					}				
				}
				catch(Exception ex)
				{
					objError.boolErrorOccurred = true;
					objError.strMessage += "Error:"+ex.Message.ToString();
				}
			}					
		}


		


		public DataSet GetUploadFiles( string itemID,clsError objerrors)
		{
			try
			{
				if(objerrors.boolErrorOccurred==false)
				{
					strQry="select * from Post_Files where PostId ='"+itemID+"'";
					dsData = new DataSet();
					da = new SqlDataAdapter(strQry,connect);
					da.Fill(dsData);                    	
				}
			}
			catch(Exception Ex)
			{
				objerrors.strMessage="Error: Getvalues "+Ex.Message.ToString();;
				dsUploadFile= null;			
			}
			return dsData;		
		}


		public bool ISFileNameExsist(string Filename ,clsError objerror )
		{
			bool flag = false;
			try
			{				
				if(objerror.boolErrorOccurred==false)
				{	
					SqlDataReader dr = null;
					cmd = new SqlCommand("select * from post_files where file_name = '"+Filename+"'",connect);
					connect.Open();
					dr = cmd.ExecuteReader();
					if(dr.Read())
					{
						flag = true;
					}
					connect.Close();											
				}
			}
			catch(Exception Ex)
			{
				objerror.boolErrorOccurred=true;
				objerror.strMessage="Error:"+Ex.Message.ToString();			
			}	
			return flag;
		}
		public bool CheckExistence(string strQry,ref clsError objError)
		{
			bool flag = false;
			ds= new DataSet();
			try
			{
				da = new SqlDataAdapter(strQry,connect);
				da.Fill(ds);
				if(ds.Tables[0].Rows.Count != 0)
				{
					flag = true;				
				}
			}
			catch(Exception ex)
			{
				objError.boolErrorOccurred = true;
				objError.strMessage = "Error:"+ex.Message.ToString();
			}
			return flag;
		}
		public bool ShowAttach(string Uname)
		{
			bool flag = false;
			SqlDataReader dr = null;
			cmd = new SqlCommand("select * from users where Email = '"+Uname+"' and Attach = 'N'",connect);
			connect.Open();
			dr = cmd.ExecuteReader();
			if(dr.Read())
			{
				flag = true;
			}
			connect.Close();
			return flag;
		}

		public DataSet GetFileNames(string strQry,ref clsError objError)
		{
			DataSet dsFiles = new DataSet();
			
			try
			{				
				da = new SqlDataAdapter(strQry,connect);
				da.Fill(dsFiles);				
			}
			catch(Exception ex)
			{
				objError.boolErrorOccurred = true;
				objError.strMessage = "Error:"+ex.Message.ToString();
			}
			return dsFiles;
		}
			
		public bool FileCount(string postid,ref clsError objError)
		{
			bool flag = false;
			try
			{
				strQry = "select count(File_Name) as filecnt from post_files where postid = '"+postid+"'";
				connect.Open();
				cmd = new SqlCommand(strQry,connect);
				dr = cmd.ExecuteReader();
				while(dr.Read())
				{
					if(Convert.ToInt16(dr["filecnt"]) < 2)
					{
						flag = true;
					}
				}				
			}
			catch(Exception ex)
			{
				objError.boolErrorOccurred = true;
				objError.strMessage = "Error:"+ex.Message.ToString();
			}
			finally
			{
				connect.Close();
			}	
			return flag;
		}
	}
}
