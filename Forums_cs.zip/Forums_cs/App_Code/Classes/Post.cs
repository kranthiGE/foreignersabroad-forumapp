using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using dotForumIncludes;
namespace Forums_cs.Classes
{
	/// <summary>
	/// Summary description for Post.
	/// </summary>
	public class Post
	{
		clsError objError = null;
		clsSendmail objSend = null;
		includeFunctions objInclude = null;

		SqlConnection connect = null;
		SqlCommand cmd = null;
		SqlDataReader dr = null;

		string strConnect = null;
		string strQry = null;
		public Post()
		{
			strConnect = ConfigurationSettings.AppSettings["forumDSN"];
		}

		public void NotifybyEmail(string Name,string Postid,string psRelid,string strSub,string strPost)
		{
			try
			{
				objError = new clsError();
				objSend = new clsSendmail();
				objInclude = new includeFunctions();

				strPost = objInclude.InsertSmiley_Domain(strPost);
				
					connect = new SqlConnection(strConnect);
					strQry = "select * from forumthreads where psRelTopid = "+psRelid+" and Notify = 'Y' and postid != '"+Postid+"' ";
					connect.Open();
					cmd = new SqlCommand(strQry,connect);
					dr = cmd.ExecuteReader();
					while(dr.Read())
					{
						objSend.SetMailSubject("You have received a Reply to your Post.");
						objSend.SetMailBody(MessageBody(Name,GenarateURL(psRelid),dr["psSubject"].ToString(),strSub,strPost));
						objSend.SendMailTo(ConfigurationSettings.AppSettings["adminMail"].ToString(),dr["psEmail"].ToString(),ref objError);
					}
					dr.Close();
					strQry = "select * from forumthreads where psRelTopid = 0 and psId = '"+psRelid+"' and Notify = 'Y'";
					cmd = new SqlCommand(strQry,connect);
					dr = cmd.ExecuteReader();
					while(dr.Read())
					{
						objSend.SetMailSubject("You have received a Reply to your Post.");
						objSend.SetMailBody(MessageBody(Name,GenarateURL(psRelid),dr["psSubject"].ToString(),strSub,strPost));
						objSend.SendMailTo(ConfigurationSettings.AppSettings["adminMail"].ToString(),dr["psEmail"].ToString(),ref objError);
					}
					connect.Close();					
				

			}
			catch(Exception ex)
			{	
				objError.boolErrorOccurred = true;
				objError.strMessage = "Error:"+ex.Message.ToString();
			}			
		}
		
		public bool CheckNotify(string postid)
		{
			bool flag = false;
			try
			{			
			objError = new clsError();
				
			connect = new SqlConnection(strConnect);
			strQry = "select psEmail from forumthreads where Postid = '"+postid+"' and Notify = 'Y'";
			connect.Open();
			cmd = new SqlCommand(strQry,connect);
			dr = cmd.ExecuteReader();
			if(dr.Read())
			{
				flag = true;
			}
			connect.Close();
			dr.Close();			
			}
			catch(Exception ex)
			{	
				objError.boolErrorOccurred = true;
				objError.strMessage = "Error:"+ex.Message.ToString();
			}
			return flag;
		}

		public string GenarateURL(string threadid)
		{
			string strDomain = ConfigurationSettings.AppSettings["DomainName"];
			strDomain = strDomain + "/threadView.aspx?id="+threadid;
			return strDomain;
		}

		public string MessageBody(string Uname,string url,string sub1,string sub2,string post)
		{
			string strBody = "<html>"
				+"<head>"
				+"<title></title>"
				+"</head>"
				+"<body>"
				+"<table cellpadding='0' cellspacing='0' border='0' align='center' width='90%'>"
				+"<tr>"
				+"<td colspan='2'>"
				+"<h4>A Reply from "+Uname+" has been Posted to your message Entitled: "+sub1+"</h4>"
				+"</td>"
				+"</tr>"
				+"<tr>"
				+"<td width='30%'>"
				+"Subject:"
				+"</td>"
				+"<td>"+sub2+""
				+"</td>"
				+"</tr>"
				+"<tr>"
				+"<td>"
				+"Body of the Post:"
				+"</td>"
				+"<td>"+post+""
				+"</td>"
				+"</tr>"
				+"<tr>"
				+"<td colspan='2'>"
				+"Please click on this URL to send a reply.....<a href = "+url+">"+url+"</a>"
				+"</td>"
				+"</tr>"
				+"<tr>"
				+"<td>"
				+"<b>NOTE:</b>"+"Please do not reply to this email"
				+"</td>"
				+"</tr>"
				+"</table>"
				+"</body>"
				+"</html>";
			return strBody;

		}

	}
}
