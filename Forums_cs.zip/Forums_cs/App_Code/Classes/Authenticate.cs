using System;
using System.Data;
using System.Data.SqlClient;

using System.Configuration;

namespace Forums_cs.Classes
{
	/// <summary>
	/// Summary description for Authenticate.
	/// </summary>
	public class Authenticate
	{
		DataSet dsLogin = null;
		bool authenticated = false;
		string strQry = null;		
		DataRow[] drows = null;
		string strConnect = null;
		int result = 0;
		Register objReg = null;
		SqlDataAdapter da = null;
		SqlCommand cmd = null;
		Random rnd = null;
		clsSendmail objSendMail = null;
		public Authenticate()
		{
			strConnect = ConfigurationSettings.AppSettings["forumDSN"];
		}
		/// **************************************************************
		/// <summary>
		/// Authenticates the given user and returns true or false
		/// </summary>
		/// <returns>true or false</returns>
		/// **************************************************************
		public bool Authenticator(ref Login objLogin,ref clsError objError)
		{
			try
			{
				objReg = new Register();
				dsLogin = new DataSet();
				PopulateUserData();		
				string strPwd = objReg.Encrypt(objLogin.Pwd,ref objError);
				if(dsLogin != null || dsLogin.Tables.Count != 0)
				{
					drows = dsLogin.Tables[0].Select("Email = '"+ objLogin.Uname +"' and pwd = '"+ strPwd +"' and roleid = 2");
					if(drows.Length > 0)
					{
						authenticated = true;	
						strQry = "update users set logindate = '"+DateTime.Now+"' where Email = '"+ objLogin.Uname +"'";	
						SqlConnection con = new SqlConnection(strConnect);
						con.Open();
						cmd = new SqlCommand(strQry,con);
						cmd.ExecuteNonQuery();
						con.Close();
					}
				}
			
			}
			catch(Exception ex)
			{
				objError.boolErrorOccurred = true;
				objError.strMessage = "Error:"+ex.Message.ToString();
			}
			finally
			{
				dsLogin = null;
				drows = null;
			}
			return authenticated;
		}
		/// **************************************************************
		/// <summary>
		/// Gets the name of the user by his EmailId.
		/// </summary>
		/// <param name="Uname">User name</param>
		/// <param name="objError">Error object</param>
		/// <returns>true or false</returns>
		/// **************************************************************
		
		public string GetName(string Uname,ref clsError objError)
		{
			string strName = null;
			try
			{
				SqlConnection con = new SqlConnection(strConnect);
				strQry = "select Fname from users where Email='"+Uname.Trim()+"'";	
				con.Open();
				cmd = new SqlCommand(strQry,con);
				strName = cmd.ExecuteScalar().ToString();
				con.Close();
			}
			catch(Exception ex)
			{
				objError.boolErrorOccurred = true;
				objError.strMessage = "Error:"+ex.ToString();
			}
			return strName;
		}
		/// **************************************************************
		/// <summary>
		/// Gets the MailId by the Name of the User.
		/// </summary>
		/// <param name="Name">Name of the user</param>
		/// <param name="objError">Error object</param>
		/// <returns>true or false</returns>
		/// **************************************************************
		public string GetEmail(string Name,ref clsError objError)
		{
			string strName = null;
			try
			{
				SqlConnection con = new SqlConnection(strConnect);
				strQry = "select Email from users where Fname='"+Name.Trim()+"'";	
				con.Open();
				cmd = new SqlCommand(strQry,con);
				strName = cmd.ExecuteScalar().ToString();
				con.Close();
			}
			catch(Exception ex)
			{
				objError.boolErrorOccurred = true;
				objError.strMessage = "Error:"+ex.ToString();
			}
			return strName;
		}
		/// **************************************************************
		/// <summary>
		/// Popelates the data of the user
		/// </summary>
		/// <returns>true or false</returns>
		/// **************************************************************
		public void PopulateUserData()
		{
			
				dsLogin = new DataSet();
				strQry = "select * from users U join roletype R on U.roleid = R.roleid";		
				da = new SqlDataAdapter(strQry,strConnect);
                da.Fill(dsLogin);
			
			
		}
		/// **************************************************************
		/// <summary>
		/// Creates a New Password and sends the Password to the particular user who forgets his password.
		/// </summary>
		/// <param name="EmailId">Email id of the User</param>
		/// <param name="objError">Error object</param>
		/// <returns>true or false</returns>
		/// **************************************************************
		public string ForgotPassword(string EmailId,ref clsError objError)
		{
			string strText = null;
			try
			{
				if(CheckExist(EmailId))
				{
					rnd = new Random();
					objSendMail = new clsSendmail();
					string strPwd = null;
					objReg = new Register();
					int NewPwd = 0;
					NewPwd = rnd.Next(10000,100000);
					strPwd = objReg.Encrypt(NewPwd.ToString(),ref objError);
					if(objError.boolErrorOccurred != true)
					{
						SqlConnection con = new SqlConnection(strConnect);
						strQry = "update users set pwd = '"+strPwd.Trim()+"' where Email='"+EmailId.Trim()+"'";
						con.Open();
						cmd = new SqlCommand(strQry,con);
						result = cmd.ExecuteNonQuery();
						con.Close();
						if(result>0)
						{
							objSendMail.SetMailSubject("Your Password details...");
							objSendMail.SetMailBody(objSendMail.MailBody(NewPwd.ToString()));
							objSendMail.SendMailTo(ConfigurationSettings.AppSettings["adminMail"],EmailId.Trim(),ref objError);												
							strText = "<font class='docLink_std13'>A new Password has been created and sent to the email address you provided.</font>";
						}					
					}
				}
				else
				{
					objError.strMessage = "Email address you provided does not exist in our records.";
				}
			}
			catch(Exception ex)
			{
				objError.boolErrorOccurred = true;
				objError.strMessage = "Error:"+ex.Message.ToString();
			}
			return strText;
		}
		/// **************************************************************
		/// <summary>
		/// Checks the existence of the Mailid of the User.
		/// </summary>
		/// <param name="Email">email id of the User.</param>
		/// <returns>true or false</returns>
		/// **************************************************************
		public bool CheckExist(string Email)
		{
			bool flag = false;
			dsLogin = new DataSet();
			strQry = "select * from users";		
			da = new SqlDataAdapter(strQry,strConnect);
			da.Fill(dsLogin);
			if(dsLogin != null || dsLogin.Tables.Count != 0)
			{
				drows = dsLogin.Tables[0].Select("Email = '"+ Email +"'");
				if(drows.Length > 0)
				{
					flag = true;								
				}
			}
			return flag;
		}
	}
}
