using System;

namespace Forums_cs.Classes
{
	/// <summary>
	/// Summary description for ItemUploadFiles.
	/// </summary>
	public class clsItemUploadFiles
	{
		private string FileID;
		private string strPostid;
		private string strItemFile_Name;
		private string strFile_path;
		//		private string Item_id;
		

		public clsItemUploadFiles()
		{
			//
			// TODO: Add constructor logic here
			//
		}


		#region Upload Fields

		public string File_id
		{
			get
			{
				return FileID;
			}
			set
			{
			
				FileID=value;
			
			
			}
			
		}
		public string PostId
		{
			get
			{
				return strPostid;
			}
			set
			{
				strPostid=value;
			}
		}
		public string ItemFile_Name
		{
			get
			{
				return strItemFile_Name;;
			}
			set
			{
				strItemFile_Name=value;
			}
		}
		public string File_path
		{
			get
			{
				return strFile_path;
			}
			set
			{
				strFile_path=value;
			}
		}
		
		#endregion


	}
}
