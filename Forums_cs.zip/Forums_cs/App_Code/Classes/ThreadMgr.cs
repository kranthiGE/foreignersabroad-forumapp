using System;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using dotForumIncludes;
using System.Web.SessionState;
namespace Forums_cs.Classes
{
	/// <summary>
	/// Summary description for ThreadMgr.
	/// </summary>
	public class ThreadMgr
	{
		
		includeFunctions myIncludes = null;
		DataSet dsCts = null;
		string strQry = null;
		SqlTransaction trans;
		SqlCommand cmd = null;
		SqlConnection connect = null;
		SqlDataReader dr = null;
		SqlDataAdapter da = null;
		int result = 0;
		bool flag = false;
		public string strCatName = null;
		public ThreadMgr()
		{
			//
			// TODO: Add constructor logic here
			//
		}
		/// **************************************************************
		/// <summary>
		/// 
		/// </summary>
		/// <returns>true or false</returns>
		/// **************************************************************
		public bool SavePost(ref Thread objThread,ref clsError objError)
		{
			try
			{
				strQry = "update forumThreads set psSubject = '"+objThread.Subject+"' , psPost = '"+objThread.Post+"' , psName = '"+objThread.Name+"' where psEmail = '"+objThread.Email+"' and psId = "+objThread.ThreadId+"";
				using (SqlConnection connect = new SqlConnection(ConfigurationSettings.AppSettings["forumDSN"]))
				{
					try
					{
						connect.Open();
						cmd = new SqlCommand();
						cmd.Connection = connect;
						trans = connect.BeginTransaction();
						cmd.Transaction = trans;
						cmd.CommandText = strQry;
						result = cmd.ExecuteNonQuery();
						if(result<0)
						{
							objError.strMessage = "Unable to Edit the Post Unsuccessfull.Please enter the details correctly";
						}
						else
						{
							flag = true;
						}
						trans.Commit();					
					}
					catch(Exception ex)
					{
						trans.Rollback();
						objError.boolErrorOccurred = true;
						objError.strMessage = "Error:"+ex.Message.ToString();
					}
					finally
					{
						connect.Close();
					}
				}
			}
			catch(Exception ex)
			{
				objError.boolErrorOccurred = true;
				objError.strMessage = "Error:"+ex.Message.ToString();
			}
			return flag;
		}
	
		/// **************************************************************
		/// <summary>
		/// 
		/// </summary>
		/// <returns>true or false</returns>
		/// **************************************************************
		public void deletePost(ref Thread objThread,ref clsError objError)
		{
			try
			{
				strQry = "delete from forumThreads where psEmail = '"+objThread.Email+"' and psId = "+objThread.ThreadId+" ";
				using (SqlConnection connect = new SqlConnection(ConfigurationSettings.AppSettings["forumDSN"]))
				{
					try
					{
						connect.Open();
						cmd = new SqlCommand();
						cmd.Connection = connect;
						trans = connect.BeginTransaction();
						cmd.Transaction = trans;
						cmd.CommandText = strQry;
						result = cmd.ExecuteNonQuery();
						if(result<0)
						{
							objError.strMessage = "Unable to Delete the Post Unsuccessfull.";
						}						
						trans.Commit();					
					}
					catch(Exception ex)
					{
						trans.Rollback();
						objError.boolErrorOccurred = true;
						objError.strMessage = "Error:"+ex.Message.ToString();
					}
					finally
					{
						connect.Close();
					}
				}
			}
			catch(Exception ex)
			{
				objError.boolErrorOccurred = true;
				objError.strMessage = "Error:"+ex.Message.ToString();
			}
		}
		/// **************************************************************
		/// <summary>
		/// 
		/// </summary>
		/// <returns>true or false</returns>
		/// **************************************************************
		public string getMaxId(string EmailId,ref clsError objError)
		{
			string strName = null;
			try
			{
				SqlConnection con = new SqlConnection(ConfigurationSettings.AppSettings["forumDSN"]);
				strQry = "select max(psid) from forumthreads where psemail='"+EmailId.Trim()+"'";	
				con.Open();
				cmd = new SqlCommand(strQry,con);
				strName = cmd.ExecuteScalar().ToString();
				con.Close();
			}
			catch(Exception ex)
			{
				objError.boolErrorOccurred = true;
				objError.strMessage = "Error:"+ex.ToString();
			}
			return strName;            			
		}


		public DataSet GetCountries(ref clsError objError)
		{
			dsCts = new DataSet();
			try
			{
				strQry = "select Typeid, typename from threadtype where Typeid != 'T240' and Parentid = 'N' order by typename";
				connect = new SqlConnection(ConfigurationSettings.AppSettings["forumDSN"]);
				da = new SqlDataAdapter(strQry,connect);
				da.Fill(dsCts);
			}
			catch(Exception ex)
			{
				objError.boolErrorOccurred = true;
				objError.strMessage = "Error:"+ex.Message.ToString();
			}
			return dsCts;
		}

		public DataSet GetRegCountries(ref clsError objError)
		{
			dsCts = new DataSet();
			try
			{
				strQry = "select imgpath, typename from threadtype where Typeid != 'T240' and Parentid = 'N' order by typename";
				connect = new SqlConnection(ConfigurationSettings.AppSettings["forumDSN"]);
				da = new SqlDataAdapter(strQry,connect);
				da.Fill(dsCts);
			}
			catch(Exception ex)
			{
				objError.boolErrorOccurred = true;
				objError.strMessage = "Error:"+ex.Message.ToString();
			}
			return dsCts;
		}

		public DataSet GetGenCountries(ref clsError objError)
		{
			dsCts = new DataSet();
			try
			{
				strQry = "select Typeid,typename from threadtype where Parentid = 'N'";
				connect = new SqlConnection(ConfigurationSettings.AppSettings["forumDSN"]);
				da = new SqlDataAdapter(strQry,connect);
				da.Fill(dsCts);
			}
			catch(Exception ex)
			{
				objError.boolErrorOccurred = true;
				objError.strMessage = "Error:"+ex.Message.ToString();
			}
			return dsCts;
		}

		public DataSet GetSates(ref clsError objError)
		{
			dsCts = new DataSet();
			try
			{
				strQry = "select Typeid,typename from threadtype where parentid != 'N'";
				connect = new SqlConnection(ConfigurationSettings.AppSettings["forumDSN"]);
				da = new SqlDataAdapter(strQry,connect);
				da.Fill(dsCts);
			}
			catch(Exception ex)
			{
				objError.boolErrorOccurred = true;
				objError.strMessage = "Error:"+ex.Message.ToString();
			}
			return dsCts;
		}

		public string GetImagPath(string strid,ref clsError objError)
		{
			string strImgpath = null;
			try
			{
				strQry = "select Imgpath from forumtopics where bcid = '"+strid+"'";	
				connect = new SqlConnection(ConfigurationSettings.AppSettings["forumDSN"]);
				connect.Open();
				cmd = new SqlCommand(strQry,connect);
				dr = cmd.ExecuteReader();
				if(dr.Read())
				{
					strImgpath = dr["Imgpath"].ToString();	
				}
				else
				{
					strImgpath = "";
				}
			}
			catch(Exception ex)
			{
				objError.boolErrorOccurred = true;
				objError.strMessage = "Error:"+ex.Message.ToString();
			}
			finally
			{
				connect.Close();
			}
			return strImgpath;
		}

		public void CreateCategory(string Id,string CatName,ref clsError objError)
		{
			try
			{				
				myIncludes = new includeFunctions();	
				connect = new SqlConnection(ConfigurationSettings.AppSettings["forumDSN"]);
				string Topicid = Id;			
				strQry = "insert into forumtopics(bcId,bcTitle,TopicType) values('"+Topicid+"','"+CatName+"','S')";
				connect.Open();
				cmd = new SqlCommand(strQry,connect);
				result = cmd.ExecuteNonQuery();
				if(result > 0)
				{
					objError.boolErrorOccurred = false;
					objError.strMessage = "Insertion Successfull";
				}			
			}	
			catch(Exception ex)
			{
				objError.boolErrorOccurred = true;
				objError.strMessage = "Error:"+ex.Message.ToString();
			}
			finally
			{
				cmd = null;
				connect.Close();
			}
		}

		public bool CheckCatExist(string strCatid,ref clsError objError)
		{
			bool flag = false;
			try
			{
				strQry = "select * from forumtopics where bcId = '"+strCatid+"'";
				connect = new SqlConnection(ConfigurationSettings.AppSettings["forumDSN"]);
				connect.Open();
				cmd = new SqlCommand(strQry,connect);
				dr = cmd.ExecuteReader();
				if(dr.Read())
				{
					flag = true;
				}			
				connect.Close();
			}
			catch(Exception ex)
			{
				objError.boolErrorOccurred = true;
				objError.strMessage = "Error:"+ex.Message.ToString();
			}
			return flag;
		}
		

	}
}
