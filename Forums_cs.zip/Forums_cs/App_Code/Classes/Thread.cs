using System;

namespace Forums_cs.Classes
{
	/// <summary>
	/// Summary description for Thread.
	/// </summary>
	public class Thread
	{
		private string strName = null;
		private string strEmail = null;
		private string strSubject = null;
		private string strPost = null;
		private string strThreadId = null;
		public Thread()
		{
			//
			// TODO: Add constructor logic here
			//
		}
		public string Name
		{
			get
			{
				return strName;
			}
			set
			{
				strName = value;
			}
		}
		public string Email
		{
			get
			{
				return strEmail;
			}
			set
			{
				strEmail = value;
			}
		}
		public string Subject
		{
			get
			{
				return strSubject;
			}
			set
			{
				strSubject = value;
			}
		}
		public string Post
		{
			get
			{
				return strPost;
			}
			set
			{
				strPost = value;
			}
		}
		public string ThreadId
		{
			get
			{
				return strThreadId;
			}
			set
			{
				strThreadId = value;
			}
		}

	}
}
