using System;

namespace Forums_cs.Classes
{
	/// <summary>
	/// Summary description for Login.
	/// </summary>
	public class Login
	{
		private string strUname = null;
		private string strPwd = null;
		private string strRoleId = null;
		private string strFname = null;
		private string strLname = null;
		private string strAttach = null;
		private string strQry = null;
		private string strNewPwd = null;
		private string strOldPwd = null;
		private string strlocation = null;
		private string strPvtCnt = null;
		private string strImgPath = null;
		private string strCity = null;
		private string strState = null;
		private string strCountry = null;
		private string strFlagpath = null;
		private string strNationality = null;
		private string strAbtMyself = null;
		public Login()
		{
			//
			// TODO: Add constructor logic here
			//
		}
		#region Login Fields

		public string AbtMyself
		{
			get
			{
				return strAbtMyself;
			}
			set
			{
				strAbtMyself = value;
			}
		}

		public string Nation
		{
			get
			{
				return strNationality;
			}
			set
			{
				strNationality = value;
			}
		}

		public string FlagPath
		{
			get
			{
				return strFlagpath;
			}
			set
			{
				strFlagpath = value;
			}
		}

		public string City
		{
			get
			{
				return strCity;
			}
			set
			{
				strCity = value;
			}
		}
		public string State
		{
			get
			{
				return strState;
			}
			set
			{
				strState = value;
			}
		}
		public string Country
		{
			get
			{
				return strCountry;
			}
			set
			{
				strCountry = value;
			}

		}


		public string ImgPath
		{
			get
			{
				return strImgPath;
			}
			set
			{
				strImgPath = value;
			}
		}

		public string PvtCnt
		{
			get
			{
				return strPvtCnt;
			}
			set
			{
				strPvtCnt = value;
			}
		}

		public string Location 
		{
			get
			{
				return strlocation;
			}
			set
			{
				strlocation = value;
			}
		}

		public string NewPwd
		{
			get
			{
				return strNewPwd;
			}
			set
			{
				strNewPwd = value;
			}
		}

		public string OldPwd 
		{
			get
			{
				return strOldPwd;
			}
			set
			{
				strOldPwd = value;
			}
		}

		public string Query
		{
			get
			{
				return strQry;
			}
			set
			{
				strQry = value;
			}
		}

		public string Attach
		{
			get
			{
				return strAttach;
			}
			set
			{
				strAttach = value;
			}
		}

		public string Fname
		{
			get
			{
				return strFname;
			}
			set
			{
				strFname = value;
			}
		}

		public string Lname
		{
			get
			{
				return strLname;
			}
			set
			{
				strLname = value;
			}
		}


		public string Uname
		{
			get
			{
				return strUname;
			}
			set
			{
				strUname = value;
			}
		}

		public string Pwd
		{
			get
			{
				return strPwd;
			}
			set
			{
				strPwd = value;
			}
		}

		public string RoleId
		{
			get
			{
				return strRoleId;
			}
			set
			{
				strRoleId = value;
			}
		}

		#endregion
	}
}
