using System;
namespace Forums_cs.Classes
{
	/// <summary>
	/// Summary description for clsError.
	/// </summary>
	public class clsError
	{
		public clsError()
		{
			this.Reset(); 
		}
		public bool boolErrorOccurred;

		/// <summary>
		/// string to hold error messages
		/// </summary>
		public string strMessage;

		/// <summary>
		/// Method to Reset object , ie clear string and set flag to false
		/// </summary>
		public void Reset()
		{
			this.boolErrorOccurred=false;
			this.strMessage=""; 
		}
	}
}
