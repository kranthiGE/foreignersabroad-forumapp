SET NOCOUNT ON
-- Restricts volume of output to errors and
-- messages that use the PRINT function

PRINT 'CREATING User dbo'
if not exists (select * from dbo.sysusers where name = N'dbo' and uid < 16382)
	EXEC sp_grantdbaccess N'INNOVIA-RE9CBKV\Administrator', N'dbo'
GO



PRINT 'CREATING User innovia'
if not exists (select * from dbo.sysusers where name = N'innovia' and uid < 16382)
	EXEC sp_grantdbaccess N'innovia', N'innovia'
GO



PRINT 'CREATING TABLE ContactUs'
CREATE TABLE [ContactUs] (
	[contactid] [int] IDENTITY (1, 1) NOT NULL ,
	[Name] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Email] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[phone] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[sub] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[msg] [varchar] (250) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	CONSTRAINT [PK_ContactUs] PRIMARY KEY  CLUSTERED 
	(
		[contactid]
	)  ON [PRIMARY] 
) ON [PRIMARY]
GO




PRINT 'CREATING TABLE RoleType'
CREATE TABLE [RoleType] (
	[RoleId] [int] IDENTITY (1, 1) NOT NULL ,
	[RoleType] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	CONSTRAINT [PK_RoleType] PRIMARY KEY  CLUSTERED 
	(
		[RoleId]
	)  ON [PRIMARY] 
) ON [PRIMARY]
GO




PRINT 'CREATING TABLE ThreadType'
CREATE TABLE [ThreadType] (
	[TypeId] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[TypeName] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[ParentId] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_ThreadType_ParentId] DEFAULT ('N'),
	[Imgpath] [varchar] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	CONSTRAINT [PK_ThreadType] PRIMARY KEY  CLUSTERED 
	(
		[TypeId]
	)  ON [PRIMARY] 
) ON [PRIMARY]
GO




PRINT 'CREATING TABLE Users'
CREATE TABLE [Users] (
	[UserId] [int] IDENTITY (1, 1) NOT NULL ,
	[Email] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Pwd] [varchar] (64) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Fname] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Lname] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Location] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[City] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[state] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Nationality] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[country] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[abtmyself] [text] COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[IsActive] [bit] NOT NULL CONSTRAINT [DF_Users_IsActive] DEFAULT (0),
	[roleId] [int] NOT NULL ,
	[Attach] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL CONSTRAINT [DF_Users_Attach] DEFAULT ('Y'),
	[joinDate] [datetime] NULL CONSTRAINT [DF_Users_joinDate] DEFAULT (getdate()),
	[Pvtcnt] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL CONSTRAINT [DF_Users_Pvtcnt] DEFAULT ('N'),
	[imgpath] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[flagpath] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[logindate] [datetime] NULL ,
	CONSTRAINT [PK_Users] PRIMARY KEY  CLUSTERED 
	(
		[Email]
	)  ON [PRIMARY] ,
	CONSTRAINT [FK_Users_RoleType] FOREIGN KEY 
	(
		[roleId]
	) REFERENCES [RoleType] (
		[RoleId]
	) ON DELETE CASCADE  ON UPDATE CASCADE 
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO




PRINT 'CREATING TABLE CountriesVisited'
CREATE TABLE [CountriesVisited] (
	[Userid] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[CntryId] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	CONSTRAINT [FK_CountriesVisited_ThreadType] FOREIGN KEY 
	(
		[CntryId]
	) REFERENCES [ThreadType] (
		[TypeId]
	) ON DELETE CASCADE  ON UPDATE CASCADE ,
	CONSTRAINT [FK_CountriesVisited_Users] FOREIGN KEY 
	(
		[Userid]
	) REFERENCES [Users] (
		[Email]
	) ON DELETE CASCADE  ON UPDATE CASCADE 
) ON [PRIMARY]
GO




PRINT 'CREATING TABLE forumThreads'
CREATE TABLE [forumThreads] (
	[psId] [varchar] (4) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[psRelTopId] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[psName] [varchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[psEmail] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[psSubject] [varchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[psPost] [text] COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[psDate] [datetime] NULL ,
	[psRelBcId] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[psLastUpdate] [datetime] NULL ,
	[psIP] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Postid] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Notify] [char] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL CONSTRAINT [DF_forumThreads_Notify] DEFAULT ('N'),
	[treeorder] [int] NULL ,
	CONSTRAINT [PK_forumThreads] PRIMARY KEY  CLUSTERED 
	(
		[psId]
	)  ON [PRIMARY] ,
	CONSTRAINT [FK_forumThreads_Users] FOREIGN KEY 
	(
		[psEmail]
	) REFERENCES [Users] (
		[Email]
	)
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO




PRINT 'CREATING TABLE forumTopics'
CREATE TABLE [forumTopics] (
	[bcId] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[bcTitle] [varchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[bcDesc] [text] COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[bcOrder] [int] NULL ,
	[bcLastUpdate] [datetime] NULL ,
	[Imgpath] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[ImgID] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[parentId] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[TopicType] [varchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL 
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO




PRINT 'CREATING TABLE Myfav'
CREATE TABLE [Myfav] (
	[Uname] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Favid] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL 
) ON [PRIMARY]
GO




PRINT 'CREATING TABLE OnlineInfo'
CREATE TABLE [OnlineInfo] (
	[sessid] [int] NULL ,
	[UserCnt] [int] NULL ,
	[Datetoday] [datetime] NULL CONSTRAINT [DF_OnlineInfo_Datetoday] DEFAULT (getdate())
) ON [PRIMARY]
GO




PRINT 'CREATING TABLE Post_Files'
CREATE TABLE [Post_Files] (
	[File_id] [int] IDENTITY (1, 1) NOT NULL ,
	[PostID] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[File_Name] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Filepath] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	CONSTRAINT [PK_Post_Files] PRIMARY KEY  CLUSTERED 
	(
		[File_id]
	)  ON [PRIMARY] 
) ON [PRIMARY]
GO




