USE [master]

IF EXISTS (SELECT name FROM master.dbo.sysdatabases WHERE name = N'dotForum2004')
	DROP DATABASE [dotForum2004]
GO

CREATE DATABASE [dotForum2004]
GO
