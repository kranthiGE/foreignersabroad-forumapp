using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using Forums_cs.Classes;
namespace Forums_cs
{
	/// <summary>
	/// Summary description for CntrysVisited.
	/// </summary>
	public partial class CntrysVisited : System.Web.UI.Page
	{
		User objUser = null;
		ThreadMgr objTMgr = null;
		ArrayList alist = null;
		DataSet ds = new DataSet();
		DataRow drow=null;
		DataTable dtable=null;
		clsError objError = null;
		private string strTypename = null;

		public string TypeName
		{
			get
			{
				return strTypename;
			}
			set
			{
				strTypename = value;
			}
		}

		protected void Page_Load(object sender, System.EventArgs e)
		{
			
			if(!IsPostBack)
			{
				
				fillingDataset();
				Binddata();
				
			}
			btnSave.Attributes["onclick"] = "javascript:return closeWin()";
		}
		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    

		}
		#endregion

		public DataSet fillingDataset()
		{
			dtable=ds.Tables.Add("country");
			dtable.Columns.Add("TypeName",typeof(string));
			dtable.Columns.Add("Cntryid",typeof(string));
			return ds;
		}

		public void Binddata()
		{
			alist = new ArrayList();
			try
			{
				objError = new clsError();
				objUser = new User();
				if(Session["CntName"]!=null)
				{
					dgcts.DataSource = (DataSet)Session["CntName"];
					dgcts.DataBind();
				}
				else
				{
					dgcts.DataSource = ds;
					dgcts.DataBind();
				}									 	
			
			}
			catch(Exception ex)
			{
				string strMsg = ex.Message.ToString();
			}
		}
		public DataSet ddldgCtsBind()
		{
			DataSet dsddl = new DataSet();
			objTMgr = new ThreadMgr();
			objError = new clsError();
			dsddl =	objTMgr.GetCountries(ref objError);			
			return dsddl;
		}
		protected void dgcts_ItemCommand(object source, System.Web.UI.WebControls.DataGridCommandEventArgs e)
		{
			bool flag = false;
			DataRow drow_s = null;
			DataRow[] drows = null;
			alist = new ArrayList();
			objUser = new User();
			objError = new clsError();
			if(e.CommandName == "delete")
			{
				HtmlInputHidden hidid = (HtmlInputHidden)e.Item.FindControl("HidctsId");
				Label lblTypeName = (Label)e.Item.FindControl("lblName");
				if(Session["CntName"]!=null)
				{
					ds = (DataSet)Session["CntName"];
					for(int i=0;i<ds.Tables[0].Rows.Count;i++)
					{
						if(ds.Tables[0].Rows[i]["Cntryid"].ToString() == hidid.Value.Trim())
						{
							drow_s = ds.Tables[0].Rows[i];
							ds.Tables[0].Rows.Remove(drow_s);
						}						
					}
					Session["CntName"] = ds;
					Binddata();					
				}				
			}
			if(e.CommandName == "Add")
			{
				
				DropDownList ddlcts = (DropDownList)e.Item.FindControl("ddlListCts");
				if(Session["CntName"]!=null)
				{
					ds = (DataSet)Session["CntName"];
					for(int i=0;i<ds.Tables[0].Rows.Count;i++)
					{
						if(ds.Tables[0].Rows[i]["Cntryid"].ToString() == ddlcts.SelectedValue.Trim())
						{
							flag = true;
							lblError.ForeColor = Color.Red;
							lblError.Text = "<b>This Country already exists</b>";
						}							
					}
					if(!flag)
					{
						lblError.Text = null;
						drow_s = getDatarow(ds,ddlcts.SelectedItem.Text,ddlcts.SelectedValue);					
						Session["CntName"] = ds;					
					}
					
				}
				else
				{
					fillingDataset();
					drow_s = getDatarow(ds,ddlcts.SelectedItem.Text,ddlcts.SelectedValue);
					Session["CntName"] = ds;
				}
				Binddata();				
				
			}
		}
		public DataRow getDatarow(DataSet dsRow,string typeName,string TypeId)
		{			
			drow=dsRow.Tables[0].NewRow();			
			drow[0]=typeName;
			drow[1]=TypeId;			
			dsRow.Tables[0].Rows.Add(drow);
			return drow;
		}

		
	}
}
