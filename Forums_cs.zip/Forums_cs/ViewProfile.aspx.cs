using System;
using System.Collections;
using System.Configuration;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using Forums_cs.Classes;
namespace Forums_cs
{
	/// <summary>
	/// Summary description for ViewProfile.
	/// </summary>
	public partial class ViewProfile : System.Web.UI.Page
	{
		DataSet ds = null;
		User objUser = null;
		clsError objError = null;
		string strName = null;
		protected System.Web.UI.WebControls.Panel pnlGuest;
		string strId = null;
		string strTopic = null;
		string strTopic1 = null;
		protected void Page_Load(object sender, System.EventArgs e)
		{
			if(Request.QueryString["id"]!=null)
			{
				strId = Request.QueryString["id"].ToString();
			}
			if(Request.QueryString["topicid"]!=null)
			{
				strTopic = Request.QueryString["topicid"].ToString();
			}
			if(Request.QueryString["topicid1"]!=null)
			{
				strTopic1 = Request.QueryString["topicid1"].ToString();
			}

			if(Session["Uname"]!=null)
			{
				if(Session["Name"]!=null)
				{
					lblUserName.Text = Session["Name"].ToString();
				}
				if(Session["emailid"]!=null)
				{
					strName = Session["emailid"].ToString();	
					if(!IsPostBack)
					{
						Filldetails(strName);			
					}					
				}
				if(Session["Uname"]!=null)
				{
					pnlLoginImage.Visible = true;
					
					pnluser.Visible = true;
					pnlTopLogin.Visible = false;
					pnlBottomLogin.Visible = false;
					pnlBottomLogout.Visible = true;
					pnlMiddleLogin.Visible = false;
					pnlMiddleLogout.Visible = true;
				}
			}
			else
			{
				pnlMailSent.Visible = true;
				pnlProfile.Visible = false;
			}			
			string url = "ImagePopup.aspx?send="+lblUname.Text.Trim();
			lnkbtnMsg.Attributes["onclick"] = "javascript:return SendMsg('"+url+"')";
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    

		}
		#endregion


		public void Filldetails(string name)
		{
			try
			{
				string strname = null;
				int strLen = 0;
				ds = new DataSet();
				objUser = new User();
				objError = new clsError();
				if(name!=null)
				{
					ds = objUser.GetUserProfile(name.Trim(),ref objError);
					if(ds.Tables[0].Rows.Count!=0)
					{
						int count = ds.Tables[0].Rows.Count;
						for(int i=0;i<=count-1;i++)
						{
							strname = ds.Tables[0].Rows[i]["typename"].ToString();
							strLen = strname.Length;
							strname = strname.Substring(0,1).ToUpper() + strname.Substring(1,strLen-1).ToLower();
							if(i != count-1)
							{
								lblPlaces.Text += " "+strname+",";
							}
							else
							{
								lblPlaces.Text += " "+strname;
							}
						}
					}
					if(ds.Tables[1].Rows.Count!=0)
					{
						lblUname.Text = ds.Tables[1].Rows[0]["Fname"].ToString();						
						if(ds.Tables[1].Rows[0]["joindate"] != System.DBNull.Value)
						{
							lbldate.Text = ds.Tables[1].Rows[0]["joindate"].ToString();
						}
						else
						{
							lbldate.Text = "Unknown";
						}						
						if(ds.Tables[1].Rows[0]["country"] != System.DBNull.Value)
						{						
							lblLocation.Text = ds.Tables[1].Rows[0]["country"].ToString();	
						}
						else
						{
							lblLocation.Text = "Unknown";
						}
						if(ds.Tables[1].Rows[0]["Postcount"] != System.DBNull.Value)
						{
							lblNoofPosts.Text = ds.Tables[1].Rows[0]["Postcount"].ToString(); 
						}
						else
						{
							lblNoofPosts.Text = "Unknown";
						}
						hidemail.Value = ds.Tables[1].Rows[0]["email"].ToString();
						if(ds.Tables[1].Rows[0]["flagpath"] != System.DBNull.Value)
						{
							imgCflag.ImageUrl = ds.Tables[1].Rows[0]["flagpath"].ToString();
						}
						else
						{
							imgCflag.Visible = false;
						}
						string strpvtcnt = ds.Tables[1].Rows[0]["Pvtcnt"].ToString();
						if(strpvtcnt == "Y")
						{
							msgrow.Visible = true;
						}
						if(ds.Tables[1].Rows[0]["imgpath"] != System.DBNull.Value && ds.Tables[1].Rows[0]["imgpath"].ToString() != String.Empty)
						{
							imgUser.ImageUrl = ds.Tables[1].Rows[0]["imgpath"].ToString();
						}
						else
						{
							imgUser.ImageUrl = ConfigurationSettings.AppSettings["nophoto"].ToString();
						}
					}
					if(ds.Tables[2].Rows.Count!=0)
					{
						if(ds.Tables[2].Rows[0]["Nationality"] != System.DBNull.Value)
						{						
							if(ds.Tables[2].Rows[0]["Nationality"].ToString() != "--Select Nationality--")
							{
								lblNation.Text = ds.Tables[2].Rows[0]["Nationality"].ToString();	
							}
							else
							{
								lblNation.Text = "Unknown";
							}							
						}
						else
						{
							lblNation.Text = "Unknown";
						}
					}
					if(ds.Tables[2].Rows.Count!=0)
					{
						if(ds.Tables[2].Rows[0]["abtmyself"] != System.DBNull.Value)
						{						
							lblAbtmyself.Text = ds.Tables[2].Rows[0]["abtmyself"].ToString();	
						}
						else
						{
							lblAbtmyself.Text = "Unknown";
						}
					}
					if(ds.Tables[2].Rows.Count!=0)
					{
						if(ds.Tables[2].Rows[0]["city"] != System.DBNull.Value)
						{
							lblLocation.Text = ds.Tables[2].Rows[0]["city"].ToString();
						}
						else
						{
							lblLocation.Text = "Unknown";
						}
					}
					if(ds.Tables[2].Rows.Count!=0)
					{
						if(ds.Tables[2].Rows[0]["state"] != System.DBNull.Value)
						{
							lblState.Text = ds.Tables[2].Rows[0]["state"].ToString();
						}
						else
						{
							lblState.Text = "Unknown";
						}
					}
				}
			}
			catch(Exception ex)
			{
				string str = ex.Message.ToString();
			}
		}

		protected void btnBack_Click(object sender, System.EventArgs e)
		{
			if(strTopic == null)
			{
				Response.Redirect("threadView.aspx?id="+strId);
			}
			else if(strTopic1 != null)
			{
				Response.Redirect("topicView.aspx?id="+strTopic+"&id1="+strTopic1);
			}
			else
			{
				Response.Redirect("topicView.aspx?id="+strTopic);
			}
		}

		protected void lnkbtnBotLogout_click(object sender, System.EventArgs e)
		{
			Session.Abandon();
			
			Response.Redirect("Home.aspx");
		}

		protected void lnkbtnLogout_Click(object sender, System.EventArgs e)
		{
			Session.Abandon();				
//			pnluser.Visible = false;
//			pnlTopLogin.Visible = true;			
//			pnlLoginImage.Visible = false;
			Response.Redirect("Home.aspx");
		}

		protected void lnkbtnSetting_Click(object sender, System.EventArgs e)
		{
			Response.Redirect("MySettings.aspx?uid=Edit");
		}

		protected void btnclose_ServerClick(object sender, System.EventArgs e)
		{
			if(strTopic == null)
			{
				Response.Redirect("threadView.aspx?id="+strId);
			}
			else if(strTopic1 != null)
			{
				Response.Redirect("topicView.aspx?id="+strTopic+"&id1="+strTopic1);
			}
			else
			{
				Response.Redirect("topicView.aspx?id="+strTopic);
			}
		}
	}
}
