using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using dotForumIncludes;
using System.Data.SqlClient;
using System.Configuration;
using Forums_cs.Classes;
namespace Forums_cs
{
	/// <summary>
	/// Summary description for topicView1.
	/// </summary>
	public partial class topicView1 : System.Web.UI.Page
	{
		public includeFunctions myIncludes = new includeFunctions();
		protected System.Web.UI.WebControls.ImageButton imgbtnLogout;
		protected System.Web.UI.WebControls.Label topicName;		
		protected System.Web.UI.WebControls.DropDownList listTopics;
		protected System.Web.UI.WebControls.Button sorter;
		
		public string thisTopicId;
		public string thisTopicId1;
		DataSet dsCts = null;
		clsError objError = null;
		protected System.Web.UI.WebControls.DropDownList ddlCountries;
		protected System.Web.UI.WebControls.DropDownList ddlUSStates;
		protected System.Web.UI.WebControls.Panel pnlStates;
		protected System.Web.UI.WebControls.DropDownList ddlSpecific;
		protected System.Web.UI.WebControls.Panel pnlCntry;
		protected System.Web.UI.HtmlControls.HtmlInputButton btnViewThreads;
		ThreadMgr objThreadMgr = null;
		User objUser = null;
		string TopicId = null;

		protected void Page_Load(object sender, System.EventArgs e)
		{
			objThreadMgr = new ThreadMgr();
			objError = new clsError();
			if(Session["Uname"]!=null)
			{
				pnlLoginImage.Visible = true;								
				pnluser.Visible = true;
				pnlTopLogin.Visible = false;
				pnlBottomLogin.Visible = false;
				pnlBottomLogout.Visible = true;
				pnlMiddleLogin.Visible = false;
				pnlMiddleLogout.Visible = true;
				if(Session["Name"]!=null)
				{
					lblUserName.Text = Session["Name"].ToString();
				}				
				objUser = new User();
				if(objUser.IsMyFav(Session["Uname"].ToString(),ref objError))
				{
					imgBtnMyFav.Visible = true;
				}
			}
			else
			{
				lblUserName.Text = null;
			}
			try
			{
				if(Request.QueryString["id"] != null)
				 {
					thisTopicId = Request.QueryString["id"];
				}
				if(Request.QueryString["id1"] != null)
				{
					thisTopicId1 = Request.QueryString["id1"];
					//thisTopicId = thisTopicId + thisTopicId1;
				}
				if(thisTopicId != thisTopicId1 && thisTopicId1!=null)
				{
					TopicId = "T"+thisTopicId+thisTopicId1;
					if(objThreadMgr.CheckCatExist(TopicId,ref objError) == false)
					{
						Session["CatName"] = myIncludes.getTopicName(thisTopicId)+"-"+myIncludes.getTopicName(thisTopicId1);
					}
				}
				else
				{
					TopicId = thisTopicId;
				}
			}
				//INSTANT C# TODO TASK: No C# equivalent to 'When'
			catch (Exception ex) // When 1=1
			{
				Response.Redirect("ErrorPage.aspx");
			}			
			if (! Page.IsPostBack)
			{

//				if(Session["CatName"] == null)
//				{
//				
//					//### POPULATE TOPICS DROP-DOWN
//					SqlConnection myConnection = new SqlConnection(ConfigurationSettings.AppSettings["forumDSN"]);
//					//SqlCommand myCommand = new SqlCommand("SELECT bcId, upper(substring(bctitle, 1,1)) + lower(substring(bctitle,2,len(bctitle)-1)) As bcTitle FROM forumTopics where parentid is null", myConnection);
//					SqlCommand myCommand = new SqlCommand("SELECT bcId, bcTitle FROM forumTopics", myConnection);
//
//					myConnection.Open();
//
//					SqlDataReader myReader = null;
//					myReader = myCommand.ExecuteReader();
//
//					listTopics.Items.Add(new ListItem("All", "0"));
//			
//					while (myReader.Read())
//					{
//						listTopics.Items.Add(new ListItem(myReader.GetString(1), myReader.GetString(0).ToString()));
//					}
//
//					listTopics.SelectedValue = TopicId.ToString();
//
//					if (listTopics.SelectedIndex != 0)
//					{
//						//topicName.Text = "<b>" + myIncludes.getTopicName(thisTopicId) + "</b> ";
						startLink.Visible = true;
						startLink.NavigateUrl = "StartThread.aspx?id=" + TopicId ;
						hyperlnkNew.NavigateUrl = "StartThread.aspx?id=" + TopicId ;
//					}
//					else
//					{
//						//topicName.Text = "<b>All</b>";
//						startLink.Visible =false;
//					}
				}
				string strImgurl = objThreadMgr.GetImagPath(TopicId,ref objError);
				if(strImgurl != null && strImgurl != "")
				{
					imgCountry.ImageUrl = strImgurl;
				}
				else
				{
					imgCountry.ImageUrl = "fa_images/default_image.JPG";
				}

				bindData();
			if(lblSub.Text.CompareTo("") == 0)
			{
				if(thisTopicId != null)
				{
					lblSub.Text = myIncludes.getTopicName(thisTopicId);
				}
				if(thisTopicId1 != null && thisTopicId.Trim()!=thisTopicId1.Trim())
				{
					lblSub.Text += "-"+myIncludes.getTopicName(thisTopicId1);
				}
			}
//			}
//			else
//			{
//				listTopics.SelectedValue = listTopics.SelectedItem.Value;
//			}
		}
		public void bindData()
		{

			SqlConnection myConnection = new SqlConnection(ConfigurationSettings.AppSettings["forumDSN"]);

			string dataSQL = "";
						
			if (TopicId != null && TopicId != "0")
			{				
				dataSQL = "SELECT psId, psName, psEmail, Left(psSubject, 100) As psSubject, psDate, psRelBcId, psLastUpdate FROM forumThreads WHERE psRelTopId = '0' AND psRelBcId = '" + TopicId + "' ORDER BY psLastUpdate DESC";		
			}			
			else
			{
				dataSQL = "SELECT psId, psName, psEmail, Left(psSubject, 100) As psSubject, psDate, psRelBcId, psLastUpdate FROM forumThreads WHERE psRelTopId = '0' ORDER BY psLastUpdate DESC";
				hyperlnkNew.Visible = false;
				startLink.Visible = false;
				lblSub.Visible = false;
			}

			SqlCommand myCommand = new SqlCommand(dataSQL, myConnection);

			SqlDataAdapter myDA = new SqlDataAdapter();
			myDA.SelectCommand = myCommand;

			DataSet myDS = new DataSet();
			myDA.Fill(myDS, "forumThreads");

			//### IF THERE ARE NO THREADS, REDIRECT TO TOPIC PAGE
			if (myDS.Tables["forumThreads"].Rows.Count == 0)
			{
				//listTopics.Visible = false;
				dotForumDisplay.DataSource = myDS;
				dotForumDisplay.DataBind();
				// Response.Redirect("index.aspx")
				hyperlnkNew.NavigateUrl = "StartThread.aspx?id=" + TopicId ;
				if (thisTopicId == null || thisTopicId == "")
				{
					pnlError.Visible = true;
					dotForumDisplay.Visible = false;
					//messageCenter.InnerHtml = "<p><font color='Red'>There are currently no threads in any topic.<p></font><a class=\"LinkHead\" href=\"forum.aspx\">View all Forum Topics</a>";
				}
				else
				{
					pnlError.Visible = true;
					dotForumDisplay.Visible = false;
					//messageCenter.InnerHtml = "<p><font color='Red'>There are currently no threads in this topic.</font><p><a class=\"LinkHead\" href=\"topicView.aspx\">View Threads in all Topics</a>";
				}
			}
			else
			{
				dotForumDisplay.DataSource = myDS;
				dotForumDisplay.DataBind();

				//### DISABLE NEXT/PREV IF LESS THAN dotForumDisplay.PageSize
				if (myDS.Tables[0].Rows.Count < dotForumDisplay.PageSize)
				{
					dotForumDisplay.PagerStyle.Visible = false;
				}
			}

		}
		public void dotForumDisplay_Paged(object sender, DataGridPageChangedEventArgs e)
		{
			dotForumDisplay.CurrentPageIndex = e.NewPageIndex;
			bindData();
		}


		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{   
		}
		#endregion

		private void dotForumDisplay_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			
		}
		

		protected void lnkbtnLogout_Click(object sender, System.EventArgs e)
		{
			Session.Abandon();			
			lblUserName.Text = null;			
			Response.Redirect("Home.aspx");
		}

		protected void lnkbtnBotLogout_click(object sender, System.EventArgs e)
		{
			Session.Abandon();
			
			Response.Redirect("Home.aspx");
		}
		protected void lnkbtnSetting_Click(object sender, System.EventArgs e)
		{
			Response.Redirect("MySettings.aspx?uid=Edit");
		}
		

		protected void imgbtnSearch_ServerClick(object sender, System.Web.UI.ImageClickEventArgs e)
		{
			Response.Redirect("Search.aspx?srch="+textfield.Value.Trim());
		}

		protected void listTopics_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			Response.Redirect("topicView.aspx?id=" + listTopics.SelectedItem.Value);
		}

		protected void dgDisplay_OnitemCmd(object source, System.Web.UI.WebControls.DataGridCommandEventArgs e)
		{
			if(e.CommandName == "ViewProfile")
			{
				HtmlInputHidden HidEmail = (HtmlInputHidden)e.Item.FindControl("HidEmail");
				if(Session["emailid"]!=null)
				{
					Session["emailid"] = null;
				}
				Session["emailid"] = HidEmail.Value;
				Response.Redirect("ViewProfile.aspx?topicid="+TopicId);
			}		

		}
		protected void dgDisplay_ItemDataBound(object sender, System.Web.UI.WebControls.DataGridItemEventArgs e)
		{
			int sublen = 0;
			string strSub = null;
			if(e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
			{
				System.Web.UI.WebControls.Image imgFlag = (System.Web.UI.WebControls.Image)e.Item.FindControl("Image1");
				if(imgFlag.ImageUrl == "")
				{
					imgFlag.Visible = false;
				}
				Label lblDgsub = (Label)e.Item.FindControl("lblDgSubject");
				sublen = lblDgsub.Text.LastIndexOf("]");
				lblSub.Text = lblDgsub.Text.Substring(0,sublen+1);
				lblDgsub.Text = lblDgsub.Text.Substring(sublen+1,(lblDgsub.Text.Length)-(sublen+1));
			}
		}

		public void bindData(string strIds)
		{

			SqlConnection myConnection = new SqlConnection(ConfigurationSettings.AppSettings["forumDSN"]);

			string dataSQL = "";
						
			
			dataSQL = "SELECT psId, psName, psEmail, Left(psSubject, 100) As psSubject, psDate, psRelBcId, psLastUpdate FROM forumThreads WHERE psRelTopId = '0' AND psRelBcId in (" + strIds + ") ORDER BY psLastUpdate DESC";		
			

			SqlCommand myCommand = new SqlCommand(dataSQL, myConnection);

			SqlDataAdapter myDA = new SqlDataAdapter();
			myDA.SelectCommand = myCommand;

			DataSet myDS = new DataSet();
			myDA.Fill(myDS, "Threads");

			//### IF THERE ARE NO THREADS, REDIRECT TO TOPIC PAGE
			if (myDS.Tables["Threads"].Rows.Count == 0)
			{
				//listTopics.Visible = false;
				dotForumDisplay.DataSource = myDS;
				dotForumDisplay.DataBind();
				// Response.Redirect("index.aspx")
				hyperlnkNew.NavigateUrl = "StartThread.aspx?id=" + TopicId ;
				if (thisTopicId == null || thisTopicId == "")
				{
					pnlError.Visible = true;
					dotForumDisplay.Visible = false;
					//messageCenter.InnerHtml = "<p><font color='Red'>There are currently no threads in any topic.<p></font><a class=\"LinkHead\" href=\"forum.aspx\">View all Forum Topics</a>";
				}
				else
				{
					pnlError.Visible = true;
					dotForumDisplay.Visible = false;
					//messageCenter.InnerHtml = "<p><font color='Red'>There are currently no threads in this topic.</font><p><a class=\"LinkHead\" href=\"topicView.aspx\">View Threads in all Topics</a>";
				}
			}
			else
			{
				dotForumDisplay.DataSource = myDS;
				dotForumDisplay.DataBind();

				//### DISABLE NEXT/PREV IF LESS THAN dotForumDisplay.PageSize
				if (myDS.Tables[0].Rows.Count < dotForumDisplay.PageSize)
				{
					dotForumDisplay.PagerStyle.Visible = false;
				}
			}

		}

		protected void imgBtnMyFav_Click(object sender, ImageClickEventArgs e)
		{
			objUser = new User();
			objError = new clsError();
			if(Session["Uname"] != null)
			{		
				bindData(objUser.GetFavIds(Session["Uname"].ToString(),ref objError));
			}

		}
	}
}
