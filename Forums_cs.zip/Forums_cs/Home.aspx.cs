using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using Forums_cs.Classes;
using dotForumIncludes;
namespace Forums_cs
{
	/// <summary>
	/// Summary description for Home.
	/// </summary>
	public partial class Home : System.Web.UI.Page
	{
		
		public includeFunctions myInclude = new includeFunctions();
		DataSet dsCats = null;
		DataSet dsStates = null;
		User objUser = null;
		protected System.Web.UI.WebControls.DataGrid dotForumDisplay;
		protected System.Web.UI.WebControls.DataGrid dgThread;
		protected System.Web.UI.HtmlControls.HtmlGenericControl Font1;
		protected System.Web.UI.WebControls.Label lblusercnt;
		clsError objError = null;

		int strLen = 0;
		int strsublen = 0;
		string strSub = null;
		string strOrg = null;
		
		protected void Page_Load(object sender, System.EventArgs e)
		{			
		
			if(Session["Uname"]!=null)
			{
				pnlTopLogin.Visible = false;
				pnlLoginImage.Visible = true;
				pnlBottomLogin.Visible = false;
				pnlBottomLogout.Visible = true;
				pnluser.Visible = true;
				pnlMiddleLogin.Visible = false;
				pnlMiddleLogout.Visible = true;
				if(Session["Name"]!=null)
				{
					lblUserName.Text = Session["Name"].ToString();
				}	
			}
			if(!IsPostBack)
			{	


				InfoCenter();

				ddlCtsList1.DataSource = BindCategories();				
				ddlCtsList1.DataBind();		
				ddlCtsList1.Items.Insert(0,new ListItem("--Select Country--","0"));
				ddlCtsList1.SelectedValue = "0";	
	
				ddlCtsList2.DataSource = BindCategories();				
				ddlCtsList2.DataBind();		
				ddlCtsList2.Items.Insert(0,new ListItem("--Select Country--","0"));
				ddlCtsList2.SelectedValue = "0";	
			}
			else if(Request["__EVENTTARGET"] == "Search")
			{
				Response.Redirect("Search.aspx?srch="+txtBoxSearch.Value.Trim());
			}
			if(Request.QueryString["qstr"] != null)
			{
				if(Request.QueryString["qstr"].ToString() == "logout")
				{
					Logout();
				}
			}
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    

		}
		#endregion

		public void Logout()
		{
			Session.Abandon();
			pnlTopLogin.Visible = true;		
			pnlLoginImage.Visible = false;
			pnluser.Visible = false;
			Response.Redirect("Home.aspx");
		}

		protected void lnkbtnLogout_Click(object sender, System.EventArgs e)
		{
			Session.Abandon();
			pnlTopLogin.Visible = true;		
			pnlLoginImage.Visible = false;
			pnluser.Visible = false;
			Response.Redirect("Home.aspx");
		}
		protected void lnkbtnBotLogout_click(object sender, System.EventArgs e)
		{
			Session.Abandon();
			pnlTopLogin.Visible = true;			
			pnlLoginImage.Visible = false;
			pnluser.Visible = false;
			Response.Redirect("Home.aspx");
		}

		protected void lnkbtnSetting_Click(object sender, System.EventArgs e)
		{
			Response.Redirect("MySettings.aspx?uid=Edit");
		}

		

		public DataSet BindCategories()
		{
			dsCats = new DataSet();
			objUser = new User();
			objError = new clsError();			
			dsCats = objUser.GetCats(ref objError);		
			if(dsCats.Tables[0].Rows.Count==0)
			{
				dsCats = null;
			}			
			
            return dsCats;			
		}

	

		public string GetThreadsUrl(string strCntryCodes)
		{
			string strUrl = null;
			try
			{
				strUrl = "topicView.aspx?id="+strCntryCodes;
			}
			catch(Exception ex)
			{
				objError.boolErrorOccurred = true;
				objError.strMessage = "Error:"+ex.Message.ToString();
			}
			return strUrl;
		}

		private void lnkbtnListAll_Click(object sender, System.Web.UI.ImageClickEventArgs e)
		{
			Response.Redirect("forum.aspx");
		}

		protected void ddlCtsList_SelectedIndexChanged_1(object sender, System.EventArgs e)
		{
			if(ddlCtsList1.SelectedItem.Value != "0")
			{
				Response.Redirect("topicView.aspx?id="+ddlCtsList1.SelectedItem.Value.Trim());
			}	
		}
	

		public DataSet BindState(string Parentid)
		{
			dsCats = new DataSet();
			objUser = new User();
			objError = new clsError();			
			dsCats = objUser.GetStates(Parentid,ref objError);		
			if(dsCats.Tables[0].Rows.Count==0)
			{
				dsCats = null;
			}	
			return dsCats;
		}

		protected void ddlCtsList1_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			dsStates = new DataSet();
			if(ddlCtsList1.SelectedItem.Value != "0")
			{
				dsStates = BindState(ddlCtsList1.SelectedValue.Trim());
				if(dsStates != null)
				{
					ddlStates1.DataSource = dsStates;
					ddlStates1.DataBind();
					ddlStates1.Items.Insert(0,new ListItem("--Select State/Region--","0"));
					ddlStates1.SelectedValue = "0";
				}
				else
				{
					ddlStates1.Items.Clear();
					ddlStates1.Items.Insert(0,new ListItem("--No State/Region--","0"));
					ddlStates1.SelectedValue = "0";
					
				}
				
			}
		}

		protected void ddlCtsList2_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			dsStates = new DataSet();
			if(ddlCtsList2.SelectedItem.Value != "0")
			{
				dsStates = BindState(ddlCtsList2.SelectedValue.Trim());
				if(dsStates != null)
				{
					ddlStates2.DataSource = dsStates;
					ddlStates2.DataBind();
					ddlStates2.Items.Insert(0,new ListItem("--Select State/Region--","0"));
					ddlStates2.SelectedValue = "0";
				}
				else
				{
					ddlStates2.Items.Clear();
					ddlStates2.Items.Insert(0,new ListItem("--No State/Region--","0"));
					ddlStates2.SelectedValue = "0";
				}
			}
		}

		protected void imgbtnForum_Click(object sender, System.Web.UI.ImageClickEventArgs e)
		{
			string Url = null;
			
			if(ddlCtsList1.SelectedValue != "0" && ddlCtsList2.SelectedValue != "0")
			{
				Url = "topicView.aspx?id="+ddlCtsList1.SelectedValue.Trim()+"&id1="+ddlCtsList2.SelectedValue.Trim();
			}
			if(ddlCtsList1.SelectedValue != "0" && ddlCtsList2.SelectedValue != "0" && ddlStates1.SelectedValue != "0" && ddlStates2.SelectedValue == "0")
			{
				Url = "topicView.aspx?id="+ddlStates1.SelectedValue.Trim()+"&id1="+ddlCtsList2.SelectedValue.Trim();
			}	
			if(ddlStates1.SelectedValue != "0" && ddlStates2.SelectedValue != "0" && ddlCtsList1.SelectedValue != "0" && ddlCtsList2.SelectedValue != "0")
			{
				Url = "topicView.aspx?id="+ddlStates1.SelectedValue.Trim()+"&id1="+ddlStates2.SelectedValue.Trim();
			}
			if(ddlCtsList1.SelectedValue != "0" && ddlCtsList2.SelectedValue != "0" && ddlStates2.SelectedValue != "0" && ddlStates1.SelectedValue == "0")
			{
				Url = "topicView.aspx?id="+ddlCtsList1.SelectedValue.Trim()+"&id1="+ddlStates2.SelectedValue.Trim();			
			}		
			if(ddlCtsList1.SelectedValue != "0" && ddlStates1.SelectedValue == "0" && ddlStates2.SelectedValue != "0" && ddlStates2.SelectedValue != "")
			{
				Url = "topicView.aspx?id="+ddlCtsList1.SelectedValue.Trim()+"&id1="+ddlStates2.SelectedValue.Trim();
			}			
			if(Url != null)
			{
				Response.Redirect(Url);
			} 
		}		

		public void InfoCenter()
		{
			objUser = new User();
			DataSet dsInfo = new DataSet();
			try
			{
				dsInfo = objUser.getTop5Cats();
				if(dsInfo != null)
				{
					if(dsInfo.Tables.Count != 0)
					{
						dgCat.DataSource = dsInfo;
						dgCat.DataBind();				
					}
				}

				dsInfo = objUser.getTop5Threads();
				if(dsInfo != null)
				{
					dgThreads.DataSource = dsInfo;
					dgThreads.DataBind();
				}	
							
				lbluserreg.Text = objUser.GetUserRegistered();
			}
			catch(Exception ex)
			{
				string strError = ex.Message.ToString();
			}
		}

		protected void dgThreads_ItemDataBound(object sender, System.Web.UI.WebControls.DataGridItemEventArgs e)
		{
			if(e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
			{
//				
				Label lblSubject = (Label)e.Item.FindControl("lblSub");
				if(lblSubject.Text.Length > 51)
				{
					lblSubject.Text = lblSubject.Text.Substring(0,50) + "...";
				}
				Label lblDate = (Label)e.Item.FindControl("lblDate");
				DateTime dtime = Convert.ToDateTime(lblDate.Text);
				lblDate.Text = dtime.Date.ToShortDateString();
//				
			}
		}
		protected void imgbtnGo_Click(object sender, System.Web.UI.ImageClickEventArgs e)
		{
			Response.Redirect("Search.aspx?srch="+txtBoxSearch.Value.Trim());
		}

		//<asp:Label ID="lblusercnt" Runat="server" CssClass="blackBold"></asp:Label>&nbsp;<font class="docLink_std">Online.</font>
	}
}
