using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Configuration;
using dotForumIncludes;
namespace Forums_cs
{
	/// <summary>
	/// Summary description for WebForm1.
	/// </summary>
	public partial class WebForm1 : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.ImageButton imgbtnLogout;
		protected System.Web.UI.WebControls.Panel pnlGuest;		
		public includeFunctions myIncludes = new includeFunctions();

		
		
		protected void Page_Load(object sender, System.EventArgs e)
		{
			if(Session["Uname"]!=null)
			{
				pnlLoginImage.Visible = true;
			
			
				pnluser.Visible = true;
				pnlTopLogin.Visible = false;
				if(Session["Name"]!=null)
				{
					lblUserName.Text = Session["Name"].ToString();
				}				
			}
			else
			{
				lblUserName.Text = null;
			}
			if (!Page.IsPostBack)
			{
				bindData();								
			}
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.imgbtnSearch.ServerClick += new System.Web.UI.ImageClickEventHandler(this.imgbtnSearch_ServerClick);

		}
		#endregion

		public void bindData()
		{

			SqlConnection myConnection = new SqlConnection(ConfigurationSettings.AppSettings["forumDSN"]);

			SqlCommand myCommand = new SqlCommand("SELECT bcId,Imgpath,Left(bcTitle, 100) As bcTitle, bcDesc, bcOrder, bcLastUpdate FROM forumTopics ORDER BY bcTitle, bcLastUpdate DESC", myConnection);

			SqlDataAdapter myDA = new SqlDataAdapter();
			myDA.SelectCommand = myCommand;

			DataSet myDS = new DataSet();
			myDA.Fill(myDS);

			dotForumDisplay.DataSource = myDS;
			dotForumDisplay.DataBind();

			//### DISABLE NEXT/PREV IF LESS THAN dotForumDisplay.PageSize
			if (myDS.Tables[0].Rows.Count < dotForumDisplay.PageSize)
			{
				dotForumDisplay.PagerStyle.Visible = false;
			}

		}
		public void dotForumDisplay_Paged(object sender, DataGridPageChangedEventArgs e)
		{
			dotForumDisplay.CurrentPageIndex = e.NewPageIndex;
			bindData();
		}
		public void dgForum_dataBound(Object sender,DataGridItemEventArgs e)
		{
//			string strTitle = null;
//			int strLen = 0;
//			if(e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
//			{				
//				Label lblTitle = (Label)e.Item.FindControl("lblTitle");
//				strTitle = lblTitle.Text.Trim();
//				if(strTitle != null && strTitle != "")
//				{
//					strLen = strTitle.Length;
//					strTitle = strTitle.Substring(0,1).ToUpper() + strTitle.Substring(1,strLen-1).ToLower();
//					lblTitle.Text = strTitle;
//				}
//			}
		}
		public object drawThreadLink(int thisId)
		{
			SqlConnection myConnection = new SqlConnection(ConfigurationSettings.AppSettings["forumDSN"]);
			SqlCommand myCommand = new SqlCommand("SELECT COUNT(*) FROM forumThreads WHERE psRelBcId = " + thisId, myConnection);

			myConnection.Open();
			int totalRecords =  Convert.ToInt16(myCommand.ExecuteScalar());
			myConnection.Close();

			object returnStr = null;
			if (totalRecords > 0)
			{
				returnStr = "<a class=\"listItemLink\" href=\"topicView.aspx?id=" + thisId + "\">";
			}

			return returnStr;

		}


		protected void lnkbtnLogout_Click(object sender, System.EventArgs e)
		{
			Session.Abandon();
//			pnlLoginImage.Visible = true;			
//			lblUserName.Text = null;
//			
//			pnluser.Visible = false;
//			pnlTopLogin.Visible = true;			
//			pnlLoginImage.Visible = false;
			Response.Redirect("Home.aspx");
		}

		protected void lnkbtnSetting_Click(object sender, System.EventArgs e)
		{
			Response.Redirect("/Forums_cs/MySettings.aspx?uid=Edit");
		}

		private void imgbtnSearch_ServerClick(object sender, System.Web.UI.ImageClickEventArgs e)
		{
			Response.Redirect("/Forums_cs/Search.aspx?srch="+textfield.Value.Trim());
		}

	}
}
