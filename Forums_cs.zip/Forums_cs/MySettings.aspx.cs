using System;
using System.Collections;
using System.Configuration;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using Forums_cs.Classes;
namespace Forums_cs
{
	/// <summary>
	/// Summary description for MySettings.
	/// </summary>
	public partial class MySettings : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.Panel pnlGuest;
		
		User objUser = null;		
		clsError objError = null;
		Login objLogin = null;
		ThreadMgr objTMgr = null;
		DataSet dsddl = null;
		DataSet dsCts = null;

		

		string strQstr = null;
		protected void Page_Load(object sender, System.EventArgs e)
		{
			if(Session["Uname"] != null)
			{
				if(Session["Name"]!=null)
				{
					lblUserName.Text = Session["Name"].ToString();
				}
				pnlTopLogin.Visible = false;
				pnlLoginImage.Visible = true;
				pnlBottomLogout.Visible = true;
				pnlBottomLogin.Visible = false;
				pnlMiddleLogin.Visible = false;
				pnlMiddleLogout.Visible = true;
				if(Request.QueryString["uid"]!=null)
				{
					strQstr = Request.QueryString["uid"].ToString();
					if(strQstr == "Edit")
					{
						if(!IsPostBack)
						{
							ddlNationality.DataSource = FillRegCountries();
							ddlNationality.DataBind();
							ddlNationality.Items.Insert(0,"--Select Nationality--");
							ddlCntry.DataSource = FillRegCountries();
							ddlCntry.DataBind();
							ddlCntry.Items.Insert(0,"--Select Country--");
							UserInfo();	
							Binddata();
						}
					}
					if(Request.QueryString["qstr"] != null)
					{
						if(!IsPostBack)
						{
							if(Request.QueryString["qstr"] == "pnl")
							{
								pnlSuccess.Visible = true;
							}
						}
					}
				}
			}
			else
			{
				Response.Redirect("LoginPage.aspx?qstr=LoginUser");
			}
			btnUpdate.Attributes["onclick"] = "javascript:return Valid()";
			lnkbtnUpload.Attributes["onclick"] = "javascript:return ImgPopup()";
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    

		}
		#endregion


		protected void lnkbtnBotLogout_click(object sender, System.EventArgs e)
		{
			Session.Abandon();			
			Response.Redirect("Home.aspx");
		}
		public DataSet FillRegCountries()
		{
			dsddl = new DataSet();
			objError = new clsError();
			objTMgr = new ThreadMgr();
			dsddl =	objTMgr.GetRegCountries(ref objError);
			return dsddl;
		}

		protected void btnUpdate_Click(object sender, System.EventArgs e)
		{
			pnlSuccess.Visible = false;
			update();
		}

		public void update()
		{
			bool flag = false;
			objError = new clsError();
			objUser = new User();
			objLogin = new Login();
			objLogin.Uname = txtBoxEmail.Text;
			if(hidVal.Value.Trim() == "true")
			{
				flag = true;
				objLogin.OldPwd = txtBoxOldPwd.Text;
				if(objUser.CheckPwd(txtBoxEmail.Text.Trim(),txtBoxOldPwd.Text.Trim(),ref objError))
				{
					objLogin.NewPwd = txtBoxNewPwd.Text;
				}
			}		
			if(Session["IMGpath"] != null)
			{
				objLogin.ImgPath = Session["IMGpath"].ToString();
			}
			
			objLogin.Fname = txtBoxFname.Text;
			objLogin.State = txtBoxState.Text;
			if(ddlNationality.SelectedItem.Value != "--Select Nationality--")
			{
				objLogin.Nation = ddlNationality.SelectedItem.Text;
			}
			if(ddlCntry.SelectedItem.Value != "--Select Country--")
			{
				objLogin.Country = ddlCntry.SelectedItem.Text;
			}
			objLogin.FlagPath = ddlNationality.SelectedItem.Value;
			objLogin.AbtMyself = txtBoxabtMyself.Text;
			objLogin.City = txtBoxCity.Text;
			if(rdbtnYes.Checked)
			{
				objLogin.PvtCnt = "Y";
			}
			else
			{
				objLogin.PvtCnt = "N";
			}
			objUser.UpdateUserInfo(ref objLogin,flag,ref objError);
			if(objError.boolErrorOccurred == true)
			{
				lblError.ForeColor = Color.Red;
				lblError.Text = objError.strMessage;
			}
			else
			{
				pnlAccnt.Visible = false;
				pnlSuc.Visible = false;
				pnlRegCts.Visible = true;
			}
		}

		public void UserInfo()
		{
			objError = new clsError();
			objUser = new User();
			ArrayList alist = new ArrayList();
			alist = objUser.getuserInfo(Session["Uname"].ToString(),ref objError);
			if(alist.Count!=0)
			{
				txtBoxEmail.Text = alist[0].ToString();
				txtBoxFname.Text = alist[2].ToString();
				
				if(alist[5] != System.DBNull.Value)
				{
					if(alist[5].ToString() != "")
					{
						imguser.ImageUrl=alist[5].ToString();
					}
					else
					{
						imguser.Visible = false;
					}
				}
				else
				{
					imguser.Visible = false;
				}
				if(alist[6] != System.DBNull.Value)
				{
					if(alist[6].ToString() != "")
					{
						ddlCntry.Items.FindByText(alist[6].ToString()).Selected = true;
					}
				}
				
				txtBoxState.Text = alist[7].ToString();
				if(alist[8] != System.DBNull.Value || alist[8].Equals("") == false)
				{
					if(alist[8].ToString() != "")
					{
						ddlNationality.Items.FindByText(alist[8].ToString()).Selected = true;
					}
				}
				
				txtBoxabtMyself.Text = alist[9].ToString();
					
				
				txtBoxCity.Text = alist[10].ToString();

				if(alist[4].ToString() == "Y")
				{
					rdbtnYes.Checked = true;
				}
				else
				{
					rdbtnNo.Checked = true;
				}
				
			}
		}

		protected void lnkbtnSetting_Click(object sender, System.EventArgs e)
		{
			Response.Redirect("MySettings.aspx?uid=Edit");
		}

		protected void lnkbtnLogout_Click(object sender, System.EventArgs e)
		{
			Session.Abandon();
			Response.Redirect("Home.aspx");
		}

		protected void btnHome_Click(object sender, System.EventArgs e)
		{
			Response.Redirect("Home.aspx");
		}

		
		public void Binddata()
		{
			DataSet dsCts = new DataSet();
			try
			{
				objError = new clsError();
				objUser = new User();
				if(Session["Uname"] != null)
				{
					dsCts = objUser.GetSelectedCts(Session["Uname"].ToString(),ref objError);
					if(dsCts.Tables.Count!=0)
					{
						dgcts.DataSource = dsCts;
						dgcts.DataBind();
					}					 	
				}
			}
			catch(Exception ex)
			{
				string strMsg = ex.Message.ToString();
			}
		}

		protected void dgcts_ItemCommand(object source, System.Web.UI.WebControls.DataGridCommandEventArgs e)
		{
			objUser = new User();
			objError = new clsError();
			if(e.CommandName == "delete")
			{
				HtmlInputHidden hidid = (HtmlInputHidden)e.Item.FindControl("HidctsId");
				if(Session["Uname"]!=null)
				{
					objUser.RemoveCts(Session["Uname"].ToString().Trim(),hidid.Value,ref objError);
					if(objError.boolErrorOccurred == false)
					{
						lblError.Text = objError.strMessage;
						Binddata();
					}
					else
					{
						lblError.ForeColor = Color.Red;
						lblError.Text = objError.strMessage;
					}
				}
			}
			if(e.CommandName == "Add")
			{
				DropDownList ddlcts = (DropDownList)e.Item.FindControl("ddlListCts");
				if(Session["Uname"]!=null)
				{
					objUser.InsertCts(Session["Uname"].ToString().Trim(),ddlcts.SelectedValue.Trim(),ref objError);
					if(objError.boolErrorOccurred == false)
					{
						lblError.Text = objError.strMessage;
						Binddata();
					}
					else
					{
						lblError.ForeColor = Color.Red;
						lblError.Text = objError.strMessage;
					}
				}
			}
		}

		public DataSet ddlBind()
		{
			dsddl = new DataSet();
			objTMgr = new ThreadMgr();
			objError = new clsError();
			if(Session["Uname"] != null)
			{
				dsddl =	objTMgr.GetCountries(ref objError);
			}
			return dsddl;
		}

//		public DataSet FillRegCountries()
//		{
//			dsCts = new DataSet();
//			objError = new clsError();
//			objTMgr = new ThreadMgr();
//			dsCts =	objTMgr.GetRegCountries(ref objError);
//			return dsCts;
//		}

		protected void dgcts_ItemDataBound(object sender, System.Web.UI.WebControls.DataGridItemEventArgs e)
		{
			if(e.Item.ItemType == ListItemType.Footer)
			{
				
			}
		}

		protected void Button1_Click(object sender, System.EventArgs e)
		{
			lblError.Text = null;
			pnlAccnt.Visible = false;
			pnlSuc.Visible = true;
			pnlRegCts.Visible = false;
		}

		protected void btnSave_Click(object sender, System.EventArgs e)
		{
			update();
			Response.Redirect("MySettings.aspx?uid=Edit&qstr=pnl");
		}

	}
}
