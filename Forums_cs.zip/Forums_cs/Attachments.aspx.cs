using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Configuration;
using System.IO;
using Forums_cs.Classes;


namespace Forums_cs
{
	/// <summary>
	/// Summary description for WebForm1.
	/// </summary>
	public partial class Attachments : System.Web.UI.Page
	{
		protected string ItemId=null;
		protected string strFileName = null;
		protected string strPath = null;
		protected string RelPath = null;
		int Filelength = 0;
		int fileindex = 0;
		
		protected string strFileExtent = null;
		protected DataSet dsFileUpload;
		
		string stredit= null;
		public bool showpanal= false;
		clsError objError = null;
		Random rnm = new Random();
		clsItemUploadFileMgr objuploadMgr= null;
		
		clsItemUploadFiles objItemupload = null;
		protected void Page_Load(object sender, System.EventArgs e)
		{
			if(Session["Uname"]!=null)
			{
				if(!Page.IsPostBack)
				{
					if(Request.QueryString["Edit"]!=null)
					{
						pnlView.Visible = true;
						stredit=Request.QueryString["Edit"].ToString().Trim();
						if(stredit=="EditFile")
						{
							ItemId = Request.QueryString["Item"].ToString().Trim();
							Session["FileID"]=ItemId;
						}
						else
						{
							lblError.ForeColor=Color.Red;
							lblError.Text="Url Request is Worng";
						}					
					}
					else if(Request.QueryString["View"]!=null)
					{
						showpanal=true;
						ItemId = Request.QueryString["Item"].ToString().Trim();
						Session["FileID"]=ItemId;
						dgAttachements.Columns[3].Visible = false;					
					}
					else
					{				
						if(Request.QueryString["Item"]!=null)
						{
							showpanal=false;
							pnlView.Visible = true;
							ItemId = Request.QueryString["Item"].ToString().Trim();
							Session["FileID"]=ItemId;
							dgAttachements.Visible=true;
							pnlnoAttachflies.Visible=false;
						}			
				
					}	
					gridbind();
					lblError.Visible=false;
				}
			}
			else
			{

			}
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.btnUpdate.Click += new System.Web.UI.ImageClickEventHandler(this.btnUpdate_Click);
			this.dgAttachements.PageIndexChanged += new System.Web.UI.WebControls.DataGridPageChangedEventHandler(this.dgAttachements_PageIndexChanged);
			this.dgAttachements.DeleteCommand += new System.Web.UI.WebControls.DataGridCommandEventHandler(this.dgAttachements_Delete);

		}
		#endregion
		
		public void FileExtentionCheck()
		{
			Filelength = FlUpload.PostedFile.FileName.Length;
			fileindex = FlUpload.PostedFile.FileName.LastIndexOf(".");
			strFileExtent = FlUpload.PostedFile.FileName.Substring(fileindex,Filelength - fileindex).ToLower();
			Filelength = 0;
		}


		public int genrate()
		{
			int Rnum=0;

			Rnum=rnm.Next(Convert.ToInt32(ConfigurationSettings.AppSettings["RndMin"]),Convert.ToInt32(ConfigurationSettings.AppSettings["RndMax"]));
			return Rnum;
		}
		
		private void btnUpdate_Click(object sender, System.EventArgs e)
		{
			

		}

		private void dgAttachements_PageIndexChanged(object source, System.Web.UI.WebControls.DataGridPageChangedEventArgs e)
		{
			dgAttachements.CurrentPageIndex=e.NewPageIndex;
			gridbind();
		
		}

		public void gridbind()
		{
			try
			{
			
				clsError objer = new clsError();
				objuploadMgr = new clsItemUploadFileMgr();
				if(dsFileUpload==null)
				{				
					dsFileUpload=objuploadMgr.GetUploadFiles( Session["FileID"].ToString(), objer);
					if(dsFileUpload.Tables.Count==1)
					{
						if(dsFileUpload.Tables[0].Rows.Count!=0)
						{
							showpanal=false;
							dgAttachements.DataSource=dsFileUpload.Tables[0];
							dgAttachements.DataBind();
							dgAttachements.Visible=true;
							

							if(showpanal)
							{
								pnlnoAttachflies.Visible=false;
							}
						}
						else
						{
						
							
						dgAttachements.Visible=false;
							if(showpanal)
							{
								pnlnoAttachflies.Visible=true;
							}
							
						}
					}
								
				}
				else
				{
					if(dsFileUpload.Tables[1].Rows.Count!=0)
					{
						dgAttachements.DataSource=dsFileUpload.Tables[1];
						dgAttachements.DataBind();
						dgAttachements.Visible=true;
						showpanal=false;
						if(showpanal)
						{
							pnlnoAttachflies.Visible=false;
						}
					}
					else
					{
					dgAttachements.Visible=false;
						if(showpanal)
						{
							pnlnoAttachflies.Visible=true;
						}
					}

				}


				
			}
			catch(Exception ex)
			{
				lblError.Visible=true;
				lblError.ForeColor = Color.Red;
				lblError.Text = "Error:"+ex.Message.ToString();			
			}				
			finally
			{			
			
			}		
		
		}

		
		public bool DeleteAtcualFile(clsItemUploadFiles objItemFilepath,clsError objerror)
		{

			bool flagdelete =true; 
			int lenstr=0;
			int  lastindex=0;
			string Fname=null;
			string Fullpath= null;
			string Fileadd=null;
			
			try
			{				
				Fileadd=objItemFilepath.File_path.ToString();
				lenstr= Fileadd.Length;
						
				lastindex= Fileadd.LastIndexOf("/");
				lastindex+=1;
				
			
			
				Fname= Fileadd.Substring(lastindex,lenstr-lastindex);
				

				Fullpath=Server.MapPath(ConfigurationSettings.AppSettings["FilePath"]+Fname);
				//str=File.Exists(s);
			
				if(flagdelete= File.Exists(Fullpath))
				{
				
					File.Delete(Fullpath);
					flagdelete= true;
					
				
				}
				else
				{
					objerror.boolErrorOccurred=true;
					objerror.strMessage="Error in Deleting";
					flagdelete=false;
				}			
			}
		
			catch(Exception ex)
			{			
				objerror.boolErrorOccurred=true;
				objerror.strMessage="Error in Deleting"+ex.Message.ToString();
				flagdelete= false;

			}
					
			return flagdelete;
		}


		protected void dgAttachements_Delete(object sender,DataGridCommandEventArgs e)
		{
			try
			{
				if(e.CommandName=="Delete")
				{
					objuploadMgr = new clsItemUploadFileMgr();
					objItemupload = new clsItemUploadFiles();
					objError = new clsError(); 
					
					if((e.Item.ItemType==ListItemType.Item)||(e.Item.ItemType==ListItemType.AlternatingItem))
					{
						HtmlInputHidden hdnflid = (HtmlInputHidden) e.Item.FindControl("hdnFileid");
						HtmlInputHidden hdnItd = (HtmlInputHidden) e.Item.FindControl("hdnItemid");
						
						
						objItemupload.File_id = hdnflid.Value.ToString();
						objItemupload.PostId =	hdnItd.Value.ToString();
						
						
						objuploadMgr.DeleteUploadFile(objItemupload,objError);

//						if(DeleteAtcualFile(objItemupload,objError))
//						{
//							lblError.Visible=true;
//							lblError.ForeColor=Color.Green;
//							lblError.Text="File is Deleted Seccessfully";						
//						}
//						else
//						{
//							lblError.Visible=true;
//							lblError.ForeColor=Color.Red;
//							lblError.Text="File is Not Deleted Seccessfully";						
//						}	
                
						if(objError.boolErrorOccurred== false)
						{
							lblError.ForeColor = Color.Green;
							lblError.Text = "The file is Successfully Deleted";
							gridbind(); 					
						}
						else
						{					
							lblError.Visible=true;
							lblError.ForeColor = Color.Red;
											
						}		
				
					}
				
				}
			}
			catch(Exception ex)
			{
				lblError.Visible=true;
				lblError.ForeColor = Color.Red;
				lblError.Text = "Error:"+ex.Message.ToString();
			}
		}


		public void DisplayDownload(string strPath)
		{
			string strPhysicalPath = null;
			FileInfo objInfo = null;
			try
			{
				
				strPhysicalPath = Server.MapPath(strPath);
				if(System.IO.File.Exists(strPhysicalPath))
				{
					objInfo = new FileInfo(strPhysicalPath);
					Response.Clear();
					Response.AddHeader("Content-Disposition", "attachment; filename="+objInfo.Name);
					Response.AddHeader("Content-Length", objInfo.Length.ToString());
					Response.ContentType = "application/octet-stream";
					Response.WriteFile(objInfo.FullName);
				}
			}
			catch(Exception ex)
			{
				lblError.ForeColor = Color.Red;
				lblError.Text = ex.Message.ToString();
			}
			finally
			{
				Response.End();
			}
		}
		


		public void dgAttachements_Cancel(object sender,DataGridCommandEventArgs e)
		{
		
			
			dgAttachements.EditItemIndex=-1;
			gridbind();
			lblError.Visible=false;
		
		
		}

		


		protected void dgAttachements_Edit(object sender,DataGridCommandEventArgs e)
		{
		
			dgAttachements.EditItemIndex=e.Item.ItemIndex;
			gridbind();
			lblError.Visible=false;
		
		
		
		}

		private void btnCancel_Click(object sender, System.EventArgs e)
		{
			txtFileName.Value="";
			//FlUpload.Value=null;
			
		}

		private void btnUpdate_Click(object sender, System.Web.UI.ImageClickEventArgs e)
		{
			objItemupload = new clsItemUploadFiles();
			objuploadMgr = new clsItemUploadFileMgr();
			objError = new clsError();
			string ActfileName;
			bool flg;
		
			try
			{
				if(txtFileName.Value.CompareTo("") != 0)
				{

					if(FlUpload.Value != null)
					{
						if(FlUpload.PostedFile != null)
						{	
							FileExtentionCheck();

							if(strFileExtent == ".pdf" || strFileExtent == ".doc"||strFileExtent == ".rtf" || strFileExtent == ".txt" || strFileExtent == ".gif" || strFileExtent == ".jpg" || strFileExtent == ".bmp" || strFileExtent == ".jpeg")
							{
								strFileName = ItemId;
								ActfileName=Filename(strFileExtent,ref objError);							

								if(objError.boolErrorOccurred==false)
								{
									RelPath = ConfigurationSettings.AppSettings["FilePath"]+ActfileName;
									strPath = HttpContext.Current.Server.MapPath(ConfigurationSettings.AppSettings["FilePath"]+ActfileName);
									objItemupload.ItemFile_Name=txtFileName.Value.Trim();
									objItemupload.PostId=Session["FileID"].ToString();
									objItemupload.File_path=RelPath;
									if(objuploadMgr.FileCount(objItemupload.PostId,ref objError))
									{
										FlUpload.PostedFile.SaveAs(strPath);
								
										objuploadMgr.InsertUpLoadfile(objItemupload,objError);
									}
									else
									{
										lblError.ForeColor = Color.Red;
										objError.boolErrorOccurred = true;
										lblError.Text = "Cannot Insert more than two files";
										objError.strMessage = "Cannot Insert more than two files";
									}
									if(objError.boolErrorOccurred==false)
									{
										lblError.Visible=true;
										lblError.ForeColor = Color.Green;
										lblError.Text = "The File is Successfully Upload";
										txtFileName.Value="";
										gridbind();
									}
									else
									{
										lblError.Visible=true;
										lblError.ForeColor = Color.Red;
										lblError.Text = "Error:"+objError.strMessage;
										flg= DeleteAtcualFile(objItemupload,objError);
									}
								}
								else
								{
									lblError.Visible=true;
									lblError.ForeColor = Color.Red;
									lblError.Text = "Error:Please upload  only pdf or doc or rtf or txt Files";
							
								}
						
							
						
							}
							else
							{
								lblError.Visible=true;
								lblError.ForeColor = Color.Red;
								lblError.Text = "Error:Please upload  only pdf or doc or rtf or txt Files";
							}
						}

					}
					
				}
				else
				{
					lblError.ForeColor = Color.Red;
					lblError.Text = "Please enter the File Name";
				}
			}
			catch(Exception ex)
			{
				Response.Write(ex.Message.ToString());
				lblError.ForeColor = Color.Red;
				lblError.Text = ex.Message.ToString();
				
			}
		}
		
		

			public string  Filename(string Extent,ref clsError objError)
			{
				int number=0;
				string relpath1=null;
				string strFilename= null;				
				objuploadMgr = new clsItemUploadFileMgr();				
				number= genrate();
				first:
				strFilename="AF"+number.ToString()+Extent;
				relpath1= ConfigurationSettings.AppSettings["FilePath"]+strFilename;	
				if(objuploadMgr.ISFileNameExsist(relpath1, objError))
				{
					goto first;
				}
				return  strFilename;		
			}

		protected void dgAttachements_SelectedIndexChanged(object sender, System.EventArgs e)
		{
		
		}

		protected void dgAttachements_ItemCommand(object source, System.Web.UI.WebControls.DataGridCommandEventArgs e)
		{
			if(e.CommandName == "View")
			{
				HtmlInputHidden hidFilePath = (HtmlInputHidden)e.Item.FindControl("hidFilePath");
				DisplayDownload(hidFilePath.Value.Trim());
			}
		}

		protected void Button1_ServerClick(object sender, System.EventArgs e)
		{
			
		}

	



	}
}
