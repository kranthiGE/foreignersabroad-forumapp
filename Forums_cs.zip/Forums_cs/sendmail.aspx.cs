using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Configuration;
using Forums_cs.Classes;
namespace Forums_cs
{
	/// <summary>
	/// Summary description for sendmail.
	/// </summary>
	public partial class sendmail : System.Web.UI.Page
	{
		clsSendmail objSend = null;
		clsError objError = null;
		User objUser = null;
		DataSet dsddl = null;
		protected System.Web.UI.WebControls.Literal ltrltry;
	
		
		protected void Page_Load(object sender, System.EventArgs e)
		{
			
			// Put user code to initialize the page here
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    

		}
		#endregion

		protected void Button1_Click(object sender, System.EventArgs e)
		{
//			objError = new clsError();
//			objSend = new clsSendmail();
//			objSend.SetMailSubject("hai.......");
//			objSend.SetMailBody(TextBox2.Text);
//            objSend.SendMailTo(ConfigurationSettings.AppSettings["adminMail"].ToString(),TextBox1.Text,ref objError);
//
//			if(objError.boolErrorOccurred == true)
//			{
//				Label1.ForeColor = Color.Red;
//				Label1.Text = objError.strMessage;
//			}
		}



		
	
	}
}
