using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Configuration;

using Forums_cs.Classes;
using dotForumIncludes;

namespace Forums_cs
{
	/// <summary>
	/// Summary description for SendToFriend.
	/// </summary>
	public partial class SendToFriend : System.Web.UI.Page
	{
		clsError objError = null;
		clsSendmail objSend = null;
		includeFunctions myincludes = null;
		string strId = null;
		protected void Page_Load(object sender, System.EventArgs e)
		{
			if(Session["Uname"]!=null)
			{
				pnlBottomLogin.Visible = false;
				pnlBottomLogout.Visible = true;
				pnlTopLogin.Visible = false;
				pnlLoginImage.Visible = true;
				pnluser.Visible = true;
				pnlMiddleLogin.Visible = false;
				pnlMiddleLogout.Visible = true;
				if(Session["Name"]!=null)
				{
					lblUserName.Text = Session["Name"].ToString();
				}	
			}
			if(Request.QueryString["id"] != null)
			{
				strId = Request.QueryString["id"].ToString();		
			}
			else if(Request.QueryString["Hlnk"] != null)
			{
				strId = null;
			}
			else if(Request.QueryString["qstr"] != null)
			{
				pnlSuccess.Visible = true;
				pnlSend.Visible = false;
			}	
			else
			{
				Response.Redirect("Home.aspx");
			}
			btnSend.Attributes["onclick"] = "javascript:return Valid()";
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    

		}
		#endregion


		protected void lnkbtnBotLogout_click(object sender, System.EventArgs e)
		{
			Session.Abandon();
			
			Response.Redirect("Home.aspx");
		}

		protected void btnSend_Click(object sender, System.EventArgs e)
		{
			try
			{
				objError = new clsError();
				objSend = new clsSendmail();
				myincludes = new includeFunctions();

				objSend.SetMailSubject(getSubject());				
				
				if(TextboxFemail1.Text.CompareTo("") != 0)
				{
					objSend.SetMailBody(getBody(TextboxFname1.Text.Trim()));
					objSend.SendMailTo(TextboxYouEmail.Text.Trim(),TextboxFemail1.Text,ref objError);
				}
				if(TextboxFemail2.Text.CompareTo("") != 0)
				{
					objSend.SetMailBody(getBody(TextboxFname2.Text.Trim()));
					objSend.SendMailTo(TextboxYouEmail.Text.Trim(),TextboxFemail2.Text,ref objError);
				}
				if(TextboxFemail3.Text.CompareTo("") != 0)
				{
					objSend.SetMailBody(getBody(TextboxFname3.Text.Trim()));
					objSend.SendMailTo(TextboxYouEmail.Text.Trim(),TextboxFemail3.Text,ref objError);
				}
				if(TextboxFemail4.Text.CompareTo("") != 0)
				{	
					objSend.SetMailBody(getBody(TextboxFname4.Text.Trim()));
					objSend.SendMailTo(TextboxYouEmail.Text.Trim(),TextboxFemail4.Text,ref objError);
				}
				if(TextboxFemail5.Text.CompareTo("") != 0)
				{
					objSend.SetMailBody(getBody(TextboxFname5.Text.Trim()));
					objSend.SendMailTo(TextboxYouEmail.Text.Trim(),TextboxFemail5.Text,ref objError);
				}					
				if(objError.boolErrorOccurred == false)
				{
					if(strId != null)
					{
						Response.Redirect("threadView.aspx?id="+strId);
					}
					else
					{
						Response.Redirect("SendToFriend.aspx?qstr=pnl");
					}
				}
						
			}
			catch(Exception ex)
			{
				lblError.ForeColor = Color.Red;
				lblError.Text = "Error:"+ex.Message.ToString();
			}
		}

		public string getSubject()
		{
			string strSub = null;
			strSub =  "WelCome to the New Forum FA-Connecting People(From '"+txtBoxYou.Text+"')";
			return strSub;
		}

		public string GenerateUrl()
		{
			string strUrl = null;
			if(strId != null)
			{
				strUrl = ConfigurationSettings.AppSettings["DomainName"].ToString()+"/threadView.aspx?id="+strId;
			}
			else
			{
				strUrl = ConfigurationSettings.AppSettings["DomainName"].ToString()+"/Home.aspx";
			}
            return strUrl;			
		}

		public string getBody(string strName)
		{
			string strBody = null;

				strBody = "<table cellpadding=0 cellspacing=0 border=0 width=90%>"
							+"<tr>"
							+"<td>"
							+"&nbsp;<font class='docLink_std'>Dear "+strName+",</font>"
							+"</td>"
							+"</tr>"
							+"<tr>"
							+"<td>"
							+"&nbsp;&nbsp;&nbsp;I would like you to visit <a href='www.foreignersabroad.com'>www.foreignersabroad.com</a> .You can connect with people worldwide using this website."
							
							+"<br>"														
							+"</td>"
							+"</tr>"
							+"<tr>"
							+"<td>"
							+"<br>"
							+"Message:"
							+"</td>"
							+"</tr>"
							+"<tr>"
							+"<td>"							
							+""+txtBoxMsg.Text+""
							+"</td>"
							+"</tr>"
							+"<tr>"
							+"<td>"
							+"<br>"
							+"<font class='docLink_std'>Thanks ,</font>"
							+"</td>"
							+"</tr>"
							+"<tr>"
							+"<td>"
							+"&nbsp;"+txtBoxYou.Text.Trim()+""
							+"</td>"
							+"</tr>"
							+"</table>";

			return strBody;
		}
		protected void lnkbtnLogout_Click(object sender, System.EventArgs e)
		{
			Session.Abandon();
			
			Response.Redirect("Home.aspx");
		}

		protected void lnkbtnSetting_Click(object sender, System.EventArgs e)
		{
			Response.Redirect("MySettings.aspx?uid=Edit");
		}

		protected void btnSuccess_Click(object sender, System.EventArgs e)
		{
			Response.Redirect("Home.aspx");
		}
	}
}
