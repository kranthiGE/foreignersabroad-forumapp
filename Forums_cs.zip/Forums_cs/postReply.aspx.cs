using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using dotForumIncludes;
using System.Data.SqlClient;
using System.Configuration;
using Forums_cs.Classes;
namespace Forums_cs
{
	/// <summary>
	/// Summary description for postReply1.
	/// </summary>
	public partial class postReply1 : System.Web.UI.Page
	{
		public includeFunctions myIncludes = new includeFunctions();
	
		
		public string thisThreadId;
		public int thisTopicId;

		Authenticate auth = null;
		ThreadMgr objThreadMgr = null;
		User objUser = null;		
		clsError objError = null;
		Thread objThread = null;
		clsItemUploadFileMgr objUploadMgr = null;
		clsItemUploadFiles objUpload = null;
		Post objPost = null;
		string strPsid = null;

		SqlTransaction trans = null;
		SqlCommand myCommand = null;
		string strtemp = null;
		protected void Page_Load(object sender, System.EventArgs e)
		{
			if(Session["Uname"]!=null)
			{
				objUploadMgr = new clsItemUploadFileMgr();
				if(objUploadMgr.ShowAttach(Session["Uname"].ToString()))
				{
					pnlAttach.Visible = true;
				}
				pnlLoginImage.Visible = true;	
				pnlBottomLogout.Visible = true;
				pnlBottomLogin.Visible = false;
				pnlMiddleLogin.Visible = false;
				pnlMiddleLogout.Visible = true;
				pnluser.Visible = true;
				pnlTopLogin.Visible = false;
				if(Session["Name"]!=null)
				{
					lblUserName.Text = Session["Name"].ToString();
				}
			}
			else
			{
				lblUserName.Text = null;
			}
			if(Session["Uname"]!=null)
			{			
				objUser = new User();
				
					if(Session["Editpost"]!=null)
					{
						
					}
					else
					{
						try
						{
							if(Request.QueryString["id"]!=null)
							{
								thisThreadId = Request.QueryString["id"];
							}
							else if(Session["threadid"]!=null)
							{
								thisThreadId = Session["threadid"].ToString();
							}
							else
							{
								Response.Redirect("ErrorPage.aspx");
							}
						}
							//INSTANT C# TODO TASK: No C# equivalent to 'When'
						catch (Exception ex) // When 1=1
						{
							Response.Redirect("ErrorPage.aspx");
						}

						if (thisThreadId == null)
						{
							Response.Redirect("topicView.aspx?id=0");
						}
					}				
				if(!Page.IsPostBack)
				{
					try
					{
						
						HidAttach.Value = objUser.GetID("PS","select * from forumthreads where Postid = ",ref objError);
						if(Session["Uname"]!=null)
						{
							psEmail.Text = Session["Uname"].ToString();
						}
						if(Session["Name"]!=null)
						{
							txtBoxName.Text = Session["Name"].ToString();
						}
						//### GET TOP-LEVEL THREAD NAME
						SqlConnection myConnection = new SqlConnection(ConfigurationSettings.AppSettings["forumDSN"]);
						SqlCommand myCommand = new SqlCommand("SELECT LEFT(psSubject, 80) As psSubject, psRelBcId FROM forumThreads WHERE psId = '"+thisThreadId+"'", myConnection);

						myConnection.Open();

						SqlDataReader myReader = null;
						myReader = myCommand.ExecuteReader();

						myReader.Read();
						strtemp = myReader["psRelBcId"].ToString();
						hidTopicID.Value = strtemp;
						topicLink.NavigateUrl = "topicView.aspx?id="+strtemp+"";
						topicLink.Text = myIncludes.getTopicName(strtemp);
//						threadLink.NavigateUrl = "threadView.aspx?id=" + thisThreadId;
						psSubject.Text = myReader["psSubject"].ToString();
						
						objError = new clsError();
						objThreadMgr = new ThreadMgr();
						string strImgurl = objThreadMgr.GetImagPath(strtemp,ref objError);
						if(strImgurl != null && strImgurl != "")
						{
							imgCountry.ImageUrl = strImgurl;
						}
						else
						{
							imgCountry.ImageUrl = "fa_images/default_image.JPG";
						}
							
						
						myReader.Close();
						myConnection.Close();

						if (! Page.IsPostBack)
						{
							submitter.CommandArgument = strtemp.ToString();

							//BindData();
						}
					}
					catch(Exception ex)
					{

					}
				}
			}
			else
			{
				if(Request.QueryString["id"]!=null)
				{
					Session["threadid"] = Request.QueryString["id"].ToString();
					Response.Redirect("LoginPage.aspx?qstr=LoginUser");
				}
				else
				{
					Response.Redirect("LoginPage.aspx?qstr=LoginUser");
				}
				
			}
			submitter.Attributes["onclick"] = "javascript:return valid()";			
			lnkbtnAttach.Attributes["onclick"] = "javascript:return FileUpload('"+HidAttach.Value.Trim()+"')";
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.imgbtnSearch.ServerClick += new System.Web.UI.ImageClickEventHandler(this.imgbtnSearch_ServerClick);

		}
		#endregion

		
		public void BindData()
		{

			//### ONLY NEED TOP LEVEL SUBJECT TO PREPEND WITH "RE: "
			psSubject.Text = "RE: " + myIncludes.getThreadSubject(thisThreadId);

		}

		protected void lnkbtnBotLogout_click(object sender, System.EventArgs e)
		{
			Session.Abandon();
			
			Response.Redirect("Home.aspx");
		}

		public void Page_Error(object sender, EventArgs e)
		{
			string strErrorMessage = "";

			Response.Write("<font style=\"color:#cc0000; font-family: system; font-size:11px;\">An error has occurred on this page:<p>");
			strErrorMessage = Request.Url.ToString() + "<p>" + Server.GetLastError().ToString() + "</font>";
			Response.Write(strErrorMessage);

			Server.ClearError();

			Response.Write("<p><a class=\"menuitem\" href=\"ErrorPage.aspx\">Return to the Discussion Forum</a></p>");

		}


		protected void submitter_Click(object sender, System.EventArgs e)
		{
			try
			{			
				objPost = new Post();
				System.DateTime lastUpdate = System.DateTime.Now;
				objUser = new User();
				objError = new clsError();
				strPsid = objUser.GetThreadId("select * from forumthreads where psId = ",ref objError);
				using (SqlConnection connect = new SqlConnection(ConfigurationSettings.AppSettings["forumDSN"]))
				{
					try
					{	
						connect.Open();
						
						myCommand = new SqlCommand();
						trans = connect.BeginTransaction();
						myCommand.Transaction = trans;
						myCommand.Connection = connect;
						if(chkBox.Checked)
						{
							myCommand.CommandText = "INSERT INTO forumThreads (psId,psRelTopId, psName, psEmail, psSubject, psPost, psDate, psRelBcId, psLastUpdate, psIP, Postid, Notify) VALUES('"+strPsid+"','"+thisThreadId+"', '" + myIncludes.RemoveHTMLQuote(txtBoxName.Text) + "',  '" + myIncludes.RemoveHTMLQuote(psEmail.Text) + "',  '" + myIncludes.RemoveHTMLQuote(psSubject.Text) + "',  '" + myIncludes.RemoveHTMLQuote(psPost.Text) + "', '" + lastUpdate + "', '"+hidTopicID.Value.Trim()+"', '" + lastUpdate + "', '" + Request.ServerVariables["REMOTE_HOST"] + "','"+HidAttach.Value.Trim()+"', 'Y')";
						}
						else
						{
							myCommand.CommandText = "INSERT INTO forumThreads (psId,psRelTopId, psName, psEmail, psSubject, psPost, psDate, psRelBcId, psLastUpdate, psIP, Postid) VALUES('"+strPsid+"','"+thisThreadId+"', '" + myIncludes.RemoveHTMLQuote(txtBoxName.Text) + "',  '" + myIncludes.RemoveHTMLQuote(psEmail.Text) + "',  '" + myIncludes.RemoveHTMLQuote(psSubject.Text) + "',  '" + myIncludes.RemoveHTMLQuote(psPost.Text) + "', '" + lastUpdate + "', '"+hidTopicID.Value.Trim()+"', '" + lastUpdate + "', '" + Request.ServerVariables["REMOTE_HOST"] + "','"+HidAttach.Value.Trim()+"')";
						}
						myCommand.ExecuteNonQuery();
						
						//### UPDATE LAST DATE IN TOPIC
						
						
						myCommand.CommandText = "UPDATE forumTopics SET bcLastUpdate = '" + lastUpdate + "' WHERE bcId = '"+hidTopicID.Value.Trim()+"'";
						myCommand.ExecuteNonQuery();
						

						//### UPDATE LAST DATE IN THREAD PARENT
											
						myCommand.CommandText = "UPDATE forumThreads SET psLastUpdate = '" + lastUpdate + "' WHERE psId = '"+thisThreadId+"'";
						myCommand.ExecuteNonQuery();
						trans.Commit();

						Session["threadid"] = null;
						
						if(Session["FileID"]!=null)
						{
							Session["FileID"] = null;
						}
						
						objPost.NotifybyEmail(Session["Name"].ToString(),HidAttach.Value.Trim(),thisThreadId.ToString(),psSubject.Text,psPost.Text);
						Response.Redirect("threadView.aspx?id=" + thisThreadId);
					}
					catch(Exception ex)
					{
						trans.Rollback();
						Response.Write("<font style=\"color:#cc0000; font-family: system; font-size:11px;\">An Exception error has occurred on this page:<p>");
						Response.Write("<p>" + ex.ToString());
						Response.Write("<p><b>Record NOT Inserted</b></font>");
						Server.ClearError();
					}
					finally
					{
						connect.Close();
					}				
				}
			}
				//INSTANT C# TODO TASK: No C# equivalent to 'When'
			catch (Exception ex) // When 1=1
			{
				Response.Write("<font style=\"color:#cc0000; font-family: system; font-size:11px;\">An Exception error has occurred on this page:<p>");
				Response.Write("<p>" + ex.ToString());
				Response.Write("<p><b>Record NOT Inserted</b></font>");
				Server.ClearError();
			}
		}

		protected void canceller_Click(object sender, System.EventArgs e)
		{
			Response.Redirect("threadView.aspx?id=" + thisThreadId);
		}
		

		



		protected void lnkbtnLogout_Click(object sender, System.EventArgs e)
		{
			Session.Abandon();
			
			Response.Redirect("Home.aspx");
		}

		protected void lnkbtnSetting_Click(object sender, System.EventArgs e)
		{
			Response.Redirect("MySettings.aspx?uid=Edit");
		}

		private void imgbtnSearch_ServerClick(object sender, System.Web.UI.ImageClickEventArgs e)
		{
			Response.Redirect("Search.aspx?srch="+textfield.Value.Trim());
		}
		

	}
}
