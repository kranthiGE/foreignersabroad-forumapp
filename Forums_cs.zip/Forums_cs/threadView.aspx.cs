using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.IO;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using dotForumIncludes;
using System.Data.SqlClient;
using System.Configuration;
using Forums_cs.Classes;
namespace Forums_cs
{
	/// <summary>
	/// Summary description for threadView1.
	/// </summary>
	public partial class threadView1 : System.Web.UI.Page
	{
		public includeFunctions myIncludes = new includeFunctions();
		clsItemUploadFileMgr objUploadMgr = null;
		clsItemUploadFiles objUpload = null;
		clsError objError = null;
		ThreadMgr objThreadMgr = null;
		User objUser = null;
		string strSub= null;
		string strTId = null;
		string strQry = null;
		ArrayList alist = null;
		public string thisThreadId;
		public int thisThreadId1;
		
		
		public string thisSortOrder;
		

		protected void Page_Load(object sender, System.EventArgs e)
		{
			if(Session["Uname"]!=null)
			{
				objUser = new User();
				lblError.Text = null;
				pnlLoginImage.Visible = true;
				imgbtnAdd.Visible = true;
				pnluser.Visible = true;
				pnlTopLogin.Visible = false;
				pnlBottomLogin.Visible = false;
				pnlBottomLogout.Visible = true;
				pnlMiddleLogin.Visible = false;
				pnlMiddleLogout.Visible = true;
				if(Session["Name"]!=null)
				{
					lblUserName.Text = Session["Name"].ToString();
				}
			}
			else
			{
				imgbtnAdd.Visible = false;
				lblUserName.Text = null;
			}

			try
			{
				thisThreadId = Request.QueryString["id"];
				
			}
				//INSTANT C# TODO TASK: No C# equivalent to 'When'
			catch (Exception ex) // When 1=1
			{				
				Response.Redirect("ErrorPage.aspx");
			}
			try
			{
				thisSortOrder = Request.QueryString["or"];
			}
				//INSTANT C# TODO TASK: No C# equivalent to 'When'
			catch (Exception ex) // When 1=1
			{		
				Response.Redirect("ErrorPage.aspx");
			}

			if (thisSortOrder == null)
			{
				thisSortOrder = "asc";
			}

			if (thisSortOrder != "asc" & thisSortOrder != "desc")
			{
				Response.Redirect("ErrorPage.aspx");				
			}			
			try
			{
				objError = new clsError();
				objThreadMgr = new ThreadMgr();
				SqlConnection myConnection = new SqlConnection(ConfigurationSettings.AppSettings["forumDSN"]);
				SqlCommand myCommand = new SqlCommand("SELECT LEFT(psSubject, 60) As psSubject, psRelBcId FROM forumThreads WHERE psId = '"+thisThreadId+"'", myConnection);

				myConnection.Open();

				SqlDataReader myReader = null;
				myReader = myCommand.ExecuteReader();

				myReader.Read();
				threadLink.NavigateUrl = "topicView.aspx?id=" + myReader["psRelBcId"] ;
				threadLink.Text = myIncludes.getTopicName(myReader["psRelBcId"].ToString());
				strTId = myReader["psRelBcId"].ToString();
				string strImgurl = objThreadMgr.GetImagPath(myReader["psRelBcId"].ToString(),ref objError);
				if(strImgurl != null && strImgurl != "")
				{
					imgCountry.ImageUrl = strImgurl;
				}
				else
				{
					imgCountry.ImageUrl = "fa_images/default_image.JPG";
				}

				myReader.Close();
				myConnection.Close();
			


				if (! Page.IsPostBack)
				{
					
					sortOrder.SelectedValue = thisSortOrder;
					if(Session["Uname"] != null)
					{
						if(objUser.IsMyFav(Session["Uname"].ToString(),strTId,ref objError))
						{
							imgbtnAdd.Visible = false;
							imgbtnRemove.Visible = true;
						}						
					}
					bindData();
				}
			}
			catch(Exception ex)
			{
                Response.Redirect("ErrorPage.aspx");		
			}
			
		}

		public void bindData()
		{

			SqlConnection myConnection = new SqlConnection(ConfigurationSettings.AppSettings["forumDSN"]);

			string dataSQL = null;
			dataSQL = "SELECT psName, psEmail, psSubject,psId, psPost, psDate, postid, psRelBcId FROM forumThreads WHERE psId = '"+thisThreadId+"' OR psRelTopId = '"+thisThreadId+"' ORDER BY psDate " + thisSortOrder;

			SqlCommand myCommand = new SqlCommand(dataSQL, myConnection);

			SqlDataAdapter myDA = new SqlDataAdapter();
			myDA.SelectCommand = myCommand;

			DataSet myDS = new DataSet();
			myDA.Fill(myDS, "forumThreads");

			//### IF THERE ARE NO THREADS, REDIRECT TO TOPIC PAGE
			if (myDS.Tables["forumThreads"].Rows.Count == 0)
			{
				// Response.Redirect("index.aspx")
				messageCenter.InnerHtml = "<p>There are currrently no threads in this topic.<p><a class=\"menuitem\" href=\"ErrorPage.aspx\">View All Topics</a>";
			}
			else
			{
				int sublen = 0;
				dotForumDisplay.DataSource = myDS;
				dotForumDisplay.DataBind();
				strSub = myDS.Tables["forumThreads"].Rows[0]["psSubject"].ToString();
				sublen = strSub.LastIndexOf("]");
				lblSubject.Text = strSub.Substring(sublen+1,strSub.Length-(sublen+1));
				

				//### DISABLE NEXT/PREV IF LESS THAN dotForumDisplay.PageSize
				if (myDS.Tables[0].Rows.Count < dotForumDisplay.PageSize)
				{
					dotForumDisplay.PagerStyle.Visible = false;
				}
			}

		}


		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
//		this.imgbtnLogout.Click += new System.Web.UI.ImageClickEventHandler(this.imgbtnLogout_Click);
//		this.sorter.Click += new System.EventHandler(this.sorter_Click);
//		this.dotForumDisplay.ItemCommand += new System.Web.UI.WebControls.DataGridCommandEventHandler(this.dotForumDisplay_ItemCommand);
//		this.dotForumDisplay.ItemDataBound += new System.Web.UI.WebControls.DataGridItemEventHandler(this.dotForumDisplay_ItemDataBound);
//		this.Load += new System.EventHandler(this.Page_Load);
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.imgbtnReply.Click += new System.Web.UI.ImageClickEventHandler(this.imgbtnReply_Click);
			this.dotForumDisplay.ItemCommand += new System.Web.UI.WebControls.DataGridCommandEventHandler(this.dotForumDisplay_ItemCommand);
			this.dotForumDisplay.ItemDataBound += new System.Web.UI.WebControls.DataGridItemEventHandler(this.dotForumDisplay_ItemDataBound);
			this.imgbtnSearch.ServerClick += new System.Web.UI.ImageClickEventHandler(this.imgbtnSearch_ServerClick);

		}
		#endregion

		private void dotForumDisplay_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			
		}

		public void dotForumDisplay_Paged(object source, System.Web.UI.WebControls.DataGridPageChangedEventArgs e)
		{
			dotForumDisplay.CurrentPageIndex = e.NewPageIndex;
			bindData();
		}

		public void sorter_update(object sender, System.Web.UI.WebControls.CommandEventArgs e)
		{
			Response.Redirect("threadView.aspx?id="+thisThreadId+"&or=" + sortOrder.SelectedItem.Value);
		}

		private void sorter_Click(object sender, System.EventArgs e)
		{
			Response.Redirect("threadView.aspx?id="+thisThreadId+"&or=" + sortOrder.SelectedItem.Value);
		}

		private void lnkbtnSignOut_Click(object sender, System.EventArgs e)
		{
			Session.Abandon();
		}

		public void dotForumDisplay_ItemCommand(object source, System.Web.UI.WebControls.DataGridCommandEventArgs e)
		{
			if(e.CommandName == "ViewProfile")
			{
				if(Session["emailid"]!=null)
				{
					Session["emailid"] = null;
				}
                HtmlInputHidden hidEmail = (HtmlInputHidden)e.Item.FindControl("hidEmail");
				Session["emailid"] = hidEmail.Value;
				Response.Redirect("ViewProfile.aspx?id="+thisThreadId+"");
			}
			if(e.CommandName == "file1")
			{
				HtmlInputHidden hidFile1 = (HtmlInputHidden)e.Item.FindControl("hidFile1");
				
				DisplayDownload(hidFile1.Value);
			}
			if(e.CommandName == "file2")
			{
				HtmlInputHidden hidFile2 = (HtmlInputHidden)e.Item.FindControl("hidFile2");

				DisplayDownload(hidFile2.Value);
			}
		}

		protected void dotForumDisplay_ItemDataBound(object sender, System.Web.UI.WebControls.DataGridItemEventArgs e)
		{
			if(e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
			{
				DataSet dsFiles = new DataSet();
				alist = new ArrayList();
				objUploadMgr = new clsItemUploadFileMgr();
				objUpload = new clsItemUploadFiles();
				Panel pnlattach = (Panel)e.Item.FindControl("pnlAttach");
				
				LinkButton lnkbtnFile1 = (LinkButton)e.Item.FindControl("lnkbtnFile1");
				LinkButton lnkbtnFile2 = (LinkButton)e.Item.FindControl("lnkbtnFile2");

				HtmlInputHidden hidFile1 = (HtmlInputHidden)e.Item.FindControl("hidFile1");
				HtmlInputHidden hidFile2 = (HtmlInputHidden)e.Item.FindControl("hidFile2");
					

				HtmlInputHidden hidPostId = (HtmlInputHidden)e.Item.FindControl("HidPostId");
				
				strQry = "select * from post_files where postid = '"+hidPostId.Value.Trim()+"'";
				dsFiles = objUploadMgr.GetFileNames(strQry,ref objError);
				if(dsFiles.Tables.Count != 0)
				{

				}
				if(dsFiles.Tables[0].Rows.Count != 0)
				{
					pnlattach.Visible = true;
					
					if(dsFiles.Tables[0].Rows.Count == 2)
					{
						lnkbtnFile1.Text = dsFiles.Tables[0].Rows[0]["File_Name"].ToString();
						lnkbtnFile2.Text = dsFiles.Tables[0].Rows[1]["File_Name"].ToString();

						hidFile1.Value = dsFiles.Tables[0].Rows[0]["Filepath"].ToString();
						hidFile2.Value = dsFiles.Tables[0].Rows[1]["Filepath"].ToString();
					}
					else
					{
						lnkbtnFile1.Text = dsFiles.Tables[0].Rows[0]["File_Name"].ToString();

						hidFile1.Value = dsFiles.Tables[0].Rows[0]["Filepath"].ToString();						
					}
					for(int i=0; i<=alist.Count-1;i++)
					{
						//lblNames.Text += "  "+alist[i].ToString();
					}				
				}					
			}
			if(e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
			{
				string strText = null;
				Label lblPost = (Label)e.Item.FindControl("lblPost");
				strText = lblPost.Text.Trim();
				lblPost.Text = myIncludes.InsertSmiley(strText);

				System.Web.UI.WebControls.Image imgFlag = (System.Web.UI.WebControls.Image)e.Item.FindControl("Image1");
				if(imgFlag.ImageUrl == "")
				{
					imgFlag.Visible = false;
				}
			}
			
		}

		private void imgbtnLogout_Click(object sender, System.Web.UI.ImageClickEventArgs e)
		{
			Session.Abandon();
			pnlLoginImage.Visible = true;	
			lblUserName.Text = null;
			
			pnluser.Visible = false;
			pnlTopLogin.Visible = true;
		}

		private void dotForumDisplay_ItemDataBound_1(object sender, System.Web.UI.WebControls.DataGridItemEventArgs e)
		{
			
		}

		private void dotForumDisplay_ItemCommand_1(object source, System.Web.UI.WebControls.DataGridCommandEventArgs e)
		{
			
		}

		protected void sortOrder_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			Response.Redirect("threadView.aspx?id=" + thisThreadId + "&or=" + sortOrder.SelectedItem.Value);
		}

		protected void lnkbtnLogout_Click(object sender, System.EventArgs e)
		{
			Session.Abandon();			
//			lblUserName.Text = null;
//			
//			pnluser.Visible = false;
//			pnlTopLogin.Visible = true;			
//			pnlLoginImage.Visible = false;
			Response.Redirect("Home.aspx");
		}


		protected void lnkbtnSetting_Click(object sender, System.EventArgs e)
		{
			Response.Redirect("MySettings.aspx?uid=Edit");
		}

		private void imgbtnSearch_ServerClick(object sender, System.Web.UI.ImageClickEventArgs e)
		{
			Response.Redirect("Search.aspx?srch="+textfield.Value.Trim()+"&id="+thisThreadId);
		}

		private void imgbtnReply_Click(object sender, System.Web.UI.ImageClickEventArgs e)
		{
			Response.Redirect("postReply.aspx?id="+thisThreadId+"");
		}

		public void DisplayDownload(string strPath)
		{
			string strPhysicalPath = null;
			FileInfo objInfo = null;
			try
			{
				strPhysicalPath = Server.MapPath(strPath);
				if(System.IO.File.Exists(strPhysicalPath))
				{
					objInfo = new FileInfo(strPhysicalPath);
					Response.Clear();
					Response.AddHeader("Content-Disposition", "attachment; filename="+objInfo.Name);
					Response.AddHeader("Content-Length", objInfo.Length.ToString());
					Response.ContentType = "application/octet-stream";
					Response.WriteFile(objInfo.FullName);
				}
			}
			catch(Exception ex)
			{
				lblError.ForeColor = Color.Red;
				lblError.Text = ex.Message.ToString();
			}
			finally
			{
				Response.End();
			}
		}

		protected void imgbtnAdd_Click(object sender, System.Web.UI.ImageClickEventArgs e)
		{
			try
			{
				objUser = new User();
				objError = new clsError();
				objUser.AddFav(Session["Uname"].ToString(),strTId,ref objError);
				if(objError.boolErrorOccurred == false)
				{
					imgbtnAdd.Visible = false;
					imgbtnRemove.Visible = true;
				}
			}
			catch(Exception ex)
			{
                lblError.ForeColor = Color.Red;
				lblError.Text = "Error:"+ex.Message.ToString();
			}
		}

		protected void imgbtnRemove_Click(object sender, System.Web.UI.ImageClickEventArgs e)
		{
			try
			{
				objUser = new User();
				objError = new clsError();
				objUser.RemoveFav(Session["Uname"].ToString(),strTId,ref objError);
				if(objError.boolErrorOccurred == false)
				{
					imgbtnAdd.Visible = true;
					imgbtnRemove.Visible = false;
				}
			}
			catch(Exception ex)
			{
				lblError.ForeColor = Color.Red;
				lblError.Text = "Error:"+ex.Message.ToString();
			}
		}

		protected void imgbtnSend_Click(object sender, System.Web.UI.ImageClickEventArgs e)
		{
			Response.Redirect("SendToFriend.aspx?id="+thisThreadId);
		}

		protected void lnkbtnBotLogout_click(object sender, System.EventArgs e)
		{
			Session.Abandon();
			
			Response.Redirect("Home.aspx");
		}

	}
}
